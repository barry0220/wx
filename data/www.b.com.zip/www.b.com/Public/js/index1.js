$(function(){
	$(".left_nav>div").click(function(){
		var index = $(this).index()
		if(index==0){
			$(".tab_1").hide()
			
		}else if(index==1){
			$(".tab_2").hide()
			
		}else if(index==2){	
			$(".tab_3").hide()
			
		}else if(index==3){
			$(".tab_4").hide()
		}

		
	})
	$(".table_zhou>span").click(function(){
		var index1 = $(this).index()
		alert(index1)
	
		if(index1=="1"){
				$.ajax({
		"type": "post",
		"url": "http://app.gymbaby.cn/Home/qiandao",
		"dataType": "json",
		"data":{
		
		},
		success: function(data){
			console.log(data)
		}
					});
			
			
		}else if(index1=="2"){
					$.ajax({
		"type": "post",
		"url": "http://app.gymbaby.cn/Home/qiandao",
		"dataType": "json",
		"data":{
			
		},
		success: function(data){
			console.log(data)
		}
					});
		}else if(index1=="3"){
						$.ajax({
		"type": "post",
		"url": "http://app.gymbaby.cn/Home/qiandao",
		"dataType": "json",
		"data":{
			
		},
		success: function(data){
			console.log(data)
		}
					});
	
		}else if(index1=="4"){
			$.ajax({
		"type": "post",
		"url": "http://app.gymbaby.cn/Home/qiandao",
		"dataType": "json",
		"data":{
		
		},
		success: function(data){
			console.log(data)
		}
					})
			
		}else if(index1=="5"){
				$.ajax({
		"type": "post",
		"url": "http://app.gymbaby.cn/Home/qiandao",
		"dataType": "json",
		"data":{
		
		},
		success: function(data){
			console.log(data)
		}
					})
			
			
		}else if(index1=="6"){
			$.ajax({
		"type": "post",
		"url": "http://app.gymbaby.cn/Home/qiandao",
		"dataType": "json",
		"data":{
		
		},
		success: function(data){
			console.log(data)
		}
					})
			
			
		}else if(index1=="7"){
			$.ajax({
		"type": "post",
		"url": "http://app.gymbaby.cn/Home/qiandao",
		"dataType": "json",
		"data":{
		
		},
		success: function(data){
			console.log(data)
		}
					})
			
		}
		
		
		
	})
	
	$(".tab_1_1>span").click(function(){
		var index=$(this).index()
		/*$(this).attr("class","border-3").siblings().attr("class"," ");*/
        $(".tab_1_1>span").removeClass("border-3");
        $(this).addClass("border-3")

		if(index=="0"){
			$(".huiyuan_liebiao").show();
			$(".xinzenghuiyuan").hide();
			$(".huiyuanxuyuan").hide();
		
		}else if(index=="1"){
			$(".huiyuan_liebiao").hide();
			$(".xinzenghuiyuan").show();
			$(".huiyuanxuyuan").hide();
		}else if(index=="2"){
			$(".huiyuan_liebiao").hide();
			$(".xinzenghuiyuan").hide();
			$(".huiyuanxuyuan").show();
		}
	
	
	
	})
	var wdwid=$(window).width();
	var leftN=wdwid-$('.advert').width();
	var pL=leftN/2+'px'
$('.advert').css('left',pL)



	
})
