/**
 * Created by Administrator on 2017-06-09.
 */
function tap(obj) {
    $(obj).siblings().find($('.tapP')).removeClass("active");
    $(obj).find($('.tapP')).addClass("active");
   var tapC= $(obj).index();
 /*  $('.tapCon').find($('.tapList')).removeClass("hidd");*/
    $('.tapCon').find($('.tapList')).eq(tapC).removeClass("hidd")
    $('.tapCon').find($('.tapList')).eq(tapC).siblings().addClass("hidd")
}
function xuanze(obj) {
    $(obj).siblings().find($('.content1')).css('color','#666')
    $(obj).find($('.content1')).css('color','#fdb06a')
}

