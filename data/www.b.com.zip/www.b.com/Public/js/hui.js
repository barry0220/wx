/**
 * Created by Administrator on 2017-03-21.
 */


var strtjbb2=" <p class='xzhy-hyxiangqing'><span>姓名：<i><input type='text' class='baobao_name'/></i></span><span >小名：<i><input type='text' id='baobao_name1[]'/></i></span>"
    +"<span>"
+"出生日期："
    +"<i>"
+"<select style='width: 120px' name='' id='baobao_birthday'>"
   +" <option value=''></option>"
    +"<option value=''></option>"
    +"<option value=''></option>"
    +"</select>"
    +"</i>"
    +"</span><span >性别：<i><input type='radio' checked='checked' id='sex' name='Sex' value='male' style='width: 12px;height: 12px;' />男<input type='radio' checked='checked' id='sex[]' name='Sex' value='male' style='width: 12px; height: 12px;margin-left: 15px;'/>女</i></span></p>";

$("#tjbb").click(function () {
    var strtjbb="";
    strtjbb+=strtjbb2;
    $(".tibaobao").append(strtjbb)
});


$(".quxiao2").click(function () {
    $(".chongzhikc2").css("display","none")
})
$(".queren2").click(function () {
    $(".chongzhikc2").css("display","none")
});

/*点击表格的续约*/


/*会员签约页面确认添加按钮*/


/*家长联系方式添加*/
var a=0;
function jiazjia(){

 a++;
 if(a<6){
    var jiazjiastr1="";

    var jiazjiastr2="<br><br><p class='hu_2' style='margin-top: 0;margin-bottom: 0;clear: both'>"
        +"<span style='font-size: 14px;'>&nbsp;&nbsp;&nbsp;<b style='color:red'>*&nbsp;</b>关系：<i><select style='width:78px;' class='guanxi"+a+"'>"
        +"<option value ='1'>爸爸</option>"
        +"<option value ='2'>妈妈</option>"
        +"<option value='3'>爷爷</option>"
        +"<option value='4'>奶奶</option>"
        +"<option value='5'>姥爷</option>"
        +"<option value='6'>姥姥</option>"
        +"</select></i></span>"
        +"<span  style='font-size: 14px;margin-left: 46px '><b style='color:red'>*&nbsp;</b>姓名：<i><input type='text' class='name"+a+"'/></i></span>"
        +"<span style='font-size: 14px;margin-left: 27px ;'><b style='color:red'>*&nbsp;</b>联系电话：<i><input type='text' style='width:120px' class='phone"+a+"'/></i></span>"
        +"</p>";
    jiazjiastr1+=jiazjiastr2;
    $("#jiazlx").append(jiazjiastr1)

 }
}
/*家长联系方式添加*/
/*
$(".tb").on("click",".xq",function(){
    alert(1);
    $(".mk1").css("display","none");

})*/
$("#xgxx").click(function () {

    $("#lxfsxs").css("display",'none');
    $("#xgjz").css('display','block');
    $("#dzxs").css("display",'none');
    $('.xgxx').css('display','blok');
    $("#dzinp").css('display','block');
$("#xgxx").css("display",'none');
$("#qrxg").css("display",'block');

});
var b=0;
$("#tij5").click(function () {
    b++;
    if(b<5){
        var jiazjiastr1="";

        var jiazjiastr2="<p class='hu_2' style='margin-top: 0;margin-bottom: 0;clear: both'>"
            +"<span style='font-size: 14px;'> 关系：<i><select style='width: 78px;height: 20px' id='guanxi[]'>"
            +"<option value ='volvo'>Volvo</option>"
            +"<option value ='saab'>Saab</option>"
            +"<option value='opel'>Opel</option>"
            +"<option value='audi'>Audi</option>"
            +"</select></i></span>"
            +"<span  style='font-size: 14px;margin-left:45px' >姓名：<i><input type='text' id='name[]'/></i></span>"
            +"<span style='font-size: 14px;margin-left:27px'>联系电话：<i><input type='text' style='width:120px' id='phone[]'/></i></span>"
            +"</p><br>";
        jiazjiastr1+=jiazjiastr2;
        $("#xgjz").append(jiazjiastr1)

    }
});


$('#qrxg').click(function () {
    $('#hyxgcg').css('display','block')
    setTimeout(function () {
        $('#hyxgcg').css('display','none')
    },3000)
})

