/**
 * Created by Administrator on 2017-04-24.
 */





$('.xiugai').click(function () {
   /* console.log($(this).parent().parent())*/
    $(this).parent().parent().css({
        'border':'none',
        'box-shadow':'none',
        'display':'none'
    });
    $(this).parent().parent().parent().find('.tjkuang3').css('display','block');
   /* $(this).parent().parent().animate({height:"0px"});*/

   /* $(this).parent().parent().find('.tjkuang3').css({
        'height':'200px',
        'border':' 1px solid #dbdbdb',
        'box-shadow':'1px 1px 2px 2px #dbdbdb'
    })
*/


   /* $(this).parent().parent( $('.tjkuang2'))
    $('.tjkuang3').css({
        'height':'200px',
        'border':' 1px solid #dbdbdb',
        'box-shadow':'1px 1px 2px 2px #dbdbdb'
    })*/
});
$('.huodtj3').click(function () {
    location.reload()
});
