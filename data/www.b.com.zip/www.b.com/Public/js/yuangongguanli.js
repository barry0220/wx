/**
 * Created by Administrator on 2017-04-06.
 */
$('.xzyg').click(function () {
   $('.xinzengyuantc').css('display','block')
});
$('.cha').click(function () {
    $('.xinzengyuantc').css('display','none')
    $('.xiugaitc').css('display','none')
});
$('.qrtianjiayg').click(function () {

    $('.xinzengyuantc').css('display','none')
});
$('.shancyg').click(function () {
    if(confirm("确定要删除该员工吗？"))
    {
     /* 如果确认删除*/
     $(this).parent().parent('.xx1').remove()

    }
    else
    {
        return false;
    }


})


