/**
 * Created by Administrator on 2017-07-28.
 */
$('.shehuiR li').click(function () {
    $('.shehuiR li').removeClass("active");
    $(this).addClass("active");
    var liIndex= $(this).index();
    $('.shehuiRY').removeClass("active");
    $('.shehuiRY').eq(liIndex).addClass("active");
    
});