$("li").click(function(){
	
		alert("1");
	
})
