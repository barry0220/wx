$(function(){
	alert("1")
	$.ajax()
	$(".book_fen>ul>li>select").click(function(){
		
		var vlue=$(this).find("option:selected").text();
		console.log(vlue)
		
	})
	
	
	
	
	
})
