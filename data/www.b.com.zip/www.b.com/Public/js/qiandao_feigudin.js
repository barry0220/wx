
$(function(){
	$(".header>div").click(function(){
	$(this).attr("class","div_dian").siblings().attr("class"," ")
	
	var  zhi = $(this).text()
	$.ajax({
		"type": "post",
		"url": "http://app.gymbaby.cn/Home/jiaoshi",
		"dataType": "json",
		"data":{
			"centre_id":"MczxYp5h"+","+"226"
		},
		success: function(data){
			$(".center").append(data)
		}
	});

	$(".book_fen").html(zhi)
	
	
})
})