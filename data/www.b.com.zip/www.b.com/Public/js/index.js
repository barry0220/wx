/**
 * Created by Administrator on 2017-03-20.
 */
var take1="off"
$('.jiaow-l').click(function () {
    if(take1=="off"){
        $('.jiaowu').css("height","300px");
        $('.jiaowu-list').css('display','block');
        take1="on";

    }else {

        $('.jiaowu').css("height", "80px");
        $('.jiaowu-list').css('display', 'none')
        take1 = "off";

    }
})

$('.pk-list1').click(function () {
    $('.paike').css('display','block');
    $('.kbchaxun').css('display','none');
});
$('.pk-list2').click(function () {
    $('.paike').css('display','none');
    $('.kbchaxun').css('display','block');
})
$(".chongzhi").click(function () {
    $(".chongzhikc").css("display","block")
})
/*取消重置课程运行*/
$(".quxiao").click(function () {
    $(".chongzhikc").css("display","none");
})
/*取消重置课程运行*/
/*确认时间段课程运行*/
$(".queren").click(function () {
    alert(1)
   $(".chongzhikc").css("display","none")
})
/*确认时间段课程运行*/
$(".tjia").click(function () {
    var str=""


    var str2="<div style='width: 927px;'>"
       + "<div>"
        +"<select style='margin-left:20px ;margin-top: 15px;border-radius:2px;width: 140px;height: 20px '>"
        +"<option selected='selected'>LIFE&nbsp;英语 LI</option>"
    +"<option></option>"
    +"<option></option>"
    +"<option></option>"
    +"</select> <br>"
    +"<select  style='margin-left:20px ;margin-top: 15px;border-radius:2px;width:90px;height: 20px '>"
       +"<option selected='selected'>张琪</option>"
        +"<option></option>"
        +"<option></option>"
        +"<option></option>"
        +"</select> <span style='margin-left: 2px'>2-6个月</span>"
        +"</div>"
    +"<div>"
        +"<select style='margin-left:20px ;margin-top: 15px;border-radius:2px;width: 140px;height: 20px '>"
        +"<option selected='selected'>LIFE&nbsp;英语 LI</option>"
        +"<option></option>"
        +"<option></option>"
        +"<option></option>"
        +"</select> <br>"
        +"<select  style='margin-left:20px ;margin-top: 15px;border-radius:2px;width:90px;height: 20px '>"
        +"<option selected='selected'>张琪</option>"
        +"<option></option>"
        +"<option></option>"
        +"<option></option>"
        +"</select> <span style='margin-left: 2px'>2-6个月</span>"
        +"</div>"
        +"<div>"
        +"<select style='margin-left:20px ;margin-top: 15px;border-radius:2px;width: 140px;height: 20px '>"
        +"<option selected='selected'>LIFE&nbsp;英语 LI</option>"
        +"<option></option>"
        +"<option></option>"
        +"<option></option>"
        +"</select> <br>"
        +"<select  style='margin-left:20px ;margin-top: 15px;border-radius:2px;width:90px;height: 20px '>"
        +"<option selected='selected'>张琪</option>"
        +"<option></option>"
        +"<option></option>"
        +"<option></option>"
        +"</select> <span style='margin-left: 2px'>2-6个月</span>"
        +"</div>"
        +"<div>"
        +"<select style='margin-left:20px ;margin-top: 15px;border-radius:2px;width: 140px;height: 20px '>"
        +"<option selected='selected'>LIFE&nbsp;英语 LI</option>"
        +"<option></option>"
        +"<option></option>"
        +"<option></option>"
        +"</select> <br>"
        +"<select  style='margin-left:20px ;margin-top: 15px;border-radius:2px;width:90px;height: 20px '>"
        +"<option selected='selected'>张琪</option>"
        +"<option></option>"
        +"<option></option>"
        +"<option></option>"
        +"</select> <span style='margin-left: 2px'>2-6个月</span>"
        +"</div>"
         +"</div>"
        ;
    str+=str2
$(".xuanke").append(str);
    var str3="";
    var str="<div style='margin-top: 50px'>"
    +"上午"
    +"<select>"
    +"<option selected='selected' ></option>"
        +"<option>周一</option>"
        +"<option>周二</option>"
        +"<option>周三</option>"
        +"</select> <br>"

        +"下午"
        +"<select style='margin-top: 15px'>"
        +"<option selected='selected'></option>"
        +"<option>周一</option>"
        +"<option>周二</option>"
        +"<option>周三</option>"
        +"</select>"
        +"</div>"
    str3+=str;
$(".time-pk").append(str3)

});
$('.ss').click(function () {
    $('.xingqi').removeClass("active");
    if($(this).hasClass("active")){
        $(this).removeClass("active");
    }else{
        $(this).addClass("active");
    }
})