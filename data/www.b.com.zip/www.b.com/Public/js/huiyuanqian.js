/**
 * Created by Administrator on 2017-10-23.
 */
 // var lujing=location.href;
 // var arr=lujing.split("uuid=");
 // var uuidj= arr[1].split("%27");
 // alert(uuidj)
 // console.log(uuidj)
// var uid='';
var kshi=null;
var youhuiq=null;
$(function () {
    $.ajax({
            "type": "post",
            "url": "http://www.b.com/users/kes",
            "dataType": "json",
            "data": {
            },
            success: function (data) {
                console.log(data)
                var str='';
                for(var i=0;i<data.length;i++){
                   str+='<option value="'+data[i].s_id+'">'+data[i].s_name+'</option>'
                }
            /*    youhuiq
                xiaosr*/
                $('#keshi').append(str)

            }
        });

    $.ajax({
        "type": "post",
        "url": "http://www.b.com/users/yhj",
        "dataType": "json",
        "data": {
        },
        success: function (data) {
            var str=''
            for(var i=0;i<data.length;i++){
                str+='<option pri="'+data[i].price+'" value="'+data[i].s_id+'">'+data[i].s_name+'</option>'
            }
            /* xiaosr*/
           $('#youhuiq').append(str);
        }
    });
if(uid!=0){
    $.ajax({
        "type": "post",
        "url": "http://www.b.com/users/xianx",
        "dataType": "json",
        "data": {
            "user_id": uid
        },
        success: function (data) {
            $('.zhutiBox').css('display','block')

            $('#xingm1').html(data.baobao_name);
            $('#xingm2').html(data.baobao_name2);
            $('#huisex').html(data.baobao_sex);
            $('#mamName').html(data.name2);
            $('#huiphone').html(data.phone);
            $('#huika').html(data.kahao);
            $('#huidizhi').html(data.site);
            $('#huibir').html(data.baobao_birthday);
            $('.cropped').html('<img class="touxiang" style="width: 100%;height: auto" src="'+data.img+'" alt="">')
        }
    })
}


    $.ajax({
        "type": "post",
        "url": "http://www.b.com/users/xsr",
        "dataType": "json",
        "data": {
        },
        success: function (data) {

          var str=''
            for(var i=0;i<data.length;i++){
                str+='<option pri="'+data[i].user_id+'" value="'+data[i].user_id+'">'+data[i].username+'</option>'
            }
            $('#xiaosr').append(str)
        }
    });

    /*课时包改变时的计算金额start*/
    $('#keshi').change(function () {

        kshi=$('#keshi').val();
        $.ajax({
            "type": "post",
            "url": "http://www.b.com/users/jia",
            "dataType": "json",
            "data": {
                's_id':$(this).val()
            },
            success: function (data) {
               console.log(data);

                $('#xiaoshouj').html('￥'+data.price);
                $('#y_keshi').val(data.k_shu)
            }
        });
        youhuiq=$('#youhuiq').val();
       /* alert(kshi);
        alert(youhuiq);*/
        $.ajax({
            "type": "post",
            "url": "http://www.b.com/users/jine",
            "dataType": "json",
            "data": {
                'money':kshi,
                's_id':youhuiq
            },
            success: function (data) {


          $('#yings').html(data)
            }
        })


    })
    /*课时包改变时的计算金额end*/

    /*优惠券改变时的计算金额start*/
    $('#youhuiq').change(function () {
        /*alert(kshi);*/
        youhuiq=$('#youhuiq').val();
        /*alert(youhuiq);*/
        $.ajax({
            "type": "post",
            "url": "http://www.b.com/users/jine",
            "dataType": "json",
            "data": {
                'money':kshi,
                's_id':youhuiq
            },
            success: function (data) {
                console.log(data);
                $('#yings').html(data)
            }
        })

    })
    /*优惠券改变时的计算金额end*/

    /*更改头像start*/

    var options =
    {
        thumbBox: '.thumbBox',
        spinner: '.spinner',
        imgSrc: 'img/avatar.png'
    }
    var cropper = $('.imageBox').cropbox(options);
    $('#file').on('change', function () {
        var reader = new FileReader();
        reader.onload = function (e) {
            options.imgSrc = e.target.result;
            cropper = $('.imageBox').cropbox(options);
        }
        reader.readAsDataURL(this.files[0]);
        this.files =null;
    })
    $('#btnCrop').on('click', function () {
        var img = cropper.getDataURL();
        $('.cropped').html('<img src="' + img + '">');
      /*alert(uid)*/
        $.ajax({
            "type": "post",
            "url": "http://www.b.com/users/tonx",
            "dataType": "json",
            "data": {
                "img": img,
                "user_id":uid
            },
            success: function (data) {
                if(data==1){
                    $('#myModal').hide()
                }


            }

        })


    });
    /*	$('#btnZoomIn').on('click', function () {
     cropper.zoomIn();
     })
     $('#btnZoomOut').on('click', function () {
     cropper.zoomOut();
     })*/

    /*更改头像end*/






})



/*点击名字搜索start*/
function sousuo(obj) {
    uid=$(obj).attr('uid');
    /*alert(uid)*/
    $('#suosuok').hide();
   /* alert($(obj).html());*/
 var cc= $(obj).find('.daming').html();
    $('#suo').val(cc);
    $.ajax({
        "type": "post",
        "url": "http://www.b.com/users/xianx",
        "dataType": "json",
        "data": {
            "user_id": uid
        },
        success: function (data) {
            $('.zhutiBox').css('display','block')

            $('#xingm1').html(data.baobao_name);
            $('#xingm2').html(data.baobao_name2);
            $('#huisex').html(data.baobao_sex);
            $('#mamName').html(data.name2);
            $('#huiphone').html(data.phone);
            $('#huika').html(data.kahao);
            $('#huidizhi').html(data.site);
            $('#huibir').html(data.baobao_birthday);
            $('.cropped').html('<img class="touxiang" style="width: 100%;height: auto" src="'+data.img+'" alt="">')
        }
    })



}
/*点击名字搜索start*/

$('#suo').keyup(function () {
    if($(this).val()!=''){
        var name=$('#suo').val();
       /* console.log(name)*/
        $.ajax({
            "type": "post",
            "url": "http://www.b.com/users/sou",
            "dataType": "json",
            "data": {
                "username":name
            },
            success: function (data) {
               /* console.log(data);*/
                var str='';
                for(var i=0;i<data.length;i++){
                    str+='<li uid="'+data[i].user_id+'" onclick="sousuo(this)" class="clearfloat"><span class="dam daming">'+data[i].baobao_name+'</span> <span class="dam">'+data[i].baobao_name2+'</span></li>'
                }
                $('#suosuok').html(str)
            }
        });
        $('#suosuok').show()
    }else {
        $('#suosuok').hide()
    }
});

$('#tianjH').click(function () {

if($('#hetong').val()==''){
    alert('合同编号不能为空');
    return false;
}
if($('#keshi').val()==''){
    alert('课时包不能为空');
    return false;
}
    if($('#start_time').val()==''){
        alert('合约开始时间不能为空');
        return false;
    }
    if($('#shishou').val()==''){
        alert('实收金额不能为空');
        return false;
    }
    var type = $('#heyu input[name="he"]:checked').val();
    $.ajax({
        "type": "post",
        "url": "http://www.b.com/users/addhy",
        "dataType": "json",
        "data": {
            "user_id": uid,
            "hetong": $('#hetong').val(),
            "dindan": $('#dindan').val(),
            "s_id":$('#keshi').val(),
            "you":$('#youhuiq').val(),
            "start_time":$('#start_time').val(),
            "end_time":$('#end_time').val(),
            "zeng_ke":$('#zeng_ke').val(),
            "yingshou":$('#yings').html(),
            "shishou":$('#shishou').val(),
            "y_keshi":$('#y_keshi').val(),
            "guwen":$('#xiaosr').val(),
            "bz":$('#bz').val(),
            "type":type
        },
        success: function (data) {
            if(data==2){
                alert('合同号已存在')
            }else{
               /* alert("恭喜添加成功！");*/
                $('#qianyuet').modal({"backdrop":"static"});
                $('#tianzhu').attr('href',"huiyuanlieb?id="+uid)
             /*   juzzhong("#qianyuet");
                function juzzhong(aa) {
                    var $modal_dialog = $(aa).find('.modal-dialog');
                    var clientHeight=$(window).height();
                    var dialogHeight= $modal_dialog.height();
                    console.log(clientHeight,dialogHeight)
                    var m_top = (clientHeight - dialogHeight)/2;
                    $modal_dialog.find(".modal-content").css({'margin': m_top + 'px auto 0'});
                }*/

                /*location.reload();*/
            }
        }
    })


    
    
})

