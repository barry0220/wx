/**
 * Created by Administrator on 2017-10-20.
 */
/*liebiao*/
var zongye=0;
var status=$('#jkl').val();
var p=1;
 function huiche(event) {
        if(event.keyCode==13){
            search()
        }
    }
$(function () {
    /*会员是1；非会员为0*/
    $.ajax({
        "type": "post",
        "url": "http://www.b.com/users/user",
        "dataType": "json",
        "data": {
            "status":status
        },
        success: function (data) {
            console.log(data);
            zongye=data[0].pagetotal;
            $('#numm').html("共有"+data[0].num+"条记录&nbsp;&nbsp;当前1页/共"+data[0].pagetotal+"页")
            var str='';
            for(var i=0;i<data.length;i++){
                if(data[i].baobao_name==null){
                    data[i].baobao_name=''
                }
                if(data[i].baobao_sex==null){
                    data[i].baobao_sex=''
                }
                if(data[i].baobao_name2==null){
                    data[i].baobao_name2=''
                }
                if(data[i].yueling==null){
                    data[i].yueling=''
                }
                if(data[i].y_keshi==null){
                    data[i].y_keshi=''
                }
                if(data[i].create_time==null){
                    data[i].create_time=''
                }
                if(data[i].e_time==null){
                    data[i].e_time=''
                }
                if(data[i].name2==null){
                    data[i].name2=''
                }
                if(data[i].phone2==null){
                    data[i].phone2=''
                }
                if(data[i].vip==1){
                    data[i].vip="会员"
                }else{
                    data[i].vip="非会员"
                }
                str+=' <tr onclick="xq('+data[i].user_id+')">' +
                    '<td>'+data[i].baobao_name+'</td>' +
                    '<td>'+data[i].baobao_sex+'</td>' +
                    '<td>'+data[i].baobao_name2+'</td>' +
                    '<td>'+data[i].yueling+'</td>' +
                    '<td>'+data[i].y_keshi+'</td>' +
                    // '<td>'+data[i].create_time+'</td>' +
                    '<td>'+data[i].e_time+'</td>' +
                    '<td>'+data[i].name2+'</td>' +
                    '<td>'+data[i].phone2+'</td>' +
                    '<td>'+data[i].vip+'</td>' +
                    '<td><a href="/Home/User/xiu?user_id='+data[i].user_id+'">修改 | </a>'+
                    '<a href="" onclick="shanchu('+data[i].user_id+')">删除</a>'+
                    '</td>' +
                    '</tr>'
            }
            var str2='';
            for(var i=0;i<data[0].pagetotal;i++){
               var aa=Number(i)+1;
                str2+='<option value="'+aa+'">'+aa+'</option>'
            }
            $('#ye').html(str2);
            $('#liebiao').html(str)
        }
    })
});
$("#shouye").click(function () {
    status=$('#jkl').val();
    p=1;
    tiaoye()
})
$("#shangye").click(function () {
    status=$('#jkl').val();
    if(p>1){
        p--;
        tiaoye()
    }else {
        alert("已经到第一页了");
        return false;
    }
});

$('#xiaye').click(function () {
    status=$('#jkl').val();
        if(p<zongye){
            p++;
            tiaoye()
        }else {
            alert("已经到最后一页了");
            return false;
        }
    });
$('#tiaoye').click(function () {
    status=$('#jkl').val();
    p=$('#ye').val();
    tiaoye()
})
$("#weiye").click(function () {
    status=$('#jkl').val();
  p=zongye;
    tiaoye()
});
function tiaoye() {
    status=$('#jkl').val();
    $.ajax({
        "type": "post",
        "url": "http://www.b.com/users/user",
        "dataType": "json",
        "data": {
            "p":p,
            "zhi":$('#suo').val(),
            "status": status
        },
        success: function (data) {
            $('#numm').html("共有"+data[0].num+"条记录&nbsp;&nbsp;当前"+data[0].page+"页/共"+data[0].pagetotal+"页")
            var str=''
            for(var i=0;i<data.length;i++){
                if(data[i].baobao_name==null){
                    data[i].baobao_name=''
                }
                if(data[i].baobao_sex==null){
                    data[i].baobao_sex=''
                }
                if(data[i].baobao_name2==null){
                    data[i].baobao_name2=''
                }
                if(data[i].yueling==null){
                    data[i].yueling=''
                }
                if(data[i].y_keshi==null){
                    data[i].y_keshi=''
                }
                if(data[i].create_time==null){
                    data[i].create_time=''
                }
                if(data[i].e_time==null){
                    data[i].e_time=''
                }
                if(data[i].name2==null){
                    data[i].name2=''
                }
                if(data[i].phone2==null){
                    data[i].phone2=''
                }
                if(data[i].vip==1){
                    data[i].vip="会员"
                }else{
                    data[i].vip="非会员"
                }
                str+=' <tr onclick="xq('+data[i].user_id+')">' +
                    '<td>'+data[i].baobao_name+'</td>' +
                    '<td>'+data[i].baobao_sex+'</td>' +
                    '<td>'+data[i].baobao_name2+'</td>' +
                    '<td>'+data[i].yueling+'</td>' +
                    '<td>'+data[i].y_keshi+'</td>' +
                    // '<td>'+data[i].create_time+'</td>' +
                    '<td>'+data[i].e_time+'</td>' +
                    '<td>'+data[i].name2+'</td>' +
                    '<td>'+data[i].phone2+'</td>' +
                    '<td>'+data[i].vip+'</td>' +
                    '<td><a href="/Home/User/xiu?user_id='+data[i].user_id+'">修改 | </a>'+
                    '<a href="" onclick="shanchu('+data[i].user_id+')">删除</a>'+
                    '</td>' +
                    '</tr>'
            }
            var str2='';
            for(var i=0;i<data[0].pagetotal;i++){
                var aa=Number(i)+1;
                str2+='<option value="'+aa+'">'+aa+'</option>'
            }
            $('#ye').html(str2);
            for(var i=0;i<$('#ye option').length;i++){
                if($('#ye option').eq(i).val()==p){
                    $('#ye option').eq(i).attr("selected",true);
                }
            }
            $('#liebiao').html(str)
        }
    })
}
function search() {
    status=$('#jkl').val();
     $.ajax({
         "type": "post",
         "url": "http://www.b.com/users/user",
         "dataType": "json",
         "data": {
             "status":status,
             "zhi":$('#suo').val()
         },
         success: function (data) {
              console.log(data);
             if(data!=''){
                 zongye=data[0].pagetotal;
                 $('#numm').html("共有"+data[0].num+"条记录&nbsp;&nbsp;当前1页/共"+data[0].pagetotal+"页")
                 var str='';
                 for(var i=0;i<data.length;i++){
                     if(data[i].baobao_name==null){
                    data[i].baobao_name=''
                }
                if(data[i].baobao_sex==null){
                    data[i].baobao_sex=''
                }
                if(data[i].baobao_name2==null){
                    data[i].baobao_name2=''
                }
                if(data[i].yueling==null){
                    data[i].yueling=''
                }
                if(data[i].y_keshi==null){
                    data[i].y_keshi=''
                }
                if(data[i].create_time==null){
                    data[i].create_time=''
                }
                if(data[i].e_time==null){
                    data[i].e_time=''
                }
                if(data[i].name2==null){
                    data[i].name2=''
                }
                if(data[i].phone2==null){
                    data[i].phone2=''
                }
                if(data[i].vip==1){
                    data[i].vip="会员"
                }else{
                    data[i].vip="非会员"
                }
                     str+=' <tr onclick="xq('+data[i].user_id+')">' +
                         '<td>'+data[i].baobao_name+'</td>' +
                         '<td>'+data[i].baobao_sex+'</td>' +
                         '<td>'+data[i].baobao_name2+'</td>' +
                         '<td>'+data[i].yueling+'</td>' +
                         '<td>'+data[i].y_keshi+'</td>' +
                         // '<td>'+data[i].create_time+'</td>' +
                         '<td>'+data[i].e_time+'</td>' +
                         '<td>'+data[i].name2+'</td>' +
                         '<td>'+data[i].phone2+'</td>' +
                         '<td>'+data[i].vip+'</td>' +
                         '<td><a href="/Home/User/xiu?user_id='+data[i].user_id+'">修改 | </a>'+
                    '<a href="" onclick="shanchu('+data[i].user_id+')">删除</a>'+
                    '</td>' +
                         '</tr>'
                 }
                 var str2='';
                 for(var i=0;i<data[0].pagetotal;i++){
                     var aa=Number(i)+1;
                     str2+='<option value="'+aa+'">'+aa+'</option>'
                 }
                 $('#ye').html(str2);
                 $('#liebiao').html(str)
             }else{
                 $('#numm').html("没有相关数据")
                 $('#ye').html('');
                 $('#liebiao').html('')
             }
         }
     })
}
function shanchu(user_id){
    var result=confirm("确认要删除吗");
    if(result){
      $.ajax({
        url:"http://www.b.com/Home/Users/shanchu",
                type:"post",
                async:false,
                data:{"user_id":user_id},
                success:function(e){
                  if(e==1){
                    obj.parentNode.parentNode.remove();
                  }
        }
      })
    }
}
function xq(user_id){
        location.href='http://www.b.com/Home/User/huiyuanlieb?id='+user_id;
    }
