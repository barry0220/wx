/**
 * Created by Administrator on 2017-04-21.
 */
$('.yuy').click(function () {
  /*
    alert($(this).index())*/
    $('.xinxi').css('display','block')
    $('.xinxi>.yuyue').css('background','#64a9ec')

})

$('.yuyue').click(function () {
    $(this).css('background','#b3b3b3')
});