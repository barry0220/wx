/**
 * Created by Administrator on 2017-10-20.
 */


function diqu(obj,ao) {
    var shengid=$(obj).val();
    $.ajax({
        "type": "post",
        "url": "http://www.b.com/users/sel_coun",
        "dataType": "json",
        "data": {
            "coun":shengid
        },
        success: function (data) {
            console.log(data);
            var str='';
            for(var i=0;i<data.length;i++){
                str+='<option value="'+data[i].REGION_ID+'" onclick="sheng(this)">'+data[i].REGION_NAME+'</option>'
            }
            $(ao).html(str)
        }
    })
}


var a=0;

$('#jia').click(function () {

    var str='<div class="row zengjiaguanxi"   style="margin-top: 10px">' +
        '<div class="col-sm-3">' +
        '<div class="clearfloat">' +
        '<p class="listLeft"><i class="xing">*</i><span class="ListIntr fon18">关系</span></p>' +
        '<select name="guanxi[]"  class="huixinp" >' +
        '<option value="1">爸爸</option>' +
        '<option value="2">妈妈</option>' +
        '<option value="3">爷爷</option>' +
        '<option value="4">奶奶</option>' +
        '<option value="5">其他</option>' +
        '</select>' +
        '</div>' +
        '</div>' +
        '<div class="col-sm-3">' +
        '<div class="clearfloat">' +
        '<p class="listLeft"><i class="xing">*</i><span class="ListIntr fon18">姓名</span></p>' +
        '<input name="name[]" required class="huixinp" type="text">' +
        '</div>' +
        '</div>' +
        '<div class="col-sm-6">' +
        '<div class="clearfloat">' +
        '<p class="listLeft" style="width: 20%"><i class="xing">*</i><span class="ListIntr fon18">联系电话</span></p>' +
        '<input name="phone[]" maxlength="11" onkeypress="return event.keyCode>=48&&event.keyCode<=57" ng-pattern="/[^a-zA-Z]/" required class="huixinp" style="width: 19%" type="text">' +
        '<img style="width: 20px;height: 20px;margin-left: 14px" onclick="jian(this)" src="http://www.b.com/Public/img/system/tixing.png" alt="">' +
        '</div>' +
        '</div>' +
        '</div>'
    if(a<4&&a>=0){
        a++;
        $('.tianjialixi').append(str)

    }else {
        a=4;
        return false
    }

});
function jian(obj) {
    if(a<=4&&a>0){
        a--
    }else {
        a=0
    }
    /* alert(111);*/
    $(obj).parents('.zengjiaguanxi').remove()
}

$(function () {
    $.ajax({
            "type": "post",
            "url": "http://www.b.com/users/dq",
            "dataType": "json",
            "data": {},
            success: function (data) {

                /*REGION_ID*/
                var str='<option>请选择</option>';
                for(var i=0;i<data.length;i++){
                    str+='<option value="'+data[i].REGION_ID+'" >'+data[i].REGION_NAME+'</option>'
                }
                $('#sheng').html(str);
               /* <option value="">北京市</option>*/
            }
        })

})
