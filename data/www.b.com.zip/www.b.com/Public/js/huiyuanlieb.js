/**
 * Created by Administrator on 2017-07-07.
 */


var imgurl = "";
function getPhoto(node) {
    var imgURL = "";
    try{
        var file = null;
        if(node.files && node.files[0] ){
            file = node.files[0];
        }else if(node.files && node.files.item(0)) {
            file = node.files.item(0);
        }
        //Firefox 因安全性问题已无法直接通过input[file].value 获取完整的文件路径
        try{
            imgURL =  file.getAsDataURL();
        }catch(e){
            imgRUL = window.URL.createObjectURL(file);
        }
    }catch(e){
        if (node.files && node.files[0]) {
            var reader = new FileReader();
            reader.onload = function (e) {
                imgURL = e.target.result;
            };
            reader.readAsDataURL(node.files[0]);
        }
    }
    creatImg(imgRUL);
    return imgURL;
}

function creatImg(imgRUL){
    var textHtml = "<img class='touxiang' src='"+imgRUL+"' style='width: 100%;'/>";
    $(".ge_pic_icon_Infor").html(textHtml);
}

$('.zhengSF').change(function () {
// alert(1);
    $('.zhengS').submit()
})


$(function () {


    //${pageContext.request.contextPath}/
    url = "https://crm.gymbaby.cn/dxfsjl";
    $.ajax({
        url : url,
        type : "post",
        dateType : "json",
        success : function(data) {
            if(!data.length){
                $('.tbody1').html('')
            }
            var tiaoshu=5;
            var page1=0;
            fenye1(data,page1);
            $('.shouye1').click(function () {
                page1=0;
                fenye1(data,page1);
            });

            $('.shangye').click(function () {
                if(page1>1){
                    page1--;
                }else {
                    page1=0;
                }
                fenye1(data,page1)
            });
            $('.weiye').click(function () {
                var zongye=Math.ceil(data.length/tiaoshu);
                page1=zongye-1;
                fenye1(data,page1)
            });

            $('.fxiaye').click(function() {
                var zongye=Math.ceil(data.length/tiaoshu);
                if(page1<zongye-1){
                    page1++;
                }else {
                    page1=zongye-1;
                }
                console.log(page1)
                fenye1(data,page1)
            });

            $('.tiaozhuan').click(function () {
                page1=$('.xuanyeq').val()-1;
                fenye1(data,page1)

            });

            function fenye1(data,page1) {
                var a=tiaoshu*page1;
                var b=a+tiaoshu;
                if(b>=data.length){
                    b=data.length
                }
                var str='';
                for(var i=a;i<b;i++){
                    var tz=i+1;
                    str+="<tr>"
                        +"<td style='text-align: center'>"+tz+"</td>"
                        +"<td style='text-align: center'>"+data[i].baobao_name+"</td>"
                        +"<td style='text-align: center'>"+data[i].phone+"</td>"
                        +"<td style='text-align: center'>"+data[i].create_time+"</td>"
                        +"<td style='text-align: center'>"+data[i].mb_type+"</td>"
                        +"<td style='text-align: center'>"+data[i].status+"</td>"
                        +"<td style='text-align: center'>"+data[i].type+"</td>"
                        +"</tr>"
                }
                $('.tbody1').html(str)
            }
            var str2='';
            var zongye=Math.ceil(data.length/tiaoshu)
            for (var k=0;k<zongye;k++){
                var numYs=k+1
                str2+='<option value="'+numYs+'">'+numYs+'</option>'
            }
            $('.xuanyeq').html(str2);
            var ztnum=data.length;
            $('.zongtiaoshu').html('共'+ztnum+'条记录')

        }

    });
})














