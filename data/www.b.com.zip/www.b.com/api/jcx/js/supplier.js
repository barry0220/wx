$(function  () {
	supplier();
	var zongye="";
	var p=1;
	var str='';
	var search = $('#suo').val();
//	分页跳页
	$("#shouyes").on("click",function(){
	    p=1;
	    supplier();
	})
	$("#shangyes").click(function () {	
	    if(p>1){
	        p--;
	        supplier()
	    }else {
	        alert("已经到第一页了");
	        return false;
	    }
	});
	
	$('#xiayes').click(function () {
	    if(p<zongye){
	        p++;
	        supplier()
	    }else {
	        alert("已经到最后一页了");
	        return false;
	    }
	    });
	$('#tiaoyes').click(function () {
	    status=$('#jkl').val();
	    p=$('#ye').val();
	    supplier()
	})
	$("#weiyes").click(function () {    
		p=zongye;
	    supplier()
	});
   //数据展示
	function supplier() {
	    $.ajax({
	        "type": "post",
	        "url": "http://www.b.com/JxcSupplier/index",
	        "dataType": "json",
	        "data": {page:p,pageone:4,search:search},
	        success: function (e) {
	        	console.log(e);
	        	var str='';
	        	var str2='';
	            if(!e.data){
	                str = "<tr><td colspan='11'>没有查找到数据!</td></tr>";
	                str2='<option value="0">0</option>'
	                $('#nums').html("");
	            }else{        	
	        	console.log(p);
	        	zongye=e.map.pagetotal;
	            $('#nums').html("共有"+e.data.length+"条记录&nbsp;&nbsp;当前"+e.map.page+"页/共"+e.map.pagetotal+"页");			
	            for(var i=0;i<e.data.length;i++){
	                str+='<tr ondblclick="doshow(11)">'+
                            '<td>'+i+'</td>'+
                            '<td>'+e.data[i].supplier_num+'</td>'+
                            '<td>'+e.data[i].supplier_name+ '</td>'+
                            '<td>'+e.data[i].tel+'</td>'+
                            '<td>'+e.data[i].linkman+'</td>'+
                            '<td>'+e.data[i].phone+'</td>'+
                            '<td class="center">'+e.data[i].create_time+'</td>'+
                            '<td class="center">'+
                               '<a class="bun-ck" onclick="ck('+e.data[i].id+',this)">查看   </a>| '+
                               '<a class="bun-xg" onclick="xg('+e.data[i].id+',this)">修改   </a>| '+
                               '<a class="" href="javascript:void(0)" onclick="sc('+e.data[i].id+',this)">删除</a>'+
                            '</td>'+
                        '</tr>'
	            }            
	            for(var i=0;i<e.map.pagetotal;i++){
	                var aa=Number(i)+1;
	                str2+='<option value="'+aa+'">'+aa+'</option>'
	            }
	            $('#ye').html(str2);
	            for(var i=0;i<$('#ye option').length;i++){
	                if($('#ye option').eq(i).val()==p){
	                    $('#ye option').eq(i).attr("selected",true);
	                }
	            }
	            $('.table tbody').html(str)
	            }
	        }
	    })
	}
	//查询供应商
	    $("#xmjs").click(function () {
	        search = $('#suo').val();
	        supplier();
	    });

});

//删除数据
   function sc(id,obj){
    var result=confirm("确认要删除吗");
    if(result){
      $.ajax({
        url:"http://www.b.com/JxcSupplier/delete",
        type:"post",
        async:false,
        data:{"id":id},
        success:function(e){
          if(e.status == 2){
            obj.parentNode.parentNode.remove();
          }else if (e.status == 1){
              alert('删除失败');
          }
        }
      })
    }
   }	


