$(function () {
    var zongye=0;
    var p=1;
    var search = $('#suo').val();
    var typeid = $('#typeid').val();
    var supplier_id = $('#supplierid').val();
    var arr = {'search':search,'typeid':typeid,'supplierid':supplier_id,'pageone':4,'page':p};
    getGoods();
//	分页跳页
	$("#shouyes").on("click",function(){
	    p=1;
	    getGoods();
	})
	$("#shangyes").click(function () {	
	    if(p>1){
	        p--;
	        getGoods()
	    }else {
	        alert("已经到第一页了");
	        return false;
	    }
	});	
	$('#xiayes').click(function () {
        if(p<zongye){
            p++;
            getGoods();
        }else {
            alert("已经到最后一页了");
            return false;
        }
    });
	$('#tiaoyes').click(function () {
	    status=$('#jkl').val();
	    p=$('#ye').val();
	    getGoods()
	})
	$("#weiyes").click(function () {    
		p=zongye;
	    getGoods()
	});
//  查询商品   
    $("#xmjs").click(function () {
        arr.typeid = $('#typeid').val();
        arr.supplierid = $('#supplierid').val();
        arr.search = $('#suo').val();
        getGoods();
    });
    
//  数据展示
	function getGoods(){
//	    console.log(arr);
	    arr.page = p;
	    $.ajax({
	        "url": "http://www.b.com/JxcGoods/index",
	        "type": "post",
	        "dataType": "json",
	        "data": {map:arr},
	        success: function (e) {
//	            console.log(e);
	            var str='';
	            var str2='';
//	            console.log(e);
	            if(!e.data){
	                str = "<tr><td colspan='11'>没有查找到数据!</td></tr>";
	                str2='<option value="0">0</option>'
	                $('#nums').html("");
	            }else{
	                zongye=e.map.pagetotal;
	                $('#nums').html("共有"+e.data.length+"条记录&nbsp;&nbsp;当前"+e.map.page+"页/共"+e.map.pagetotal+"页");
	                for(var i=0;i<e.data.length;i++){
	                    str+='<tr>' +
	                        '<td>'+(i+1)+'</td>'+
	                        '<td>'+e.data[i].good_num+'</td>'+
	                        '<td class="center">'+e.data[i].good_name+'</td>'+
	                        '<td>'+e.data[i].type_name+'</td>'+
	                        '<td class="center">'+e.data[i].spec+'</td>'+
	                        '<td class="center">'+e.data[i].unit+'</td>'+
	                        '<td >'+
	                        '<div style="position: relative;">'+
	                        '<img  height="26px" src="'+e.data[i].mini_imgpath+'" alt="商品图片" onmouseover="$(this).next().css("display","")" onmouseout="$(this).next().css("display","none")">'+
	                        '<div style="display:none;position: absolute;z-index: 2;left:50px;top:-50px;"><img height="260px" src="'+e.data[i].imgpath+'" alt="商品图片"></div>'+
	                        '</div>'+
	                        '</td>'+
	                        '<td class="center">'+e.data[i].cost_price+'</td>'+
	                        '<td class="center">'+e.data[i].purchase_price+'</td>'+
	                        '<td class="center">'+e.data[i].real_price+'</td>'+
	                        '<td class="center">'+
	                        '<a class="bun-ck" onclick="ck('+e.data[i].id+',this)">查看    </a>| '+
	                        '<a class="bun-xg" onclick="xg('+e.data[i].id+',this)">修改    </a>| '+
	                        '<a class=" " href="javascript:void(0)" onclick="sc('+e.data[i].id+',this)">删除</a>'+
	                        '</td>'+
	                        '</tr>'
	                }
	
	                for(var i=0;i<e.map.pagetotal;i++){
	                    var aa=Number(i)+1;
	                    str2+='<option value="'+aa+'">'+aa+'</option>'
	                }
	            }
	            $('#ye').html(str2);
	            $('.table tbody').html(str)
	        },
	        error:function(e){
//	            console.log(e)
	        }
	    })
	}

});


//删除数据
   function sc(id,obj){
    var result=confirm("确认要删除吗");
    if(result){
      $.ajax({
        url:"http://www.b.com/JxcGoods/delete",
        type:"post",
        async:false,
        data:{"id":id},
        success:function(e){
          if(e.status == 2){
            obj.parentNode.parentNode.remove();
          }else if (e.status == 1){
              alert('删除失败');
          }
        }
      })
    }
   }
