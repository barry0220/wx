$(function () {
    var zongye=0;
    var types="";
    var use="";
    var bu="";
    var p=1;
    var search = $('#suo').val();
    var typeid = $('#typeid').val();
    var isuse = $('#isuse').val();
    var arr = {'search':search,'type':typeid,'is_use':isuse,'pageone':4,'page':p,};
    storage();
//	分页跳页
	$("#shouyes").on("click",function(){
	    p=1;
	    storage();
	})
	$("#shangyes").click(function () {	
	    if(p>1){
	        p--;
	        storage()
	    }else {
	        alert("已经到第一页了");
	        return false;
	    }
	});	
	$('#xiayes').click(function () {
        if(p<zongye){
            p++;
            storage();
        }else {
            alert("已经到最后一页了");
            return false;
        }
    });
	$('#tiaoyes').click(function () {
	    status=$('#jkl').val();
	    p=$('#ye').val();
	    storage()
	})
	$("#weiyes").click(function () {    
		p=zongye;
	    storage()
	});
//  查询商品   
    $("#xmjs").click(function () {
	     arr.search = $('#suo').val();
	     arr.type = $('#typeid').val();
	     arr.is_use = $('#isuse').val();
	    console.log(arr);
       storage()
    });
    
//  数据展示
	function storage(){
	    console.log(arr);	
	    $.ajax({
	        "url": "http://www.b.com/JxcOutStorage/index",
	        "type": "post",
	        "dataType": "json",
	        "data": {map:arr},
	        success: function (e) {
	            console.log(e);
	            var str='';
	            var str2='';
//	            console.log(e);
	            if(!e.data){
	                str = "<tr><td colspan='11'>没有查找到数据!</td></tr>";
	                str2='<option value="0">0</option>'
	                $('#nums').html("");
	            }else{
	                zongye=e.map.pagetotal;
	                $('#nums').html("共有"+e.data.length+"条记录&nbsp;&nbsp;当前"+e.map.page+"页/共"+e.map.pagetotal+"页");
	                for(var i=0;i<e.data.length;i++){
	                	if(e.data[i].type==1){ types="出库"};
	                	if(e.data[i].type==2){ types="入库"};
	                	if(e.data[i].is_use==1){use="禁用",bu="启用" };
	                	if(e.data[i].is_use==2){use="启用",bu="禁用"};
	                    str+='<tr>'+
	                            '<td>'+e.data[i].id+'</td>'+
	                            '<td>'+e.data[i].name+' </td>'+
	                            '<td>'+types+'</td>'+
	                            '<td>'+use+'</td>'+
	                            '<td class="center">'+e.data[i].create_time+'</td>'+
	                            '<td class="center">'+
                                    '<a  onclick="ck1('+e.data[i].id+',this)">'+bu+'</a>|  '+
	                                '<a class="btn-xg" onclick="doedit(1)">修改   </a> | '+
	                                '<a class="btn-sc" href="javascript:void(0)" onclick="sc('+e.data[i].id+',this)">删除</a>'+
	                            '</td>'+
		                    '</tr> '
	                }
	
	                for(var i=0;i<e.map.pagetotal;i++){
	                    var aa=Number(i)+1;
	                    str2+='<option value="'+aa+'">'+aa+'</option>'
	                }
	            }
	            $('#ye').html(str2);
	            $('.table tbody').html(str)
	        },
	        error:function(e){
//	            console.log(e)
	        }
	    })
	}

});


//删除数据
   function sc(id,obj){
    var result=confirm("确认要删除吗");
    if(result){
      $.ajax({
        url:"http://www.b.com/JxcOutStorage/delete",
        type:"post",
        async:false,
        data:{"id":id},
        success:function(e){
          if(e.status == 2){
            obj.parentNode.parentNode.remove();
          }else if (e.status == 1){
              alert('删除失败');
          }
        }
      })
    }
   }
