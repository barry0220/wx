

$(function  () {
	express();
	var zongye="";
	var p=1;
	var str='';
	var search = $('#suo').val();
//	分页跳页
	$("#shouyes").on("click",function(){
	    p=1;
	    express();
	})
	$("#shangyes").click(function () {	
	    if(p>1){
	        p--;
	        express()
	    }else {
	        alert("已经到第一页了");
	        return false;
	    }
	});
	
	$('#xiayes').click(function () {
	    if(p<zongye){
	        p++;
	        express()
	    }else {
	        alert("已经到最后一页了");
	        return false;
	    }
	    });
	$('#tiaoyes').click(function () {
	    status=$('#jkl').val();
	    p=$('#ye').val();
	    express()
	})
	$("#weiyes").click(function () {    
		p=zongye;
	    express()
	});

	
	
	
   //数据展示
	function express() {
	    $.ajax({
	        "type": "post",
	        "url": "http://www.b.com/JxcExpress/index",
	        "dataType": "json",
	        "data": {page:p,pageone:4,search:search},
	        success: function (e) {
	        	console.log(e);
	        	var str='';
	        	var str2='';
	            if(e.data==null){
	                str = "<tr><td colspan='11'>没有查找到数据!</td></tr>";
	                str2='<option value="0">0</option>'
	                $('#nums').html("");
	            }else{        	
	        	console.log(p);
	        	zongye=e.map.pagetotal;
	            $('#nums').html("共有"+e.data.length+"条记录&nbsp;&nbsp;当前"+e.map.page+"页/共"+e.map.pagetotal+"页");			
	            for(var i=0;i<e.data.length;i++){
	                str+='<tr ondblclick="showupdate(this,1)">' +
	                    '<td>'+i+'</td>' +
	                    '<td>'+e.data[i].express_name+'</td>' +
	                    '<td>'+e.data[i].create_time+'</td>' +
	                    '<td><a onclick="showupdate(this,2)">修改 </a>| '+
	                    '<a href="javascript:void(0);" onclick="del('+e.data[i].id+',this)">删除</a>'+
	                    '</td>' +
	                    '</tr>'+
                        '<tr style="display:none; ">'+
                            '<td style="text-align: right;vertical-align: middle;"><span style="color:red;margin: 4px;">*</span>'+
                            '</td>'+
                            '<td><input value="'+e.data[i].express_name+'" name="express_name" class="form-control" required="" style="width: 120px;height:26px;padding: 0;position: relative" type="text">'+
                            '</td>'+
                            '<td><a onclick="taj('+e.data[i].id+',this)">保存修改 </a>'+
                            '</td>'+
                            '<td>'+' '+'</td>'+
                        '</tr>' 
	            }            
	            for(var i=0;i<e.map.pagetotal;i++){
	                var aa=Number(i)+1;
	                str2+='<option value="'+aa+'">'+aa+'</option>'
	            }
	            $('#ye').html(str2);
	            for(var i=0;i<$('#ye option').length;i++){
	                if($('#ye option').eq(i).val()==p){
	                    $('#ye option').eq(i).attr("selected",true);
	                }
	            }
	            
	            }
	        $('.table tbody').html(str)    
	        }
	        
	    })
	}
	//查询类别
	    $("#xmjs").click(function () {
	        search = $('#suo').val();
	        express();
	    });
	//添加数据
	 $("#button-name").click(function () { 
	   	var name=$("#button-a").val()
	    var result=confirm("确认要添加么吗");
	    if(result){    	 
	      $.ajax({
	        url:"http://www.b.com/JxcExpress/store",
	        type:"post",
	        async:false,
	        data:{express_name:name},
	        success:function(e){
	        	console.log(e.status);
	        	express();
	        }
	      })
	    }
	});  

});


 //删除数据
   function del(id,obj){
    var result=confirm("确认要删除吗？");
	if(result){
	  $.ajax({
	    url:"http://www.b.com/JxcExpress/delete",
	        type:"post",
            async:false,
            data:{id:id},
            success:function(e){
            	console.log(e);
              if(e.status == 2){
                obj.parentNode.parentNode.remove();
              }
	        }
	      })
	    }
	}	