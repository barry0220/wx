//$(function () {
//  /*会员是1；非会员为0*/
//  $.ajax({
//  	"url": "https://api.gymbaby.cn/xueyuan",
//      "type": "post",        
//      "dataType": "json",
//      "data": {
//          "status":status,
//          openid:"oWprtwKhrTeUJYR7bkn_lcCgTLnI"
//      },
//      success: function (data) {
//          console.log(data);
//          zongye=data[0].length;
//          $('#nums').html("共有"+data.length+"条记录&nbsp;&nbsp;当前1页/共"+data[0].pagetotal+"页")
//          var str='';
//          for(var i=0;i<data.length;i++){
//              if(data[i].baobao_name==null){
//                  data[i].baobao_name=''
//              }
//              if(data[i].baobao_sex==null){
//                  data[i].baobao_sex=''
//              }
//              if(data[i].baobao_name2==null){
//                  data[i].baobao_name2=''
//              }
//              if(data[i].yueling==null){
//                  data[i].yueling=''
//              }
//              if(data[i].y_keshi==null){
//                  data[i].y_keshi=''
//              }
//              if(data[i].create_time==null){
//                  data[i].create_time=''
//              }
//              if(data[i].e_time==null){
//                  data[i].e_time=''
//              }
//              if(data[i].name2==null){
//                  data[i].name2=''
//              }
//              if(data[i].phone2==null){
//                  data[i].phone2=''
//              }
//              str+='<tr>' +
//                  '<td>'+data[i].centre_id+'</td>' +
//                  '<td>'+data[i].username+'</td>' +
//                  '<td>'+data[i].gangwei+'</td>' +
//                  '<td>'+data[i].phone+'</td>' +
//                  '<td><a href="/Home/User/xiu?user_id='+data[i].user_id+'">修改 | </a>'+
//                  '<a href="" onclick="shanchu('+data[i].user_id+')">删除</a>'+
//                  '</td>' +
//                  '</tr>'
//          }
//          var str2='';
//          for(var i=0;i<data[0].pagetotal;i++){
//             var aa=Number(i)+1;
//              str2+='<option value="'+aa+'">'+aa+'</option>'
//          }
//          $('#ye').html(str2);
//          $('#liebiao').html(str)
//      }
//  })
//});
//$("#shouye").click(function () {
//  status=$('#jkl').val();
//  p=1;
//  tiaoye()
//})
//$("#shangye").click(function () {
//  status=$('#jkl').val();
//  if(p>1){
//      p--;
//      tiaoye()
//  }else {
//      alert("已经到第一页了");
//      return false;
//  }
//});
//
//$('#xiaye').click(function () {
//  status=$('#jkl').val();
//      if(p<zongye){
//          p++;
//          tiaoye()
//      }else {
//          alert("已经到最后一页了");
//          return false;
//      }
//  });
//$('#tiaoye').click(function () {
//  status=$('#jkl').val();
//  p=$('#ye').val();
//  tiaoye()
//})
//$("#weiye").click(function () {
//  status=$('#jkl').val();
//p=zongye;
//  tiaoye()
//});