<?php
namespace Home\Controller;
use Think\Controller;
class MyshController extends Controller {
    public function index1(){
    	header("access-control-allow-origin:*");
    	$centre_id=session('centre_id');
    	$user_id=session('user_id');
      $arr=M('crm_kjilu_r')
      ->join('crm_kjilu on crm_kjilu_r.jl_id=crm_kjilu.jl_id')
      ->join('xueyuan_baoming on crm_kjilu_r.xiu_user_id=xueyuan_baoming.user_id')
      ->join('crm_goods on crm_kjilu.s_id=crm_goods.s_id')
      ->join('left join xueyuan_baoming as a on crm_kjilu_r.x_guwen=a.user_id')
      ->join('left join xueyuan_baoming as b on crm_kjilu.guwen=b.user_id')
      ->where("crm_kjilu_r.centre_id='$centre_id' and crm_kjilu_r.x_status=0 and crm_kjilu_r.xiu_user_id='$user_id'")
      ->field('crm_kjilu_r.*,crm_kjilu.*,xueyuan_baoming.username,crm_goods.s_name,a.username as x_uname,b.username as y_uname')
      ->order('crm_kjilu_r.c_time desc')
      ->select();
      foreach ($arr as $key => $value) {
        $arr[$key]['tai']=1;
      }
      $ar=M("crm_kecheng_r")
      ->join('xueyuan_baoming on crm_kecheng_r.t_user_id=xueyuan_baoming.user_id')
      ->where("crm_kecheng_r.centre_id='$centre_id' and crm_kecheng_r.s_status=0 and t_user_id='$user_id'")
      ->field('crm_kecheng_r.*,xueyuan_baoming.username')
      ->order('crm_kecheng_r.c_time desc')
      ->select();
      foreach ($ar as $key => $value) {
        $ar[$key]['tai']=2;
      }
      $a=array_merge((array)$arr, (array)$ar);
      $this->ajaxReturn($a,'JSON');
    }
    public function index2(){
    	header("access-control-allow-origin:*");
    	$centre_id=session('centre_id');
    	$user_id=session('user_id');
      $arr=M('crm_kjilu_r')
      ->join('crm_kjilu on crm_kjilu_r.jl_id=crm_kjilu.jl_id')
      ->join('xueyuan_baoming on crm_kjilu_r.xiu_user_id=xueyuan_baoming.user_id')
      ->join('crm_goods on crm_kjilu.s_id=crm_goods.s_id')
      ->join('left join xueyuan_baoming as a on crm_kjilu_r.x_guwen=a.user_id')
      ->join('left join xueyuan_baoming as b on crm_kjilu_r.y_guwen=b.user_id')
      ->where("crm_kjilu_r.centre_id='$centre_id' and (crm_kjilu_r.x_status=1 or crm_kjilu_r.x_status=2) and crm_kjilu_r.xiu_user_id='$user_id'")
      ->field('crm_kjilu_r.*,crm_kjilu.*,xueyuan_baoming.username,crm_goods.s_name,a.username as x_uname,b.username as y_uname')
      ->order('crm_kjilu_r.c_time desc')
      ->select();
      foreach ($arr as $key => $value) {
        $arr[$key]['tai']=1;
        if($value['x_status']==1){
        	$arr[$key]['x_status']='同意';
        }else{
        	$arr[$key]['x_status']='不同意';
        }
      }
      $ar=M("crm_kecheng_r")
      ->join('xueyuan_baoming on crm_kecheng_r.t_user_id=xueyuan_baoming.user_id')
      ->where("crm_kecheng_r.centre_id='$centre_id' and (crm_kecheng_r.s_status=1 or crm_kecheng_r.s_status=2) and t_user_id='$user_id'")
      ->field('crm_kecheng_r.*,xueyuan_baoming.username')
      ->order('crm_kecheng_r.c_time desc')
      ->select();
      foreach ($ar as $key => $value) {
        $ar[$key]['tai']=2;
        if($value['s_status']==1){
        	$ar[$key]['x_status']='同意';
        }else{
        	$ar[$key]['x_status']='不同意';
        }
      }
      $a=array_merge((array)$arr, (array)$ar);
      $this->ajaxReturn($a,'JSON');
    }
}