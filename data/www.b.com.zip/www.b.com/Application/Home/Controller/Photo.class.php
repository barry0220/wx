<?php 
namespace Org\dx;
include("TopClient.php");
include("AlibabaAliqinFcSmsNumSendRequest.php"); 
class Photo{
	public function number($centre,$username,$phone,$w_key,$mb_id,$str1,$str2,$str3,$str4,$str5,$str6){
		$c = new \TopClient;
		$c->appkey ="23570812";
		$c->secretKey = "e4410b9fe8ae0bb779670ea33d022273";
		$req = new \AlibabaAliqinFcSmsNumSendRequest;
		$req->setExtend("111");
		$req->setSmsType("normal");
		$req->setSmsFreeSignName("运动宝贝");
		switch ($mb_id) {
		  case '生日提醒':
			$req->setSmsParam("{\"centre\":\"$centre\",\"name\":\"$username\"}");
			break;
		  case '扣课短信通知':
		  	$req->setSmsParam("{\"name\":\"$username\",\"time\":\"$str1\",\"bishop\":\"$str2\",\"curriculum\":\"$str3\",\"button\":\"$str4\",\"class\":\"$str5\"}");
		  	break;
		  case '签约短信':
		  	$req->setSmsParam("{\"parents\":\"$str1\",\"name\":\"$username\",\"amount\":\"$str3\",\"hours\":\"$str4\",\"signing\":\"$str5\"}");
		  	break;
		  case '合约到期提醒':
		  	$req->setSmsParam("{\"name\":\"$username\",\"number\":\"$str1\",\"time\":\"$str2\"}");
		  	break;
		  case '潜客短信活动通知':
		  	$req->setSmsParam("{\"baby\":\"$username\",\"date\":\"$str1\",\"activity\":\"$str2\",\"phone\":\"$str3\"}");
		  	break;
		}
		$req->setRecNum("$phone");
		$req->setSmsTemplateCode("$w_key");
		$resp = $c->execute($req);
		return $resp;
	}
}
 ?>