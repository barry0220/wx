<?php
namespace Home\Controller;
use Think\Controller;
class kecbController extends CommonController {
	//课时包页面
    public function index(){
    	if(isset($_GET['p'])){
         $page=$_GET['p'];
       }else{
         $page=1;
       }
       $centre_id=session("centre_id");
       $num=M("crm_goods")->where("l_id=10 and status=1 and (centre_id=0 or centre_id='$centre_id')")->count();
       $pageone=10;//每页数据
       $pagetotal=ceil($num/$pageone);
       $pyl=($page-1)*$pageone;//偏移量
       $this->page=$page;
       $this->pagetotal=$pagetotal;
       $this->num=$num;
       $sql="SELECT * FROM crm_goods where l_id=10 and status=1 and (centre_id=0 or centre_id='$centre_id') order by s_id desc limit $pyl,$pageone";
       $this->data=M()->query($sql);
       $this->display();
    }
    //优惠劵页面
    public function index1(){
    	if(isset($_GET['p'])){
         $page=$_GET['p'];
       }else{
         $page=1;
       }
       $centre_id=session("centre_id");
       $num=M("crm_goods")->where("l_id=11 and status=1 and (centre_id=0 or centre_id='$centre_id')")->count();
       $pageone=10;//每页数据
       $pagetotal=ceil($num/$pageone);
       $pyl=($page-1)*$pageone;//偏移量
       $this->page=$page;
       $this->pagetotal=$pagetotal;
       $this->num=$num;
       $sql="SELECT * FROM crm_goods where l_id=11 and status=1 and (centre_id=0 or centre_id='$centre_id') limit $pyl,$pageone";
       $this->data=M()->query($sql);
       $this->display();
    }
    //添加课时包
    public function add(){
       $data['s_name']=I('post.s_name');
       $data['price']=I('post.price');
       $data['k_shu']=I('post.k_shu');
       $data['centre_id']=session('centre_id');
       $data['create_name']=session('user_id');
       $data['source']="PC";
       $data['l_id']=10;
       if(M('crm_goods')->add($data)){
       	 $this->redirect("index");
       }
    }
    //删除课时包
    public function shanchu(){
      $crm_goods=M("crm_goods");
      $id=I('post.id');
      $centre_id=M("crm_goods")->where("s_id=".$id)->getField("centre_id");
      if($centre_id==0){
        echo 2;die;//如果是总部将不能删除
      }
      $data['status']=0;
      $rel=$crm_goods->where("s_id=".$id)->save($data);
      if($rel){
        echo 1;
      }
    }
    //添加优惠劵
    public function addy(){
       $data['s_name']=I('post.s_name');
       $data['price']=I('post.price');
       $data['k_shu']=I('post.k_shu');
       $data['centre_id']=session('centre_id');
       $data['create_name']=session('user_id');
       $data['source']="PC";
       $data['l_id']=11;
       if(M('crm_goods')->add($data)){
       	 $this->redirect("kecb/index1");
       }
    }
    //删除优惠劵
    public function shanchuy(){
      $crm_goods=M("crm_goods");
      $id=I('post.id');
      $centre_id=$crm_goods->where("s_id=".$id)->getField("centre_id");
      if($centre_id==0){
        echo 2;die;//如果是总部将不能删除
      }
      $data['status']=0;
      $rel=$crm_goods->where("s_id=".$id)->save($data);
      if($rel){
        echo 1;
      }
    }
}