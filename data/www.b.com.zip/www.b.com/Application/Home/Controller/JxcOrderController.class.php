<?php
namespace Home\Controller;
use Think\Controller;
/**
 *
 * 进销存模块 出库入库控制器1
 *
 */
class JxcOrderController extends CommonController {
    //获取当前中心所有入库单
    public function enter(){
        ob_clean();
        $centre_id = session('centre_id');   //获取当前门店ID  测试为1

        //判断是否存在条件查询
        $post_data = I('post.map');
        $supplier_id = $post_data['supplier_id'];
        $person = $post_data['person'];
        $time_s = $post_data['time_s'];
        $time_e = $post_data['time_e'];
        $page = $post_data['page'] ? $post_data['page'] : 1;
        $pageone=$post_data['pageone'] ? $post_data['.pageone'] : 10;//每页数据

        //条件返回
        $map['time_s'] = $post_data['time_s'];
        $map['time_e'] = $post_data['time_e'];
        $map['supplier_id'] = $post_data['supplier_id'];
        $map['person'] = $post_data['person'];
        $map['page'] = $post_data['page'];
        $map['pageone'] = $post_data['pageone'];

        //组装where条件
        $where = [
            'jxc_order.centre_id' => $centre_id,
            'jxc_order.status' => 1,    //未删除
            'jxc_order.order_type'=>1 //入库类别
        ];
        //判断是否存在条件查询
        $string = '';    //条件字符串
        if ($time_s) {
            $string .= "and jxc_order.create_time >='{$time_s}'";
        }
        if ($time_e) {
            $string .= "and jxc_order.create_time<='{$time_e}'";
        }
        if ($supplier_id) {
            $string .= "and jxc_order.supplier_id = '{$supplier_id}'";
        }
        if ($person) {
            $string .= "and jxc_order.person = '{$person}'";
        }

        //判断是否存在查询条件
        if($string){
            $where['_string'] = substr($string,4);
        }

        $Orders = M('jxc_order')->field('jxc_order.*,jxc_supplier.supplier_name')
            ->join('jxc_supplier on jxc_order.supplier_id = jxc_supplier.id','left');      //实例化
        $m = clone $Orders;

        $count = $Orders ->where($where)->count();   //获取数据总数
        $pagetotal=ceil($count/$pageone);   //总页数
        $map['pagetotal'] = $pagetotal; //返回参数 总页数
        $pyl=($page-1)*$pageone;//偏移量

        $Orders = $m;
        $res = $Orders  -> where($where)->order('id desc')->limit($pyl,$pageone) -> select();   //获取结果信息

        //获取当前中心所有的用户信息用户用于填充采购人 制单人姓名
        $userres = M('xueyuan_baoming') -> where(['status'=>1])->where('centre_id='.$centre_id) -> select();
        //获取当前中心所有供应商名称
        $suppliers = M('jxc_supplier') -> where(['status'=>1])->where('centre_id='.$centre_id) -> select();
        //遍历用户信息 重组结构 用户ID为键
        $users = [];
        foreach ($userres as $k => $v) {
            $users[$v['user_id']] = $v['username'];
        }
        //获取所有的入库类别 出入库类别表 状态为2
        $storageres = M('jxc_out_storage')->where(['type'=>2,'is_use'=>2,'status'=>['neq','0'],'centre_id'=>$centre_id])->select();
        //遍历类别信息 重组结构 类别ID为键
        $storages = [];
        foreach($storageres as $k => $v){
            $storages[$v['id']] = $v['name'];
        }
        //遍历入库单信息 填充采购人 制单人姓名
        foreach ($res as $k => $v){
            $res[$k]['person'] = $users[$v['person']];    //获取采购人的姓名
            $res[$k]['user_name'] = $users[$v['user_id']];    //获取制单人的姓名
            $res[$k]['storage_name'] = $storages[$v['order_status']];   //获取业务类别
            $res[$k]['date'] = date('Y-m-d',strtotime($v['date'])); //修改时间样式
            $res[$k]['create_time'] = date('Y-m-d',strtotime($v['create_time']));   //修改时间样式
        }

        $data = ['map'=>$map,'suppliers'=>$suppliers,'data'=>$res];
        $this -> ajaxReturn($data,'JSON');
    }

    //获取当前中心所有出库单 ---出库暂时不写
    public function out(){

        $centre_id = session('centre_id');   //获取当前门店ID  测试为1

        //组装where条件
        $where = [
            'jxc_order.centre_id' => $centre_id,
            'jxc_order.status' => 1,    //未删除
            'jxc_order.order_type'=>0 //出库类别
        ];
        //判断是否存在条件查询
        $string = '';    //条件字符串
        $map = [];  //条件返回
        $condi = I('get.');
        if ($condi['time_s']) {
            $string .= "and jxc_order.create_time >='{$condi['time_s']}'";
            $map['time_s'] = $condi['time_s'];
        }
        if ($condi['time_e']) {
            $string .= "and jxc_order.create_time<='{$condi['time_e']}'";
            $map['time_e'] = $condi['time_e'];
        }
        if ($condi['centre']) {
            $string .= "and jxc_order.centre = '{$condi['centre']}'";
            $map['centre'] = $condi['centre'];
        }
        if ($condi['person']) {
            $string .= "and jxc_order.person = '{$condi['person']}'";
            $map['person'] = $condi['person'];
        }

        //判断是否存在查询条件
        if($string){
            $where['_string'] = substr($string,4);
        }

        $Orders = M('jxc_order');      //实例化

        // 所有到货单信息  供应商
        $m = $Orders->field('jxc_order.*,wx_centre.centre')
            ->join('wx_centre on jxc_order.centre = wx_centre.centre_id','left');

        $p = getpage($m, $where, 15);        //使用公用函数分页
        $this->page = bootstrap_page_style($p->show());    //把分页页码样式转换后 传入页面

        $res = $m  -> where($where)->order('id desc') -> select();   //获取结果信息

        //获取当前中心所有的用户信息用户用于填充采购人 制单人姓名
        $userres = M('xueyuan_baoming') -> where('centre_id='.$centre_id) -> select();

        /**
         * 1.合约 2.违约欠缴 3.取消区域保护 5.关店
         * 8.延迟收缴 9.异常未处理 10.合约未开店
         * 11.解约未关店 12.催缴 13.签订意向协议
         * 14.已交意向金 15.选址成功
         */
        //拼接查询中心名称的状态过滤条件
        $centre_where = [
            'jyzt'=>[
                'NOT IN','2,3,5,11'
            ]
        ];
        //获取当前所有中心名称
        $centres =  M('wx_centre')->where($centre_where) -> select();
//        dd($Cen->_sql());
        //遍历用户信息 重组结构 用户ID为键
        $users = [];
        foreach ($userres as $k => $v) {
            $users[$v['user_id']] = $v['name'];
        }
        //获取所有的入库类别
        $storageres = M('jxc_out_storage')->where(['centre_id'=>$centre_id])->select();
        //遍历类别信息 重组结构 类别ID为键
        $storages = [];
        foreach($storageres as $k => $v){
            $storages[$v['id']] = $v['name'];
        }

        //遍历入库单信息 填充采购人 制单人姓名
        foreach ($res as $k => $v){
            $res[$k]['person'] = $users[$v['person']];    //获取采购人的姓名
            $res[$k]['user_name'] = $users[$v['user_id']];    //获取制单人的姓名
            $res[$k]['storage_name'] = $storages[$v['order_status']];
        }
        $this -> assign('orders',$res);  //分配数据
        $this -> assign('users',$users);    //分配当前门店所有用户
        $this -> assign('map',$map);    //分配查询条件数据
        $this -> assign('centres',$centres);    //分配当前门店所有供货商信息
        $this -> assign('storages',$storages);  //分配所有的出入库状态

        $this->sidebar();                        //侧边公共栏
        $this->authid = $this->dao();            //保证左侧导航条是展开状态，默认选中
        $this -> display();
    }

    /**
     * 执行添加出入库单
     *
     */
    //显示入库添加页面
    public function addenter()
    {
        ob_clean();
        //获取当前门店用户信息  供应商信息
        $centre_id = session('centre_id');   //获取当前门店ID  测试为2
        //获取当前中心所有的用户信息用户用于填充采购人 制单人姓名
        $users = M('xueyuan_baoming') -> where(['status'=>1,'centre_id'=>$centre_id]) -> select();
        //获取当前中心所有供应商名称
        $suppliers = M('jxc_supplier')  -> where(['status'=>1,'centre_id'=>$centre_id]) -> select();
        //获取当前登录用户为制单人
        $user_name = session('name');
        //获取当前所有货运公司
        $express = M('jxc_express')->where(['status'=>1])->where('centre_id='.$centre_id) -> select();

        //获取所有的入库类别 出入库类别表 状态为2
        $storages = M('jxc_out_storage')->where(['type'=>2,'is_use'=>2,'status'=>1,'centre_id'=>$centre_id])->select();
        $date = date('Y-m-d');
        $data = ['user_name'=>$user_name,'date'=>$date,'users'=>$users,'express'=>$express,'suppliers'=>$suppliers,'storages'=>$storages];
        $this -> ajaxReturn($data,'JSON');
    }

    //显示出库添加页面 ----暂时不做
    public function addout()
    {
        //获取当前门店用户信息  供应商信息
        $centre_id = session('centre_id');   //获取当前门店ID  测试为2
        //获取当前中心所有的用户信息用户用于填充采购人 制单人姓名
        $users = M('xueyuan_baoming') -> where('centre_id='.$centre_id) -> select();
        //获取当前中心所有中心名称
        $centre_where = [
            'jyzt'=>[
                'NOT IN','2,3,5,11'
            ]
        ];
        $centres = M('wx_centre')->where($centre_where) -> select();
        //获取当前登录用户为制单人
        $user_name = session('name');
        //获取当前所有货运公司
        $express = M('jxc_express')->where(['status'=>1])->where('centre_id='.$centre_id) -> select();

        //获取所有的入库类别 出入库类别表 状态为2
        $storageres = M('jxc_out_storage')->where(['type'=>1,'is_use'=>2,'status'=>['neq','0'],'centre_id'=>$centre_id])->select();
        //遍历类别信息 重组结构 类别ID为键
        $storages = [];
        foreach($storageres as $k => $v){
            $storages[$v['id']] = $v['name'];
        }
        $date = date('Y-m-d');
        $this -> assign('users',$users);    //分配当前门店所有用户
        $this -> assign('centres',$centres);    //分配当前门店所有供货商信息
        $this -> assign('user_name',$user_name);    //分配制单人姓名
        $this -> assign('express',$express);    //分配货运公司信息
        $this -> assign('storages',$storages); //分配业务类别
        $this -> assign('date',$date);  //分配当前日期为出库日期


        $this -> display();
    }
    //添加入库单
    public function storeenter()
    {
        ob_clean();
        //判断是否非法访问 非法方式返回错误
        if (!IS_POST) {
            $this -> ajaxReturn(['status'=>1,'msg'=>'请求方式不合法'],'JSON');
        }
        //创建验证规则
        $rules = [
            ['date','require','采购日期不能为空'],
            ['purchaser_id','require','采购人不能为空'],
            ['supplier_id','require','供应商ID不能为空'],
            ['order_status','require','业务类别不能为空'],
        ];

        $Orders = M('jxc_order'); // 实例化对象
        $post_data = I('post.data');

        if (!$Orders->validate($rules) -> create($post_data)){     // 如果创建失败 表示验证没有通过 输出错误提示信息
            $this -> ajaxReturn(['status'=>1,'msg'=>'验证失败'.$Orders->getError()],'JSON');
        }else if (!isset($_POST['supplier_id'],$_POST['date'],$_POST['person'],$_POST['order_status'])){
            $this -> ajaxReturn(['status'=>1,'msg'=>'验证失败,字段填写不完整'],'JSON');
        }else {     // 验证通过 可以进行其他数据操作
            //验证商品信息
            if ( isset($_POST['number'][0]) && !empty($_POST['number'][0]) && isset($_POST['purchase_price'][0]) && !empty($_POST['purchase_price'][0])) {
                //创建验证规则
                $ruls = [
                    ['purchase_price[0]', 'require', '采购价格不能为空'],
                    ['purchase_price[0]', '/^(([0-9]+\.[0-9]*[1-9][0-9]*)|([0-9]*[1-9][0-9]*\.[0-9]+)|([0-9]*[1-9][0-9]*))$/', '采购价格必须为数字'],
                    ['number[0]', 'require', '数量不能为空'],
                    ['number[0]', '/\d+/', '数量必须为数字']
                ];

                $Order_goods = M("jxc_order_goods"); // 实例化对象

                if (!$Order_goods->validate($ruls)->create($post_data)) {     // 如果创建失败 表示验证没有通过 输出错误提示信息
                    $this -> ajaxReturn(['status'=>1,'msg'=>'商品信息验证失败'.$Order_goods->getError()],'JSON');
                } else {// 验证通过 可以进行其他数据操作
                    //获取数据
                    $centre_id = session('centre_id');   //获取当前门店ID  测试为2
                    $order_num = $this -> getNum(1);
                    $fields['order_num'] = $order_num;        //采购订单编号
                    $fields['order_type'] = 1;  //订单类别 入库
                    $fields['date'] = $post_data['date']; //到货日期
                    $fields['express_id'] = $post_data['express_id'];   //货运公司ID
                    $fields['express_price'] = $post_data['express_price'];   //运费
                    $fields['express_num'] = $post_data['express_num'];   //货运单号
                    $fields['person'] = $post_data['person'];   //获取采购人ID
                    $fields['order_status'] = $post_data['order_status'];   //设置到货单状态 未审核
                    $fields['supplier_id'] = $post_data['supplier_id'];     //获取供货商ID
                    $fields['centre_id'] = $centre_id;      //设置所属中心ID
                    $user_id = session("user_id");  //获取当前登陆用户的user_id  总部后台管理系统获取mg_id  会员管理系统获取user_id
                    $fields['user_id'] = $user_id;      //设置制单人ID
                    $fields['status'] = 1;      //设置状态正常 0为安全删除
                    $fields['notes'] = $post_data['notes'];
                    $fields['sum_price'] = $post_data['sumprice'];    //到货总价;

                    //创建模型对象
                    $Orders->create($fields);
                    //执行添加订单
                    $res = $Orders->add();

                    if ($res) {
                        //获取所有的商品信息
                        $goods_ids = $post_data['goods_id'];
                        $prices = $post_data['purchase_price'];
                        $numbers = $post_data['number'];
                        $good_notes = $post_data['good_notes'];
                        $order_id = $res;

                        //重组数据结构 转换为数据库需要的格式
                        $gfields = [];  //商品数组
                        foreach ($goods_ids as $k => $v) {
                            $gfields[$k]['good_id'] = $v;
                            $gfields[$k]['number'] = $numbers[$k];
                            $gfields[$k]['price'] = $prices[$k];
                            $gfields[$k]['good_notes'] = $good_notes[$k];
                            $gfields[$k]['order_id'] = $order_id;
                        }

                        
                        $re = $Order_goods->addAll($gfields);

                        if ($re) {
                            //添加到货订单后更新库存
                            $this -> addStock($order_id);
                            $this -> ajaxReturn(['status'=>2,'msg'=>'添加成功'],'JSON');
                        } else {
                            $this -> ajaxReturn(['status'=>1,'msg'=>'添加入库单商品失败,'.$Order_goods->getError()],'JSON');
                        }
                    } else {
                        $this -> ajaxReturn(['status'=>1,'msg'=>'添加入库单失败'.$Orders->getError()],'JSON');
                    }
                }
            }else{
                $this -> ajaxReturn(['status'=>1,'msg'=>'验证失败,商品信息填写不完整'],'JSON');
            }
        }
    }
    //添加出库单  --暂时不做
    public function storeout()
    {
        //判断是否非法访问 非法方式返回错误
        if (!IS_POST) {
            $this->error('请求方式不合法', U('JxcOrder/out'), 3);
        }

        //创建验证规则
        $rules = [
            ['date','require','出库日期不能为空'],
            ['purchaser_id','require','出库人不能为空'],
            ['centre','require','中心名称不能为空'],
            ['order_status','require','业务类别不能为空'],
        ];

        $Orders = M('jxc_order'); // 实例化对象

        if (!$Orders->validate($rules) -> create()){     // 如果创建失败 表示验证没有通过 输出错误提示信息
            $this->error('验证失败,'.$Orders->getError(), U('JxcOrder/addout'), 3);
        }else if (!isset($_POST['centre'],$_POST['date'],$_POST['person'],$_POST['order_status'])){
            $this->error('验证失败,订单字段填写不完整', U('JxcOrder/addout'), 3);
        }else {     // 验证通过 可以进行其他数据操作
            //验证商品信息
            if ( isset($_POST['number'][0]) && !empty($_POST['number'][0]) && isset($_POST['price'][0]) && !empty($_POST['price'][0])) {
                //创建验证规则
                $ruls = [
                    ['price[0]', 'require', '销售价格不能为空'],
                    ['price[0]', '/^(([0-9]+\.[0-9]*[1-9][0-9]*)|([0-9]*[1-9][0-9]*\.[0-9]+)|([0-9]*[1-9][0-9]*))$/', '销售价格必须为数字'],
                    ['number[0]', 'require', '数量不能为空'],
                    ['number[0]', '/\d+/', '数量必须为数字']
                ];

                $Order_goods = M("jxc_order_goods"); // 实例化对象

                if (!$Order_goods->validate($ruls)->create()) {     // 如果创建失败 表示验证没有通过 输出错误提示信息
                    $this->error($Order_goods->getError(), U('JxcOrder/addout'), 2);
                } else {// 验证通过 可以进行其他数据操作
                    //获取数据
                    $centre_id = session('centre_id');   //获取当前门店ID  测试为2
                    $order_num = $this -> getNum(0);
                    $fields['order_num'] = $order_num;        //采购订单编号
                    $fields['order_type'] = 0;  //订单类别 出库
                    $fields['date'] = I('post.date'); //到货日期
                    $fields['express_id'] = I('post.express_id');   //货运公司ID
                    $fields['express_price'] = I('post.express_price');   //运费
                    $fields['express_num'] = I('post.express_num');   //货运单号
                    $fields['person'] = I('post.person');   //获取采购人ID
                    $fields['order_status'] = I('post.order_status');   //设置到货单状态 未审核
                    $fields['centre'] = I('post.centre');     //获取供货商ID
                    $fields['centre_id'] = $centre_id;      //设置所属中心ID
                    $user_id = session("user_id");  //获取当前登陆用户的user_id  总部后台管理系统获取mg_id  会员管理系统获取user_id
                    $fields['user_id'] = $user_id;      //设置制单人ID
                    $fields['status'] = 1;      //设置状态正常 0为安全删除
                    $fields['notes'] = I('post.notes');
                    $fields['sum_price'] = I('post.sumprice');    //到货总价;

                    //创建模型对象
                    $Orders->create($fields);
                    //执行添加订单
                    $res = $Orders->add();

                    if ($res) {
                        //获取所有的商品信息
                        $goods_ids = I('post.goods_id');
                        $prices = I('post.price');
                        $numbers = I('post.number');
                        $good_notes = I('post.good_notes');
                        $order_id = $res;

                        //重组数据结构 转换为数据库需要的格式
                        $gfields = [];  //商品数组
                        foreach ($goods_ids as $k => $v) {
                            $gfields[$k]['good_id'] = $v;
                            $gfields[$k]['number'] = $numbers[$k];
                            $gfields[$k]['price'] = $prices[$k];
                            $gfields[$k]['good_notes'] = $good_notes[$k];
                            $gfields[$k]['order_id'] = $order_id;
                        }


                        $re = $Order_goods->addAll($gfields);

                        if ($re) {
                            //添加出货订单后更新库存 减少库存
                            $this -> removeStock($order_id);
                            $this -> redirect('JxcOrder/out');
                        } else {
                            $this->success('添加出库单商品失败,' . $Order_goods->getError(), U('JxcOrder/addout'), 3);
                        }
                    } else {
                        $this->success('添加出库单失败,' . $Orders->getError(), U('JxcOrder/addout'), 3);
                    }
                }
            }else{
                $this->error('验证失败,商品字段填写不完整', U('JxcOrder/addout'), 3);
            }
        }
    }


    //获取单条入货单信息
    public function showenter()
    {
        ob_clean();
        $id = I('post.id');    //获取要查询的商品类别的ID
        $Orders = M('jxc_order'); //实例化到货单对象
        $order_info = $Orders->where('id='.$id)->find(); //获取到货单记录

        $orderid = $order_info['id'];    //获取到货单id 用于查询商品
        $Order_goods = M('jxc_order_goods');
        $order_goods = $Order_goods->where('order_id='.$orderid)->select();

        $centre_id = session('centre_id');   //获取当前门店ID  测试为2
        //获取当前中心所有的用户信息用户用于填充采购人 制单人姓名
        $useres = M('xueyuan_baoming') -> where('centre_id='.$centre_id) -> select();
        //重组结构
        $users = [];
        foreach ($useres as $k => $v){
            $users[$v['user_id']] = $v['name'];
        }
        //获取当前中心所有供应商名称
        $supplierres = M('jxc_supplier')  -> where(['status'=>1])-> where('centre_id='.$centre_id) -> select();
        //重组结构
        $suppliers = [];
        foreach ($supplierres as $k => $v){
            $suppliers[$v['id']] = $v['supplier_name'];
        }
        //获取当前所有货运公司
        $expressres = M('jxc_express') -> where(['status'=>1]) ->where('centre_id='.$centre_id) -> select();

        //重组结构
        $express = [];
        foreach($expressres as $k => $v){
            $express[$v['id']] = $v['express_name'];
        }
        $where = [
            'centre_id'=>$centre_id,
        ];
        $goodres = M('jxc_goods')->where($where)->select();
        //重组结构
        $goods = [];
        foreach($goodres as $k =>$v){
            $goods[$v['id']] = $v;
        }
        //获取所有的入库类别 出入库类别表 状态为2
        $storageres = M('jxc_out_storage')->where(['type'=>2,'is_use'=>2,'status'=>['neq','0'],'centre_id'=>$centre_id])->select();
        //遍历类别信息 重组结构 类别ID为键
        $storages = [];
        foreach($storageres as $k => $v){
            $storages[$v['id']] = $v['name'];
        }

        //重组订单信息结构
        $info = [];
        $info['id'] = $order_info['id'];
        $info['date'] = date('Y-m-d',strtotime($order_info['date']));  //采购日期
        $info['supplier_name'] = $suppliers[$order_info['supplier_id']];   //供应商名称
        $info['person'] = $users[$order_info['person']];   //采购人
        $info['user_name'] = $users[$order_info['user_id']];   //制单人
        $info['order_status'] = $storages[$order_info['order_status']];
        $info['express_name'] = $express[$order_info['express_id']];
        $info['express_price'] = $order_info['express_price'];
        $info['express_num'] = $order_info['express_num'];
        $info['notes'] = $order_info['notes'];

        //重组订单商品信息结构
        $new_goods = [];
        foreach($order_goods as $k => $v){
            $new_goods[$k]['good_num'] = $goods[$v['good_id']]['good_num'];
            $new_goods[$k]['good_name'] = $goods[$v['good_id']]['good_name'];
            $new_goods[$k]['mini_imgpath'] = $goods[$v['good_id']]['mini_imgpath'];
            $new_goods[$k]['imgpath'] = $goods[$v['good_id']]['imgpath'];
            $new_goods[$k]['spec'] = $goods[$v['good_id']]['spec'];
            $new_goods[$k]['unit'] = $goods[$v['good_id']]['unit'];
            $new_goods[$k]['number'] = $v['number'];
            $new_goods[$k]['price'] = $v['price'];
            $new_goods[$k]['sumprice'] = sprintf("%.2f",$v['number']*$v['price']);
            $new_goods[$k]['good_notes'] = $v['good_notes'];
        }

        $data = ['order_info'=>$info,'order_goods'=>$new_goods];
        $this -> ajaxReturn($data,'JSON');

    }
    //获取单条出货单信息 ---暂时不做
    public function showout()
    {
        $id = I('get.id');    //获取要查询的商品类别的ID
        $Orders = M('jxc_order'); //实例化到货单对象
        $order_info = $Orders->where('id='.$id)->find(); //获取到货单记录

        $orderid = $order_info['id'];    //获取到货单id 用于查询商品
        $Order_goods = M('jxc_order_goods');
        $order_goods = $Order_goods->where('order_id='.$orderid)->select();

        $centre_id = session('centre_id');   //获取当前门店ID  测试为2
        //获取当前中心所有的用户信息用户用于填充采购人 制单人姓名
        $useres = M('xueyuan_baoming') -> where('centre_id='.$centre_id) -> select();
        //重组结构
        foreach ($useres as $k => $v){
            $users[$v['user_id']] = $v['name'];
        }
        //获取当前中心所有中心名称
        $centres = M('wx_centre')-> select();
        //获取当前所有货运公司
        $expressres = M('jxc_express') -> where(['status'=>1]) ->where('centre_id='.$centre_id) -> select();

        //重组结构
        foreach($expressres as $k => $v){
            $express[$v['id']] = $v['express_name'];
        }
        $where = [
            'centre_id'=>$centre_id,
            'status'=>1
        ];
        $goodres = M('jxc_goods')->where($where)->select();
        //重组结构
        foreach($goodres as $k =>$v){
            $goods[$v['id']] = $v;
        }
        //获取所有的入库类别 出入库类别表 状态为1
        $storageres = M('jxc_out_storage')->where(['type'=>1,'is_use'=>2,'status'=>['neq','0'],'centre_id'=>$centre_id])->select();
        //遍历类别信息 重组结构 类别ID为键
        $storages = [];
        foreach($storageres as $k => $v){
            $storages[$v['id']] = $v['name'];
        }
        $this -> assign('users',$users);    //分配当前门店所有用户
        $this -> assign('centres',$centres);    //分配当前门店所有供货商信息
        $this -> assign('orderinfo',$order_info);
        $this -> assign('order_goods',$order_goods);
        $this -> assign('express',$express);
        $this -> assign('goods',$goods);
        $this -> assign('storages',$storages);

        $this -> display();

    }



    //删除入库单信息  安全删除  状态修改为0
    public function deleteenter()
    {
        $id = I('post.id');
        $fields['status'] = 0;
        $Orders = M('jxc_order');
        $res = $Orders->where("id = '{$id}'")->save($fields);;
        if(false !== $res){
            //入库单作废 执行减少库存
            $this -> removeStock($id);  //参数为入库单ID
            //写入LOG
            $order_num = M('jxc_order')->where("id = $id")->find()['order_num'];
            $content = "作废入库单,单号:".$order_num."成功";
            setLog($content);
            $this -> ajaxReturn(['status'=>2,'msg'=>'作废入库单成功'],'JSON');
        } else {
            $this -> ajaxReturn(['status'=>1,'msg'=>'作废入库单失败'],'JSON');
        }
    }

    //删除出库单信息  安全删除  状态修改为0 --暂时不做
    public function deleteout()
    {
        $id = I('post.id');
        $fields['status'] = 0;
        $Orders = M('jxc_order');
        $res = $Orders->where("id = '{$id}'")->save($fields);;
        if(false !== $res){
            //出库单作废 执行添加库存
            $this -> addStock($id);  //参数为入库单ID
            //写入LOG
            $order_num = M('jxc_order')->where("id = $id")->find()['order_num'];
            $content = "作废出库单,单号:".$order_num."成功";
            setLog($content);
            echo 1;
        } else {
            echo 2;
        }
    }

    //添加库存
    public function addStock($id)
    {
        $order_id = $id;    //入库单ID
        $centre_id = session('centre_id');
        //获取所有的商品信息
        $goods = M('jxc_order_goods')->where('order_id='.$order_id)->select();

        foreach ($goods as $k => $v){
            $stocks[$k]['good_id'] = $v['good_id'];
            $stocks[$k]['number'] = $v['number'];
            $stocks[$k]['centre_id'] = $centre_id;
        }
        //判断库存中是否存在当前商品  存在修改数量 不存在添加
        $Stock = M('jxc_stock');
        foreach ($stocks as $k => $v){
            $where = [
                'good_id'=>$v['good_id'],
                'centre_id'=>$centre_id
            ];
            $now = $Stock->where($where)->find();
            //判断库存中是否存在当前商品
            if ($now){
                //执行修改库存
                $number['number'] = $now['number']+$v['number'];    //库存数量
                $Stock->where($where)->save($number);
            }else{
                //执行添加库存
                $Stock -> create($v);
                $Stock -> add($v);
            }
        }
    }
    //订单作废后减少库存 传入参数 订单的ID
    public function removeStock($id)
    {
        $centre_id = session('centre_id');  //获取当前中心ID
        //执行减少库存
        $goods = M('jxc_order_goods')->where('order_id='.$id)->select(); //获取当前订单单的商品信息

            $Stock = M('jxc_stock');
            foreach ($goods as $k => $v) {
                $where = [
                    'good_id' => $v['good_id'],
                    'centre_id' => $centre_id,
                ];
                //查找当前商品
                $now = $Stock->where($where)->find();
                //执行减少库存
                $number['number'] = $now['number'] - $v['number'];
                $Stock->where($where)->save($number);
            }
    }


    //生成流水编号
    public function getNum($type)
    {
        //设置编号开头
        if ($type == 1){    //入库
            $first = 'RK';
        }else if($type == 3){  //盘点
            $first = 'PD';
        }else{      //出库
            $first = 'CK';
        }
        $centre_id = session('centre_id');  //获取当前中心ID
//        获取当天日期
        $date = date('Ymd');
        $where = [
            'centre_id'=>$centre_id,
            'order_type'=>$type,
            'create_time'=>[
                'gt',$date
            ]
        ];
        //获取当前数据库当天使用的最后一个流水号
        $lastNum = M('jxc_order')->where($where)->order('id desc')->find()['order_num'];
        //如果存在  截取后四位 并且加1  如果不存在生成当天第一条
        if ($lastNum){
            $last = substr($lastNum,-4);    //获取最后4位
            $a = substr($lastNum,0,-4);     //获取前面9位
            $var=sprintf("%04d", $last+1);
            $num = $a.$var;
            return $num;
        }else{
            $date = substr($date,2);
            $num = $first.$date.$centre_id.'0001';
            return $num;
        }
    }
    
    /**
     * 盘点功能相关方法开始
     **/
    //显示盘点单
    public function pd()
    {
        ob_clean();
        $centre_id = session('centre_id');   //获取当前门店ID  测试为1

        //判断是否存在条件查询
        $post_data = I('post.map');
        $person = $post_data['person'];
        $time_s = $post_data['time_s'];
        $time_e = $post_data['time_e'];
        $page = $post_data['page'] ? $post_data['page'] : 1;
        $pageone=$post_data['pageone'] ? $post_data['.pageone'] : 10;//每页数据

        //条件返回
        $map['time_s'] = $post_data['time_s'];
        $map['time_e'] = $post_data['time_e'];
        $map['person'] = $post_data['person'];
        $map['page'] = $post_data['page'];
        $map['pageone'] = $post_data['pageone'];

        //组装where条件
        $where = [
            'jxc_order.centre_id' => $centre_id,
            'jxc_order.status' => 1,    //未删除
            'jxc_order.order_type'=>3 //盘点类别
        ];
        //判断是否存在条件查询
        $string = '';    //条件字符串
        if ($time_s) {
            $string .= "and jxc_order.create_time >='{$time_s}'";
        }
        if ($time_e) {
            $string .= "and jxc_order.create_time<='{$time_e}'";
        }
        if ($person) {
            $string .= "and jxc_order.person = '{$person}'";
        }

        //判断是否存在查询条件
        if($string){
            $where['_string'] = substr($string,4);
        }

        $Orders = M('jxc_order');      //实例化

        $count = $Orders ->where($where)->count();   //获取数据总数
        $pagetotal=ceil($count/$pageone);   //总页数
        $map['pagetotal'] = $pagetotal; //返回参数 总页数
        $pyl=($page-1)*$pageone;//偏移量

        $res = $Orders  -> where($where)->order('id desc')->limit($pyl,$pageone) -> select();   //获取结果信息

        //获取当前中心所有的用户信息用户用于填充盘点人姓名
        $userres = M('xueyuan_baoming') -> where(['centre_id'=>$centre_id,'status'=>1]) -> select();

        //遍历用户信息 重组结构 用户ID为键
        $users = [];
        foreach ($userres as $k => $v) {
            $users[$v['user_id']] = $v['username'];
        }

        //遍历信息 填充采购人 制单人姓名
        foreach ($res as $k => $v){
            $res[$k]['person'] = $users[$v['person']];    //获取盘点人的姓名
            $res[$k]['date'] = date('Y-m-d',strtotime($v['date'])); //修改时间样式
            $res[$k]['create_time'] = date('Y-m-d',strtotime($v['create_time']));   //修改时间样式
        }
        $data = ['map'=>$map,'users'=>$userres,'data'=>$res];
        $this -> ajaxReturn($data,'JSON');
    }

    public function addpd()
    {
        ob_clean();
        //获取当前登录用户为制单人
        $user_name = session('name');

        $date = date('Y-m-d');

        $data = ['user_name'=>$user_name,'date'=>$date];
        $this -> ajaxReturn($data,'JSON');
    }

    public function storepd()
    {
        ob_clean();
        //判断是否非法访问 非法方式返回错误
        if (!IS_POST) {
            $this -> ajaxReturn(['status'=>1,'msg'=>'请求方式不合法'],'JSON');
        }

        //创建验证规则
        $rules = [
            ['date','require','盘点日期不能为空'],
        ];

        $Orders = M('jxc_order'); // 实例化对象
        $post_data = I('post.data');

        if (!$Orders->validate($rules) -> create($post_data)){     // 如果创建失败 表示验证没有通过 输出错误提示信息
            $this -> ajaxReturn(['status'=>1,'msg'=>'验证失败'.$Orders->getError()],'JSON');
        }else if (!isset($_POST['date'])){
            $this -> ajaxReturn(['status'=>1,'msg'=>'验证失败,字段填写不完整'],'JSON');
        }else {     // 验证通过 可以进行其他数据操作
            //验证商品信息
            if ( isset($_POST['number'][0]) && !empty($_POST['number'][0]) && isset($_POST['price'][0]) && !empty($_POST['price'][0])) {
                //创建验证规则
                $ruls = [
                    ['price[0]', 'require', '销售价格不能为空'],
                    ['price[0]', '/^(([0-9]+\.[0-9]*[1-9][0-9]*)|([0-9]*[1-9][0-9]*\.[0-9]+)|([0-9]*[1-9][0-9]*))$/', '销售价格必须为数字'],
                    ['number[0]', 'require', '数量不能为空'],
                    ['number[0]', '/\d+/', '数量必须为数字']
                ];

                $Order_goods = M("jxc_order_goods"); // 实例化对象

                if (!$Order_goods->validate($ruls)->create($post_data)) {     // 如果创建失败 表示验证没有通过 输出错误提示信息
                    $this -> ajaxReturn(['status'=>1,'msg'=>'商品信息验证失败'.$Order_goods->getError()],'JSON');
                } else {// 验证通过 可以进行其他数据操作
                    //获取数据

                    $centre_id = session('centre_id');   //获取当前门店ID  测试为2
                    $user_id = session("user_id");  //获取当前登陆用户的user_id  总部后台管理系统获取mg_id  会员管理系统获取user_id
                    $order_num = $this -> getNum(3);
                    $fields['order_num'] = $order_num;        //订单编号
                    $fields['order_type'] = 3;  //订单类别 盘点
                    $fields['date'] = $post_data['date']; //日期
                    $fields['person'] = $user_id;   //获取盘点人ID
                    $fields['order_status'] = 0;   //设置盘点单状态
                    $fields['centre_id'] = $centre_id;      //设置所属中心ID
                    $fields['user_id'] = $user_id;      //设置制单人ID
                    $fields['status'] = 1;      //设置状态正常 0为安全删除
                    $fields['notes'] = $post_data['notes'];

                    //创建模型对象
                    $Orders->create($fields);
                    //执行添加订单
                    $res = $Orders->add();

                    if ($res) {
                        //获取所有的商品信息
                        $goods_ids = $post_data['goods_id'];
                        $prices = $post_data['price'];
                        $numbers = $post_data['number'];
                        $good_notes = $post_data['good_notes'];
                        $pd_stocks = $post_data['pd_stock'];
                        $order_id = $res;

                        //重组数据结构 转换为数据库需要的格式
                        $gfields = [];  //商品数组
                        $ck = [];     //商品ID为值,对应入库的商品
                        $rk = [];       //商品ID为值 对应出库的商品
                        foreach ($goods_ids as $k => $v) {
                            $gfields[$k]['good_id'] = $v;
                            $gfields[$k]['pd_number'] = $numbers[$k];  //实盘数量
                            $gfields[$k]['price'] = $prices[$k];
                            $gfields[$k]['good_notes'] = $good_notes[$k];
                            $gfields[$k]['order_id'] = $order_id;
                            $gfields[$k]['pd_stock'] = $pd_stocks[$k];  //当前库存
                            if ($pd_stocks[$k]>$numbers[$k]){  //如果库存数量大于实盘数量 即报损出库 添加出库单

                                $ck[$v] = $pd_stocks[$k]-$numbers[$k]; //存储出库的商品ID为键 值为数量差
                                $gfields[$k]['pd_status'] = 1;
                                $gfields[$k]['number'] = $pd_stocks[$k]-$numbers[$k];
                            }else if($pd_stocks[$k]<$numbers[$k]){     //如果库存数量小于实盘数量 即报益入库 添加入库单

                                $rk[$v] = $numbers[$k]-$pd_stocks[$k]; //存储入库的商品ID为键 值为数量差
                                $gfields[$k]['pd_status'] = 2;
                                $gfields[$k]['number'] = $numbers[$k]-$pd_stocks[$k];
                            }else{
                                $gfields[$k]['pd_status'] = 3;
                            }
                        }

                        $re = $Order_goods->addAll($gfields);

                        if ($re) {
                            //添加盘点单成功后执行判断修改库存
                            $Stock = M('jxc_stock');
                            //执行添加库存
                            foreach($rk as $k => $v){
                                $where = [
                                    'centre_id'=>$centre_id,
                                    'good_id'=>$k
                                ];
                                //查找当前商品
                                $now = $Stock->where($where)->find();
                                //执行增加库存
                                $number['number'] = $now['number'] + $v;
                                $Stock->where($where)->save($number);
                            }
                            //执行减少库存
                            foreach($ck as $k => $v){
                                $where = [
                                    'centre_id'=>$centre_id,
                                    'good_id'=>$k
                                ];
                                //查找当前商品
                                $now = $Stock->where($where)->find();
                                //执行减少库存
                                $number['number'] = $now['number'] - $v;
                                $Stock->where($where)->save($number);
                            }

                            $this -> ajaxReturn(['status'=>2,'msg'=>'添加成功'],'JSON');
                        } else {
                            $this -> ajaxReturn(['status'=>1,'msg'=>'添加盘点商品失败,'.$Order_goods->getError()],'JSON');
                        }
                    } else {
                        $this -> ajaxReturn(['status'=>1,'msg'=>'添加盘点单失败'.$Orders->getError()],'JSON');
                    }
                }
            }else{
                $this -> ajaxReturn(['status'=>1,'msg'=>'验证失败,商品信息填写不完整'],'JSON');
            }
        }
    }
    
    public function showpd()
    {
        ob_clean();
        $id = I('post.id');    //获取要查询的盘点单的ID
        $Orders = M('jxc_order'); //实例化盘点单对象
        $order_info = $Orders->where('id='.$id)->find(); //获取盘点单记录

        $Order_goods = M('jxc_order_goods');
        $order_goods = $Order_goods->where('order_id='.$id)->select();

        $centre_id = session('centre_id');   //获取当前门店ID  测试为2
        //获取当前中心所有的用户信息用户用于填充采购人 制单人姓名
        $useres = M('xueyuan_baoming') -> where('centre_id='.$centre_id) -> select();
        //重组结构
        foreach ($useres as $k => $v){
            $users[$v['user_id']] = $v['name'];
        }

        $where = [
            'centre_id'=>$centre_id,
        ];
        $goodres = M('jxc_goods')->where($where)->select();
        //重组结构
        foreach($goodres as $k =>$v){
            $goods[$v['id']] = $v;
        }

        //重组订单信息结构
        $info = [];
        $info['id'] = $order_info['id'];
        $info['date'] = date('Y-m-d',strtotime($order_info['date']));  //采购日期
        $info['person'] = $users[$order_info['person']];   //盘点人
        $info['notes'] = $order_info['notes'];

        //重组订单商品信息结构
        $new_goods = [];
        foreach($order_goods as $k => $v){
            $new_goods[$k]['good_num'] = $goods[$v['good_id']]['good_num'];
            $new_goods[$k]['good_name'] = $goods[$v['good_id']]['good_name'];
            $new_goods[$k]['mini_imgpath'] = $goods[$v['good_id']]['mini_imgpath'];
            $new_goods[$k]['imgpath'] = $goods[$v['good_id']]['imgpath'];
            $new_goods[$k]['spec'] = $goods[$v['good_id']]['spec'];
            $new_goods[$k]['unit'] = $goods[$v['good_id']]['unit'];
            $new_goods[$k]['number'] = $v['number'];
            $new_goods[$k]['price'] = $v['price'];
            $new_goods[$k]['sumprice'] = sprintf("%.2f",$v['number']*$v['price']);
            $new_goods[$k]['good_notes'] = $v['good_notes'];
        }

        $data = ['order_info'=>$info,'order_goods'=>$new_goods];
        $this -> ajaxReturn($data,'JSON');

    }

    public function deletepd()
    {
        $id = I('post.id');
        $fields['status'] = 0;
        $Orders = M('jxc_order');
        $res = $Orders->where("id = '{$id}'")->save($fields);;
        if(false !== $res){
            //盘点单作废 获取关联商品 判断出库还是入库 进行修改库存
            $order_goods = M('jxc_order_goods')->where('order_id='.$id)->select();
            //循环判断是出库还是入库
            $Stock = M('jxc_stock');
            $centre_id = session('centre_id');
            foreach($order_goods as $k => $v){
                if($v['pd_status'] == 1){   //出库
                    $where = [
                        'centre_id'=>$centre_id,
                        'good_id'=>$v['good_id']
                    ];
                    //查找当前商品
                    $now = $Stock->where($where)->find();
                    //执行作废增加库存
                    $number['number'] = $now['number'] + $v['number'];
                    $Stock->where($where)->save($number);
                }else if($v['pd_status']== 2){  //入库
                    $where = [
                        'centre_id'=>$centre_id,
                        'good_id'=>$v['good_id']
                    ];
                    //查找当前商品
                    $now = $Stock->where($where)->find();
                    //执行作废减少库存
                    $number['number'] = $now['number'] - $v['number'];
                    $Stock->where($where)->save($number);
                }
            }
            //写入LOG
            $order_num = M('jxc_order')->where("id = $id")->find()['order_num'];
            $content = "作废出库单,单号:".$order_num."成功";
            setLog($content);
            $this -> ajaxReturn(['status'=>2,'msg'=>'作废盘点单成功'],'JSON');
        } else {
            $this -> ajaxReturn(['status'=>1,'msg'=>'作废盘点单失败'],'JSON');
        }
    }
}