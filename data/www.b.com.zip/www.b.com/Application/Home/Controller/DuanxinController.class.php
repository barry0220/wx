<?php
namespace Home\Controller;
use Think\Controller;
class DuanxinController extends CommonController {
  //记录
    public function index(){
       $this->display();
    }
    public function fasongjilu(){
       $this->display();
    }
    public function chongzhi(){
      $centre_id=session('centre_id');
      $arr=M('crm_dx_fei')->where("centre_id='$centre_id' and dx_shu=1666 and f_jine=100 and status='支付成功'")->getField('f_id');
      if($arr!=null){
        $this->da=1;
      }
    	$this->display();
    }
    public function chongzhijilu(){
    	$this->display();
    }
    public function templatedesign(){
        $centre_id=session('centre_id');
        $a=M('wx_centre')->where("centre_id='$centre_id'")->find();
        $arr=M('crm_dx_mb')->where('is_show=1')->select();
        foreach ($arr as $key => $value) {
           switch ($value['mb_type']) {
               case '生日提醒':
                   if($a['dx_birthday']==$value['mb_id']){
                    $arr[$key]['status']=1;
                   }
                   break;
               case '签约短信':
                   if($a['dx_qianyue']==$value['mb_id']){
                    $arr[$key]['status']=1;
                   }
                   break;
               case '合约到期提醒':
                   if($a['dx_hydq']==$value['mb_id']){
                    $arr[$key]['status']=1;
                   }
                   break;
               case '扣课短信通知':
                   if($a['dx_kk']==$value['mb_id']){
                    $arr[$key]['status']=1;
                   }
                   break;
           }
        }
        $this->dx=M("crm_dx_mb")->select();
        $this->data=$arr;
    	$this->display();
    }
    public function xinxifasong(){
    	$this->display();
    }
    public function qiy(){
        $centre_id=session('centre_id');
        $mb_id=I('post.mb_id');
        $arr=M('crm_dx_mb')->where("mb_id='$mb_id'")->find();
        $tai=I('post.tai');
        if($tai==1){
          switch ($arr['mb_type']) {
              case '生日提醒':
                  $data['dx_birthday']=0;
                  break;
              case '签约短信':
                  $data['dx_qianyue']=0;
                  break;
              case '合约到期提醒':
                  $data['dx_hydq']=0;
                  break;
              case '扣课短信通知':
                  $data['dx_kk']=0;
                  break;
          }
          if(M('wx_centre')->where("centre_id='$centre_id'")->save($data)){
            $this->ajaxReturn(1,'JSON');
          }
        }else{
          switch ($arr['mb_type']) {
              case '生日提醒':
                  $data['dx_birthday']=$mb_id;
                  break;
              case '签约短信':
                  $data['dx_qianyue']=$mb_id;
                  break;
              case '合约到期提醒':
                  $data['dx_hydq']=$mb_id;
                  break;
              case '扣课短信通知':
                  $data['dx_kk']=$mb_id;
                  break;
          }
          if(M('wx_centre')->where("centre_id='$centre_id'")->save($data)){
            $this->ajaxReturn(2,'JSON');
          }
        }
    }
}