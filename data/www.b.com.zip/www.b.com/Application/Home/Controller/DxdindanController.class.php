<?php
namespace Home\Controller;
use Think\Controller;
class DxdindanController extends Controller {
  //短信订单信息
    public function index(){
       header("access-control-allow-origin:*");
       
   }
}