<?php
namespace Home\Controller;
use Think\Controller;
/**
 *
 * 进销存模块 商品类别控制器
 *
 */
class JxcExpressController extends CommonController {
    //获取当前中心商品类别信息
    public function index(){
        ob_clean();

        $centre_id = session('centre_id');   //获取当前门店ID
        //判断是否存在条件查询
        $search = I('post.search');
        $page = I('post.page') ? I('post.page') : 1;
        $pageone=I('post.pageone') ? I('post.pageone') : 10;//每页数据
        $map['search'] = $search;  //条件返回
        $map['page'] = $page;
        $map['pageone'] = $pageone;
        //组装where条件
        $where = [
            'centre_id' => $centre_id,
            'status'=>1
        ];

        if($search){
            $where['express_name'] = [['like', "%{$search}%"]];
        }

        $Express = M('jxc_express');      //实例化

        $count = $Express ->where($where)->count();   //获取数据总数
        $pagetotal=ceil($count/$pageone);   //总页数
        $map['pagetotal'] = $pagetotal; //返回参数 总页数
        $pyl=($page-1)*$pageone;//偏移量

        $res = $Express  -> where($where)->order('id desc')->limit($pyl,$pageone) -> select();   //获取结果信息
        $data = ['map'=>$map,'data'=>$res];

        $this -> ajaxReturn($data,'JSON');
    }

    //执行添加商品类别
    public function store()
    {
        ob_clean();
        //判断是否非法访问 非法方式返回错误
        if (!IS_POST) {
            $this -> ajaxReturn(['status'=>1,'msg'=>'请求方式不合法'],'JSON');
        }

        //创建验证规则
        $rules = [
            ['express_name','require','物流公司名称不能为空'],
        ];

        $Express = D("jxc_express"); // 实例化对象

        if (!$Express->validate($rules) -> create()){     // 如果创建失败 表示验证没有通过  输出错误提示信息
            $this -> ajaxReturn(['status'=>1,'msg'=>"验证失败".$Express->getError()],'JSON');
        }else{     // 验证通过 可以进行其他数据操作
            $centre_id = session('centre_id');   //获取当前门店ID  测试为1

            //获取数据
            $fields['express_name'] = I('post.express_name');
            $fields['centre_id'] = $centre_id;
            $user_id = session("user_id");  //获取当前登陆用户的user_id  总部后台管理系统获取mg_id  会员管理系统获取user_id
            $fields['user_id'] = $user_id;
            $fields['status'] = 1;
            //创建模型对象
            $Express->create($fields);
            //执行添加
            $res = $Express->add();

            if($res){
                $this -> ajaxReturn(['status'=>2,'msg'=>'添加成功'],'JSON');
            } else {
                $this -> ajaxReturn(['status'=>1,'msg'=>'添加失败'],'JSON');
            }
        }
    }



    //修改商品类别信息
    public function update()
    {
        ob_clean();
        //判断是否非法访问 非法方式返回错误
        if (!IS_POST) {
            $this -> ajaxReturn(['status'=>1,'msg'=>'请求方式不合法'],'JSON');
        }
        $express_id = I('post.id');    //获取要修改的ID
        //创建验证规则
        $rules = [
            ['express_name','require','物流公司名称不能为空'],
        ];

        $Express = M('jxc_express'); // 实例化对象

        if (!$Express->validate($rules) -> create()){     // 如果创建失败 表示验证没有通过 输出错误提示信息
            $this -> ajaxReturn(['status'=>1,'msg'=>"验证失败".$Express->getError()],'JSON');

        }else{     // 验证通过 可以进行其他数据操作
            //获取数据
            $fields['express_name'] = I('post.express_name');
            //获取原来的名称用于写入日志
            $old_name = $Express->where('id='.$express_id)->find()['express_name'];
            //执行修改
            $res = $Express->where('id='.$express_id)->save($fields);

            if($res){
                //写入LOG
                $content = "修改物流公司".$old_name."名称为".$fields['express_name'];
                setLog($content);
                $this -> ajaxReturn(['status'=>2,'msg'=>'修改成功'],'JSON');
            } else {
                $this -> ajaxReturn(['status'=>1,'msg'=>'修改失败'],'JSON');
            }
        }


    }

    //删除商品类别信息  安全删除  状态修改为0
    public function delete()
    {
        ob_clean();
        $express_id= I('post.id');

        $fields['status'] = 0;
        $res = M('jxc_express')->where("id = '{$express_id}'")->save($fields);

            if($res){
                //写入LOG
                $express_name = M('jxc_express')->where("id = '{$express_id}'")->find()['express_name'];
                $content = "删除物流公司".$express_name."成功";
                setLog($content);
//            $this->success('删除成功', U('JxcExpress/index'), 3);
                $this -> ajaxReturn(['status'=>2,'msg'=>'删除成功'],'JSON');
            } else {
                $this -> ajaxReturn(['status'=>1,'msg'=>'删除失败'],'JSON');
//            $this->success('删除失败', U('JxcExpress/index'), 3);
            }
    }
}