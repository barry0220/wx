<?php
namespace Home\Controller;
use Think\Controller;
class kecbjieController extends CommonController {
	//课时包接口
    public function index(){
      header("access-control-allow-origin:*");
    	if(isset($_POST['page'])){
         $page=$_POST['page'];
       }else{
         $page=1;
       }
       $uid=I('post.uid');
      $centre_id=M('xueyuan_baoming')->where("user_id='$uid'")->getField('centre_id');
       $num=M("crm_goods")->where("l_id=10 and status=1 and (centre_id=0 or centre_id='$centre_id')")->count();
       $pageone=10;//每页数据
       $pagetotal=ceil($num/$pageone);
       $pyl=($page-1)*$pageone;//偏移量
       $sql="SELECT * FROM crm_goods where l_id=10 and status=1 and (centre_id=0 or centre_id='$centre_id') order by s_id desc limit $pyl,$pageone";
       $arr=M()->query($sql);
       foreach ($arr as $key => $value) {
         $arr[$key]['page']=$page;
         $arr[$key]['pagetotal']=$pagetotal;
         $arr[$key]['num']=$num;
       }
       $this->ajaxReturn($arr,'JSON');
    }
    //优惠劵接口
    public function index1(){
      header("access-control-allow-origin:*"); 
      if(isset($_POST['page'])){
         $page=$_POST['page'];
       }else{
         $page=1;
       }
       $uid=I('post.uid');
      $centre_id=M('xueyuan_baoming')->where("user_id='$uid'")->getField('centre_id');
       $num=M("crm_goods")->where("l_id=11 and status=1 and (centre_id=0 or centre_id='$centre_id')")->count();
       $pageone=10;//每页数据
       $pagetotal=ceil($num/$pageone);
       $pyl=($page-1)*$pageone;//偏移量
       $sql="SELECT * FROM crm_goods where l_id=11 and status=1 and (centre_id=0 or centre_id='$centre_id') order by s_id desc limit $pyl,$pageone";
       $arr=M()->query($sql);
       foreach ($arr as $key => $value) {
         $arr[$key]['page']=$page;
         $arr[$key]['pagetotal']=$pagetotal;
         $arr[$key]['num']=$num;
       }
       $this->ajaxReturn($arr,'JSON');
    }
    //添加课时包
    public function add(){
      header("access-control-allow-origin:*"); 
       $data['s_name']=I('post.s_name');
       $data['price']=I('post.price');
       $data['k_shu']=I('post.k_shu');
       $uid=I('post.uid');
      $centre_id=M('xueyuan_baoming')->where("user_id='$uid'")->getField('centre_id');
       $data['centre_id']=$centre_id;
       $data['create_name']=$uid;
       $data['source']="PC";
       $data['l_id']=10;
       if(M('crm_goods')->add($data)){
         $this->redirect("index");
       }
    }
    //删除课时包
    public function shanchu(){
      header("access-control-allow-origin:*"); 
      $crm_goods=M("crm_goods");
      $id=I('post.id');
      $centre_id=M("crm_goods")->where("s_id=".$id)->getField("centre_id");
      if($centre_id==0){
        echo 2;die;//如果是总部将不能删除
      }
      $data['status']=0;
      $rel=$crm_goods->where("s_id=".$id)->save($data);
      if($rel){
        echo 1;
      }
    }
    //添加优惠劵
    public function addy(){
      header("access-control-allow-origin:*"); 
       $data['s_name']=I('post.s_name');
       $data['price']=I('post.price');
       $data['k_shu']=I('post.k_shu');
       $uid=I('post.uid');
      $centre_id=M('xueyuan_baoming')->where("user_id='$uid'")->getField('centre_id');
       $data['centre_id']=$centre_id;
       $data['create_name']=$uid;
       $data['source']="PC";
       $data['l_id']=11;
       if(M('crm_goods')->add($data)){
         $this->redirect("kecb/index1");
       }
    }
     //删除优惠劵
    public function shanchuy(){
      header("access-control-allow-origin:*"); 
      $crm_goods=M("crm_goods");
      $id=I('post.id');
      $centre_id=$crm_goods->where("s_id=".$id)->getField("centre_id");
      if($centre_id==0){
        echo 2;die;//如果是总部将不能删除
      }
      $data['status']=0;
      $rel=$crm_goods->where("s_id=".$id)->save($data);
      if($rel){
        echo 1;
      }
    }
  }