<?php
namespace Home\Controller;
use Think\Controller;
class DxuserController extends Controller {
  //模板记录
    public function index(){
    	header("access-control-allow-origin:*");
       $yueling1=I('post.yueling1');
       $yueling2=I('post.yueling2');
       $type=I('post.type');
       $name=I('post.name');
       $stab=I('post.stab');
       $centre_id=session('centre_id');
       $shij=date('Y-m-d');
      if($yueling1!=null and $yueling2!=null and $type!=null and $name!=null and $stab==null){
       $arr=M('wx_user')->where("belong='$centre_id' and vip='$type' and baobao_name='$name'")->field('user_id,baobao_name,baobao_birthday,vip,phone1,phone2,phone3,phone4,phone5,phone6')->select();
       foreach ($arr as $key => $value) {
        $d=strtotime($shij)-strtotime($value['baobao_birthday']);
        $e=$d/2592000;//一个月的时间，单位秒
        $f=round($e);//月龄取整
        if($f==576){
          $arr[$key]['yueling']=0;
        }else{
          $arr[$key]['yueling']=$f;
        }
        if($value['vip']==1){
          $arr[$key]['vip']='会员';
        }else{
          $arr[$key]['vip']='非会员';
        }
        if($value['phone1']!=null){
          $arr[$key]['phone']=$value['phone1'];
        }else if($value['phone2']!=null){
          $arr[$key]['phone']=$value['phone2'];
        }else if($value['phone3']!=null){
          $arr[$key]['phone']=$value['phone3'];
        }else if($value['phone4']!=null){
          $arr[$key]['phone']=$value['phone4'];
        }else if($value['phone5']!=null){
          $arr[$key]['phone']=$value['phone5'];
        }else if($value['phone6']!=null){
          $arr[$key]['phone']=$value['phone6'];
        }
      }
      foreach ($arr as $key => $value) {
        if($arr[$key]['yueling']>=$yueling1 and $arr[$key]['yueling']<=$yueling2){
                  $ar[$key] = $value;
              }else{
                  unset($ar[$key]);
              }
      }
    }else if($yueling1!=null and $yueling2!=null and $type==null and $name==null and $stab==null){
       $arr=M('wx_user')->where("belong='$centre_id'")->field('user_id,baobao_name,baobao_birthday,vip,phone1,phone2,phone3,phone4,phone5,phone6')->select();
       foreach ($arr as $key => $value) {
        $d=strtotime($shij)-strtotime($value['baobao_birthday']);
        $e=$d/2592000;//一个月的时间，单位秒
        $f=round($e);//月龄取整
        if($f==576){
          $arr[$key]['yueling']=0;
        }else{
          $arr[$key]['yueling']=$f;
        }
        if($value['vip']==1){
          $arr[$key]['vip']='会员';
        }else{
          $arr[$key]['vip']='非会员';
        }
        if($value['phone1']!=null){
          $arr[$key]['phone']=$value['phone1'];
        }else if($value['phone2']!=null){
          $arr[$key]['phone']=$value['phone2'];
        }else if($value['phone3']!=null){
          $arr[$key]['phone']=$value['phone3'];
        }else if($value['phone4']!=null){
          $arr[$key]['phone']=$value['phone4'];
        }else if($value['phone5']!=null){
          $arr[$key]['phone']=$value['phone5'];
        }else if($value['phone6']!=null){
          $arr[$key]['phone']=$value['phone6'];
        }
      }
      foreach ($arr as $key => $value) {
        if($arr[$key]['yueling']>=$yueling1 and $arr[$key]['yueling']<=$yueling2){
                  $ar[$key] = $value;
              }else{
                  unset($ar[$key]);
              }
      }
    }else if($yueling1==null and $yueling2==null and $type!=null and $name==null and $stab==null){
       $arr=M('wx_user')->where("belong='$centre_id' and vip='$type'")->field('user_id,baobao_name,baobao_birthday,vip,phone1,phone2,phone3,phone4,phone5,phone6')->select();
       foreach ($arr as $key => $value) {
        $d=strtotime($shij)-strtotime($value['baobao_birthday']);
        $e=$d/2592000;//一个月的时间，单位秒
        $f=round($e);//月龄取整
        if($f==576){
          $arr[$key]['yueling']=0;
        }else{
          $arr[$key]['yueling']=$f;
        }
        if($value['vip']==1){
          $arr[$key]['vip']='会员';
        }else{
          $arr[$key]['vip']='非会员';
        }
        if($value['phone1']!=null){
          $arr[$key]['phone']=$value['phone1'];
        }else if($value['phone2']!=null){
          $arr[$key]['phone']=$value['phone2'];
        }else if($value['phone3']!=null){
          $arr[$key]['phone']=$value['phone3'];
        }else if($value['phone4']!=null){
          $arr[$key]['phone']=$value['phone4'];
        }else if($value['phone5']!=null){
          $arr[$key]['phone']=$value['phone5'];
        }else if($value['phone6']!=null){
          $arr[$key]['phone']=$value['phone6'];
        }
      }
      foreach ($arr as $key => $value) {
        $ar[$key] = $value;
      }
    }else if($yueling1==null and $yueling2==null and $type!=null and $name!=null and $stab==null){
       $arr=M('wx_user')->where("belong='$centre_id' and baobao_name='$name'")->field('user_id,baobao_name,baobao_birthday,vip,phone1,phone2,phone3,phone4,phone5,phone6')->select();
       foreach ($arr as $key => $value) {
        $d=strtotime($shij)-strtotime($value['baobao_birthday']);
        $e=$d/2592000;//一个月的时间，单位秒
        $f=round($e);//月龄取整
        if($f==576){
          $arr[$key]['yueling']=0;
        }else{
          $arr[$key]['yueling']=$f;
        }
        if($value['vip']==1){
          $arr[$key]['vip']='会员';
        }else{
          $arr[$key]['vip']='非会员';
        }
        if($value['phone1']!=null){
          $arr[$key]['phone']=$value['phone1'];
        }else if($value['phone2']!=null){
          $arr[$key]['phone']=$value['phone2'];
        }else if($value['phone3']!=null){
          $arr[$key]['phone']=$value['phone3'];
        }else if($value['phone4']!=null){
          $arr[$key]['phone']=$value['phone4'];
        }else if($value['phone5']!=null){
          $arr[$key]['phone']=$value['phone5'];
        }else if($value['phone6']!=null){
          $arr[$key]['phone']=$value['phone6'];
        }
      }
      foreach ($arr as $key => $value) {
        $ar[$key] = $value;
      }
    }else if($yueling1!=null and $yueling2!=null and $type!=null and $name==null and $stab==null){
       $arr=M('wx_user')->where("belong='$centre_id' and vip='$type'")->field('user_id,baobao_name,baobao_birthday,vip,phone1,phone2,phone3,phone4,phone5,phone6')->select();
       foreach ($arr as $key => $value) {
        $d=strtotime($shij)-strtotime($value['baobao_birthday']);
        $e=$d/2592000;//一个月的时间，单位秒
        $f=round($e);//月龄取整
        if($f==576){
          $arr[$key]['yueling']=0;
        }else{
          $arr[$key]['yueling']=$f;
        }
        if($value['vip']==1){
          $arr[$key]['vip']='会员';
        }else{
          $arr[$key]['vip']='非会员';
        }
        if($value['phone1']!=null){
          $arr[$key]['phone']=$value['phone1'];
        }else if($value['phone2']!=null){
          $arr[$key]['phone']=$value['phone2'];
        }else if($value['phone3']!=null){
          $arr[$key]['phone']=$value['phone3'];
        }else if($value['phone4']!=null){
          $arr[$key]['phone']=$value['phone4'];
        }else if($value['phone5']!=null){
          $arr[$key]['phone']=$value['phone5'];
        }else if($value['phone6']!=null){
          $arr[$key]['phone']=$value['phone6'];
        }
      }
      foreach ($arr as $key => $value) {
        if($arr[$key]['yueling']>=$yueling1 and $arr[$key]['yueling']<=$yueling2){
                  $ar[$key] = $value;
              }else{
                  unset($ar[$key]);
              }
      }
    }else if($stab!=null){
       $staa='-'.$stab.'-';
       $ar=M('wx_user')->where("belong='$centre_id' and baobao_birthday like '%$staa%'")->field('user_id,baobao_name,baobao_birthday,vip,phone1,phone2,phone3,phone4,phone5,phone6,baobao_birthday')->order('baobao_birthday')->select();
       foreach ($ar as $key => $value) {
        $d=strtotime($shij)-strtotime($value['baobao_birthday']);
        $e=$d/2592000;//一个月的时间，单位秒
        $f=round($e);//月龄取整
        if($f==576){
          $ar[$key]['yueling']=0;
        }else{
          $ar[$key]['yueling']=$f;
        }
        if($value['vip']==1){
          $ar[$key]['vip']='会员';
        }else{
          $ar[$key]['vip']='非会员';
        }
        if($value['phone1']!=null){
          $ar[$key]['phone']=$value['phone1'];
        }else if($value['phone2']!=null){
          $ar[$key]['phone']=$value['phone2'];
        }else if($value['phone3']!=null){
          $ar[$key]['phone']=$value['phone3'];
        }else if($value['phone4']!=null){
          $ar[$key]['phone']=$value['phone4'];
        }else if($value['phone5']!=null){
          $ar[$key]['phone']=$value['phone5'];
        }else if($value['phone6']!=null){
          $ar[$key]['phone']=$value['phone6'];
        }
      }
    }
       $this->ajaxReturn($ar,'JSON');
    }
}