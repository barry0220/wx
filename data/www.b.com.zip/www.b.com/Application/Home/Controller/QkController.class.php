<?php
namespace Home\Controller;
use Think\Controller;
class QkController extends Controller {
    //当月新增名单
     public function dyxz()
    {
//        根据回传条件判断拼接查询条件
        header("access-control-allow-origin:*");
        $condition = I('post.');
        $centerid = session('centre_id');
        $yue=I('post.nianyue');
        if(empty($yue)){
          $yue=date("Y-m");
        }
        $user_id=session('user_id');
        $gw=M('xueyuan_baoming')->where("user_id='$user_id'")->getField("gangwei");
        $start_time=$yue.'-01';
        $end_time=$yue.'-31';
//        $centerid = session('centre_id');
        if($gw=='中心总监'){
            $where = "a.belong={$centerid} and a.yon=2 and a.status=1 and a.create_time>='$start_time' and a.create_time<='$end_time' and a.vip=0";
        }else{
            $where = "a.belong={$centerid} and a.yon=2 and a.status=1 and a.create_time>='$start_time' and a.create_time<='$end_time' and a.gw_id='$user_id' and a.vip=0";

        }
        if ($condition['name']){
            $where .= "  and (a.baobao_name like '%{$condition['name']}%' or a.baobao_name2 like '%{$condition['name']}%') ";
        }

        if ($condition['pname']){
            $where .= " and (a.name1 like '%{$condition['pname']}%' or a.name2 like '%{$condition['pname']}%' or a.name3 like '%{$condition['pname']}%' or a.name4 like '%{$condition['pname']}%' or a.name5 like '%{$condition['pname']}%' or a.name6 like '%{$condition['pname']}%') ";
        }

        if ($condition['pphone']){
            $where .= " and (a.phone1 like '%{$condition['pphone']}%' or a.phone2 like '%{$condition['pphone']}%' or a.phone3 like '%{$condition['pphone']}%' or a.phone4 like '%{$condition['pphone']}%' or a.phone5 like '%{$condition['pphone']}%' or a.phone6 like '%{$condition['pphone']}%') ";
        }

        if ($condition['type']){
            $where .= " and a.gj_type='{$condition['type']}'" ;
        }

        if ($condition['salesperson']){
            $where .= " and a.gw_id={$condition['salesperson']} ";
        }

//        链表联查
        if (!empty($condition['page'])){
            $page = $condition['page'];
        }else{
            $page =1;
        }

        $count = M('wx_user as a')
            ->join("left join xueyuan_baoming as b on a.gw_id=b.user_id")
            ->field("a.baobao_name,a.name1,a.name2,a.name3,a.name4,a.name5,a.name6,a.phone1,a.phone2,a.phone3,a.phone4,a.phone5,a.phone6,a.gj_type,a.gw_id,a.user_id,b.username,a.baobao_sex,a.laiyuan,a.beizhu")
            ->where($where)
            ->count();
        $pageone=10;//每页数据
        $pagetotal=ceil($count/$pageone);
        $pyl=($page-1)*$pageone;//偏移量
        $results = M('wx_user as a')
            ->join("left join xueyuan_baoming as b on a.gw_id=b.user_id")
            ->limit($pyl,$pageone)
            ->where($where)
            ->field("a.baobao_name,a.name1,a.name2,a.name3,a.name4,a.name5,a.name6,a.phone1,a.phone2,a.phone3,a.phone4,a.phone5,a.phone6,a.gj_type,a.gw_id,a.user_id,b.username,a.baobao_sex,a.laiyuan,a.beizhu,a.baobao_birthday")
            ->select();
       foreach ($results as $key => $value) {
            $results[$key]['page'] = $page;
            $results[$key]['pagetotal'] = $pagetotal;
            $results[$key]['num'] = $count;
//            关系判断
            if (!empty($value['name1'])) {
                $results[$key]['p_name'] = $value['name1'];
                $results[$key]['guanxi'] = '爸爸';
            } else if (!empty($value['name2'])) {
                $results[$key]['p_name'] = $value['name2'];
                $results[$key]['guanxi'] = '妈妈';
            } else if (!empty($value['name3'])) {
                 $results[$key]['p_name'] = $value['name3'];
                 $results[$key]['guanxi'] = '爷爷';
            } else if (!empty($value['name4'])) {
                 $results[$key]['p_name'] = $value['name4'];
                 $results[$key]['guanxi'] = '奶奶';
            } else if (!empty($value['name5'])) {
                 $results[$key]['p_name'] = $value['name5'];
                 $results[$key]['guanxi'] = '姥爷';
            } else if (!empty($value['name6'])) {
                 $results[$key]['p_name'] = $value['name6'];
                 $results[$key]['guanxi'] = '姥姥';
            } else {
                 $results[$key]['p_name'] = "";
            }
//        手机
            if (!empty($value['phone1'])) {
                 $results[$key]['p_phone'] = $value['phone1'];
            } else if (!empty($value['phone2'])) {
                 $results[$key]['p_phone'] = $value['phone2'];
            } else if (!empty($value['phone3'])) {
                 $results[$key]['p_phone'] = $value['phone3'];
            } else if (!empty($value['phone4'])) {
                 $results[$key]['p_phone'] = $value['phone4'];
            } else if (!empty($value['phone5'])) {
                 $results[$key]['p_phone'] = $value['phone5'];
            } else if (!empty($value['phone6'])) {
                 $results[$key]['p_phone'] = $value['phone6'];
            } else {
                 $results[$key]['p_phone'] = "";
            }
            $last = M('crm_gj')->where("bao_id={$value['user_id']}")->order("create_time desc")->find();
            $results[$key]['last'] = $last['create_time'];
//
        }

       // $a = M()->getLastsql();
       // var_dump($a);die;

       if ($results == false){
           json('10002',"查询失败");
       }
        if ($results == null){
            json('10003',"没有检索到数据");
        }
        json('10001',$results);

    }


    //跟进主页
    public function xz(){
        header("access-control-allow-origin:*");
        $centre_id=session('centre_id');
        $yue=I('post.yue');
        if(empty($yue)){
          $yue=date("Y-m");
        }
        $time=date("Y-m-d");
        $user_id=session('user_id');
        $start_time=$yue.'-01';
        $end_time=$yue.'-31';
        $arr['yue']=date("m");
        $gw=M('xueyuan_baoming')->where("user_id='$user_id'")->getField("gangwei");
      if($gw=='中心总监'){
        $arr['xzmd']=M('wx_user')->where("yon=2 and status=1 and create_time>='$start_time' and create_time<='$end_time' and belong='$centre_id' and vip=0")->count();//当月新增名单
        $arr['gjjl']=M('crm_gj')->where("create_time>='$start_time' and create_time<='$end_time' and centre_id='$centre_id'")->count();//当月跟进记录
        $arr['mdzs']=M('wx_user')->where("status=1 and yon=2 and belong='$centre_id' and vip=0")->count();//名单总数
        $arr['hts']=M('crm_kjilu')->where("centre_id='$centre_id' and status=1 and time>='$start_time' and time<='$end_time'")->count();//当月合同数
        $arr['htje']=M('crm_kjilu')->where("centre_id='$centre_id' and status=1 and time>='$start_time' and time<='$end_time'")->sum('shishou');//当月合同金额
        $arr['qjrgj']=M('crm_gj')->where("create_time like '%$time%' and centre_id='$centre_id' and vip=0")->count();//潜客今日跟进记录
        $arr['qxzmd']=M('wx_user')->where("yon=2 and create_time like '%$time%' and belong='$centre_id' and vip=0")->count();//潜客今日新增名单
        $arr['hjrgj']=M('crm_gj')->where("create_time like '%$time%' and centre_id='$centre_id' and vip=1")->count();//会员今日跟进记录
        $arr['hxzmd']=M('wx_user')->where("yon=2 and create_time like '%$time%' and belong='$centre_id' and vip=1")->count();//会员今日新增名单
        $arr['qjjgj']=M('crm_gj')->where("centre_id='$centre_id' and lasttime like '%$time%' and vip=0")->count();
        $arr['hjjgj']=M('crm_gj')->where("centre_id='$centre_id' and lasttime like '%$time%' and vip=1")->count();
    }else{
        $arr['xzmd']=M('wx_user')->where("yon=2 and status=1 and create_time>='$start_time' and create_time<='$end_time' and belong='$centre_id' and gw_id='$user_id' and vip=0")->count();//当月新增名单
        $arr['gjjl']=M('crm_gj')->where("create_time>='$start_time' and create_time<='$end_time' and centre_id='$centre_id' and gw_id='$user_id'")->count();//当月跟进记录
        $arr['mdzs']=M('wx_user')->where("status=1 and yon=2 and belong='$centre_id' and gw_id='$user_id' and vip=0")->count();//名单总数
        $arr['hts']=M('crm_kjilu')->where("centre_id='$centre_id' and status=1 and time>='$start_time' and time<='$end_time' and guwen='$user_id'")->count();//当月合同数
        $arr['htje']=M('crm_kjilu')->where("centre_id='$centre_id' and status=1 and time>='$start_time' and time<='$end_time' and guwen='$user_id'")->sum('shishou');//当月合同金额
        $arr['qjrgj']=M('crm_gj')->where("create_time like '%$time%' and centre_id='$centre_id' and vip=0 and gw_id='$user_id'")->count();//潜客今日跟进记录
        $arr['qxzmd']=M('wx_user')->where("yon=2 and create_time like '%$time%' and belong='$centre_id' and vip=0 and gw_id='$user_id'")->count();//潜客今日新增名单
        $arr['hjrgj']=M('crm_gj')->where("create_time like '%$time%' and centre_id='$centre_id' and vip=1 and gw_id='$user_id'")->count();//会员今日跟进记录
        $arr['hxzmd']=M('wx_user')->where("yon=2 and create_time like '%$time%' and belong='$centre_id' and vip=1 and gw_id='$user_id'")->count();//会员今日新增名单
        $arr['qjjgj']=M('crm_gj')->where("centre_id='$centre_id' and lasttime like '%$time%' and gw_id='$user_id' and vip=0")->count();
        $arr['hjjgj']=M('crm_gj')->where("centre_id='$centre_id' and lasttime like '%$time%' and gw_id='$user_id' and vip=1")->count();
    }
        if(empty($arr['xzmd'])){
            $arr['xzmd']=0;
        }
        if(empty($arr['gjjl'])){
            $arr['gjjl']=0;
        }
        if(empty($arr['mdzs'])){
            $arr['xzmd']=0;
        }
        if(empty($arr['xzmd'])){
            $arr['mdzs']=0;
        }
        if(empty($arr['htje'])){
            $arr['htje']=0;
        }
        if(empty($arr['hts'])){
            $arr['hts']=0;
        }
        if(empty($arr['qjrgj'])){
            $arr['qjrgj']=0;
        }
        if(empty($arr['qxzmd'])){
            $arr['qxzmd']=0;
        }
        if(empty($arr['hjrgj'])){
            $arr['hjrgj']=0;
        }
        if(empty($arr['hxzmd'])){
            $arr['hxzmd']=0;
        }
        if(empty($arr['qjjgj'])){
            $arr['qjjgj']=0;
        }
        if(empty($arr['hjjgj'])){
            $arr['hjjgj']=0;
        }
        json("10001",$arr);
    }
    //潜客折线图
    public function qkzx(){
        header("access-control-allow-origin:*");
        $centre_id=session('centre_id');
        $yue=I('post.yue');
        $user_id=session('user_id');
        $start_time=$yue.'-01';
        $end_time=$yue.'-31';
        $gw=M('xueyuan_baoming')->where("user_id='$user_id'")->getField("gangwei");
      if($gw=='中心总监'){
        $arr['zs']=M('wx_user')->where("status=1 and vip=0 and belong='$centre_id' and gw_id=0")->count();//总数
        $arr['yx']=M('wx_user')->where("belong='$centre_id' and vip=0 and (gj_type='新客户' or gj_type='新分配')")->count();//有效
        $arr['ygj']=M('wx_user')->where("belong='$centre_id' and vip=0 and gj_type='已跟进'")->count();//有效
        $arr['ydd']=M('wx_user')->where("belong='$centre_id' and vip=0 and gj_type='已到访'")->count();//已到店
        $bao_id=M('crm_gj')->where("centre_id='$centre_id' and vip=0")->field('bao_id')->select();//最近跟进时间
      }else{
        $arr['zs']=M('wx_user')->where("status=1 and vip=0 and belong='$centre_id' and gw_id='$user_id'")->count();//总数
        $arr['yx']=M('wx_user')->where("belong='$centre_id' and vip=0 and (gj_type='新客户' or gj_type='新分配') and gw_id='$user_id'")->count();//有效
        $arr['ygj']=M('wx_user')->where("belong='$centre_id' and vip=0 and gj_type='已跟进' and gw_id='$user_id'")->count();//有效
        $arr['ydd']=M('wx_user')->where("belong='$centre_id' and vip=0 and gj_type='已到访' and gw_id='$user_id'")->count();//已到店
        $bao_id=M('crm_gj')->where("centre_id='$centre_id' and gw_id='$user_id' and vip=0")->field('bao_id')->select();//最近跟进时间
      }
        $ke=0;
        foreach ($bao_id as $key => $value) {
            $bao[$ke]=$value['bao_id'];
            $ke++;
        }
        $ae=array_flip(array_flip($bao));
        foreach ($ae as $k => $val) {
           $aa[]=M('wx_user')->where("user_id='$val' and vip=1")->getField('vip');
        }
        $arr['yqy']=count($aa);//已签约
        if(empty($arr['zs'])){
            $arr['zs']=0;
        }
        if(empty($arr['yx'])){
            $arr['yx']=0;
        }
        if(empty($arr['ygj'])){
            $arr['ygj']=0;
        }
        if(empty($arr['ydd'])){
            $arr['ydd']=0;
        }
        if(empty($arr['yqy'])){
            $arr['yqy']=0;
        }
        json("10001",$arr);

    }
    //会员折线图
    public function hyzx(){
        header("access-control-allow-origin:*");
        $centre_id=session('centre_id');
        $yue=I('post.yue');
        $user_id=session('user_id');
        $start_time=$yue.'-01';
        $end_time=$yue.'-31';
        $gw=M('xueyuan_baoming')->where("user_id='$user_id'")->getField("gangwei");
      if($gw=='中心总监'){
        $arr['zs']=M('wx_user')->where("status=1 and vip=1 and belong='$centre_id' and gw_id=0")->count();//总数
        $arr['yx']=M('wx_user')->where("belong='$centre_id' and vip=1 and (gj_type='新客户' or gj_type='新分配')")->count();
        $arr['ygj']=M('wx_user')->where("belong='$centre_id' and vip=1 and gj_type='已跟进'")->count();//有效
        $arr['ydd']=M('wx_user')->where("belong='$centre_id' and vip=1 and gj_type='已到访'")->count();//已到店
        $bao_id=M('crm_gj')->where("centre_id='$centre_id' and vip=1")->field('bao_id')->select();//最近跟进时间
    }else{
        $arr['zs']=M('wx_user')->where("status=1 and vip=1 and belong='$centre_id' and gw_id='$user_id'")->count();//总数
        $arr['yx']=M('wx_user')->where("belong='$centre_id' and vip=1 and (gj_type='新客户' or gj_type='新分配') and gw_id='$user_id'")->count();//有效
        $arr['ygj']=M('wx_user')->where("belong='$centre_id' and vip=1 and gj_type='已跟进' and gw_id='$user_id'")->count();//有效
        $arr['ydd']=M('wx_user')->where("belong='$centre_id' and vip=1 and gj_type='已到访' and gw_id='$user_id'")->count();//已到店
        $bao_id=M('crm_gj')->where("centre_id='$centre_id' and gw_id='$user_id' and vip=1")->field('bao_id')->select();//最近跟进时间
    }
        
        $ke=0;
        foreach ($bao_id as $key => $value) {
            $bao[$ke]=$value['bao_id'];
            $ke++;
        }
        $ae=array_flip(array_flip($bao));
        foreach ($ae as $k => $val) {
           $aa[]=M('wx_user')->where("user_id='$val' and vip=1")->getField('vip');
        }
        $arr['yqy']=count($aa);//已签约
        if(empty($arr['zs'])){
            $arr['zs']=0;
        }
        if(empty($arr['yx'])){
            $arr['yx']=0;
        }
        if(empty($arr['ygj'])){
            $arr['ygj']=0;
        }
        if(empty($arr['ydd'])){
            $arr['ydd']=0;
        }
        if(empty($arr['yqy'])){
            $arr['yqy']=0;
        }
        json("10001",$arr);

    }




    //名单总数
     public function mdzs()
    {
//        根据回传条件判断拼接查询条件
        header("access-control-allow-origin:*");
        $condition = I('post.');
        $centerid = session('centre_id');
        $yue=I('post.nianyue');
        if(empty($yue)){
          $yue=date("Y-m");
        }
        $user_id=session('user_id');
        $gw=M('xueyuan_baoming')->where("user_id='$user_id'")->getField("gangwei");
        $start_time=$yue.'-01';
        $end_time=$yue.'-31';
//        $centerid = session('centre_id');
        if($gw=='中心总监'){
            $where = "a.belong={$centerid} and a.yon=2 and a.status=1 and vip=0";
        }else{
            $where = "a.belong={$centerid} and a.status=1 and a.yon=2 and a.gw_id='$user_id' and a.vip=0";
        }

        if ($condition['name']){
            $where .= "  and (a.baobao_name like '%{$condition['name']}%' or a.baobao_name2 like '%{$condition['name']}%') ";
        }

        if ($condition['pname']){
            $where .= " and (a.name1 like '%{$condition['pname']}%' or a.name2 like '%{$condition['pname']}%' or a.name3 like '%{$condition['pname']}%' or a.name4 like '%{$condition['pname']}%' or a.name5 like '%{$condition['pname']}%' or a.name6 like '%{$condition['pname']}%') ";
        }

        if ($condition['pphone']){
            $where .= " and (a.phone1 like '%{$condition['pphone']}%' or a.phone2 like '%{$condition['pphone']}%' or a.phone3 like '%{$condition['pphone']}%' or a.phone4 like '%{$condition['pphone']}%' or a.phone5 like '%{$condition['pphone']}%' or a.phone6 like '%{$condition['pphone']}%') ";
        }

        if ($condition['type']){
            $where .= " and a.gj_type='{$condition['type']}'" ;
        }

        if ($condition['salesperson']){
            $where .= " and a.gw_id={$condition['salesperson']} ";
        }

//        链表联查
        if (!empty($condition['page'])){
            $page = $condition['page'];
        }else{
            $page =1;
        }

        $count = M('wx_user as a')
            ->join("left join xueyuan_baoming as b on a.gw_id=b.user_id")
            ->field("a.baobao_name,a.name1,a.name2,a.name3,a.name4,a.name5,a.name6,a.phone1,a.phone2,a.phone3,a.phone4,a.phone5,a.phone6,a.gj_type,a.gw_id,a.user_id,b.username")
            ->where($where)
            ->count();
        $pageone=10;//每页数据
        $pagetotal=ceil($count/$pageone);
        $pyl=($page-1)*$pageone;//偏移量
        $results = M('wx_user as a')
            ->join("left join xueyuan_baoming as b on a.gw_id=b.user_id")
            ->limit($pyl, $pageone)
            ->where($where)
            ->field("a.baobao_name,a.name1,a.name2,a.name3,a.name4,a.name5,a.name6,a.phone1,a.phone2,a.phone3,a.phone4,a.phone5,a.phone6,a.gj_type,a.gw_id,a.user_id,b.username,a.baobao_sex,a.baobao_birthday,a.laiyuan,a.beizhu")
            ->select();
       foreach ($results as $key => $value) {
            $results[$key]['page'] = $page;
            $results[$key]['pagetotal'] = $pagetotal;
            $results[$key]['num'] = $count;
//            关系判断
            if (!empty($value['name1'])) {
                $results[$key]['p_name'] = $value['name1'];
                $results[$key]['guanxi'] = '爸爸';
            } else if (!empty($value['name2'])) {
                $results[$key]['p_name'] = $value['name2'];
                $results[$key]['guanxi'] = '妈妈';
            } else if (!empty($value['name3'])) {
                 $results[$key]['p_name'] = $value['name3'];
                 $results[$key]['guanxi'] = '爷爷';
            } else if (!empty($value['name4'])) {
                 $results[$key]['p_name'] = $value['name4'];
                 $results[$key]['guanxi'] = '奶奶';
            } else if (!empty($value['name5'])) {
                 $results[$key]['p_name'] = $value['name5'];
                 $results[$key]['guanxi'] = '姥爷';
            } else if (!empty($value['name6'])) {
                 $results[$key]['p_name'] = $value['name6'];
                 $results[$key]['guanxi'] = '姥姥';
            } else {
                 $results[$key]['p_name'] = "";
            }
//        手机
            if (!empty($value['phone1'])) {
                 $results[$key]['p_phone'] = $value['phone1'];
            } else if (!empty($value['phone2'])) {
                 $results[$key]['p_phone'] = $value['phone2'];
            } else if (!empty($value['phone3'])) {
                 $results[$key]['p_phone'] = $value['phone3'];
            } else if (!empty($value['phone4'])) {
                 $results[$key]['p_phone'] = $value['phone4'];
            } else if (!empty($value['phone5'])) {
                 $results[$key]['p_phone'] = $value['phone5'];
            } else if (!empty($value['phone6'])) {
                 $results[$key]['p_phone'] = $value['phone6'];
            } else {
                 $results[$key]['p_phone'] = "";
            }
            $last = M('crm_gj')->where("bao_id={$value['user_id']}")->order("create_time desc")->find();
            $results[$key]['last'] = $last['create_time'];
//
        }
//        
//        $a = M()->getLastsql();
//        var_dump($a);die;

//        if ($da == false){
//            json('10002',"查询失败");
//        }
        if ($results == null){
            json('10003',"没有检索到数据");
        }
        json('10001',$results);

    }


    //合同数
    public function hts(){
        //        根据回传条件判断拼接查询条件
        header("access-control-allow-origin:*");
        $condition = I('post.');
        $centerid = session('centre_id');
        $yue=I('post.nianyue');
        if(empty($yue)){
          $yue=date("Y-m");
        }
        $user_id=session('user_id');
        $gw=M('xueyuan_baoming')->where("user_id='$user_id'")->getField("gangwei");
        $start_time=$yue.'-01';
        $end_time=$yue.'-31';
//        $centerid = session('centre_id');
        if($gw=='中心总监'){
            $where = "b.centre_id={$centerid} and b.status=1 and b.time>='$start_time' and b.time<='$end_time'";
        }else{
            $where = "b.centre_id={$centerid} and b.status=1 and b.time>='$start_time' and b.time<='$end_time' and b.guwen='$user_id'";
        }
        if ($condition['hetong']){
            $where .= " and b.hetong={$condition['hetong']} ";
        }
        if ($condition['name']){
            $where .= "  and (a.baobao_name like '%{$condition['name']}%' or a.baobao_name2 like '%{$condition['name']}%')";
        }

        if ($condition['pname']){
            $where .= " and (a.name1 like '%{$condition['pname']}%' or a.name2 like '%{$condition['pname']}%' or a.name3 like '%{$condition['pname']}%' or a.name4 like '%{$condition['pname']}%' or a.name5 like '%{$condition['pname']}%' or a.name6 like '%{$condition['pname']}%') ";
        }

        if ($condition['pphone']){
            $where .= " and (a.phone1 like '%{$condition['pphone']}%' or a.phone2 like '%{$condition['pphone']}%' or a.phone3 like '%{$condition['pphone']}%' or a.phone4 like '%{$condition['pphone']}%' or a.phone5 like '%{$condition['pphone']}%' or a.phone6 like '%{$condition['pphone']}%') ";
        }

        if ($condition['type']){
            $where .= " and a.gj_type='{$condition['type']}'" ;
        }

        if ($condition['salesperson']){
            $where .= " and a.gw_id={$condition['salesperson']} ";
        }

//        链表联查
        if (!empty($condition['page'])){
            $page = $condition['page'];
        }else{
            $page =1;
        }

        $count = M('wx_user as a')
            ->join("crm_kjilu as b on a.jl_id=b.jl_id")
            ->join("left join xueyuan_baoming as c on a.gw_id=c.user_id")
            ->field('a.user_id,a.baobao_name,b.y_keshi,a.name1,a.name2,a.name3,a.name4,a.name5,a.name6,a.phone1,a.phone2,a.phone3,a.phone4,a.phone5,a.phone6,b.e_time,a.baobao_birthday,b.bz')
            ->where($where)
            ->count();
        $pageone=10;//每页数据
        $pagetotal=ceil($count/$pageone);
        $pyl=($page-1)*$pageone;//偏移量
        $da = M('wx_user as a')
            ->join("crm_kjilu as b on a.jl_id=b.jl_id")
            ->join("left join xueyuan_baoming as c on a.gw_id=c.user_id")
            ->field('a.user_id,a.baobao_name,b.y_keshi,a.name1,a.name2,a.name3,a.name4,a.name5,a.name6,a.phone1,a.phone2,a.phone3,a.phone4,a.phone5,a.phone6,b.e_time,a.baobao_birthday,b.bz')
            ->limit($pyl,$pageone)
            ->where($where)
            ->select();
       
       // $a = M()->getLastsql();
       // var_dump($a);die;

       if ($da == false){
           json('10002',"查询失败");
       }
        if ($da == null){
            json('10003',"没有检索到数据");
        }
        foreach ($da as $key=>$value){
            if (!empty($value['name1'])) {
                $da[$key]['p_name'] = $value['name1'];
            } else if (!empty($value['name2'])) {
                $da[$key]['p_name'] = $value['name2'];
            } else if (!empty($value['name3'])) {
                 $da[$key]['p_name'] = $value['name3'];
            } else if (!empty($value['name4'])) {
                 $da[$key]['p_name'] = $value['name4'];
            } else if (!empty($value['name5'])) {
                 $da[$key]['p_name'] = $value['name5'];
            } else if (!empty($value['name6'])) {
                 $da[$key]['p_name'] = $value['name6'];
            } else {
                 $da[$key]['p_name'] = "";
            }
//        手机
            if (!empty($value['phone1'])) {
                 $da[$key]['p_phone'] = $value['phone1'];
            } else if (!empty($value['phone2'])) {
                 $da[$key]['p_phone'] = $value['phone2'];
            } else if (!empty($value['phone3'])) {
                 $da[$key]['p_phone'] = $value['phone3'];
            } else if (!empty($value['phone4'])) {
                 $da[$key]['p_phone'] = $value['phone4'];
            } else if (!empty($value['phone5'])) {
                 $da[$key]['p_phone'] = $value['phone5'];
            } else if (!empty($value['phone6'])) {
                 $da[$key]['p_phone'] = $value['phone6'];
            } else {
                 $da[$key]['p_phone'] = "";
            }
            $last = M('crm_gj')->where("bao_id={$value['user_id']}")->order("create_time desc")->find();
            $da[$key]['last'] = $last['create_time'];
            $da[$key]['page']=$page;
            $da[$key]['pagetotal']=$pagetotal;
            $da[$key]['num']=$count;
        }
        json('10001',$da);
    }

    //潜客今日新增名单
     public function jrxz()
    {
//        根据回传条件判断拼接查询条件
        header("access-control-allow-origin:*");
        $condition = I('post.');
        $centerid = session('centre_id');
        $user_id=session('user_id');
        $gw=M('xueyuan_baoming')->where("user_id='$user_id'")->getField("gangwei");
        $time=I('post.nianyue');
        if(empty($time)){
            $time=date('Y-m-d');
        } 
//        $centerid = session('centre_id');
        if($gw=='中心总监'){
            $where = "a.belong={$centerid} and a.status=1 and a.yon=2 and a.status=1 and a.create_time like '%$time%' and a.vip=0";
        }else{
            $where = "a.belong={$centerid} and a.status=1 and a.yon=2 and a.status=1 and a.create_time like '%$time%' and a.gw_id='$user_id' and a.vip=0";
        }
        if ($condition['hetong']){
            $where .= " and b.hetong={$condition['hetong']} ";
        }

        if ($condition['name']){
            $where .= "  and (a.baobao_name like '%{$condition['name']}%' or a.baobao_name2 like '%{$condition['name']}%') ";
        }

        if ($condition['pname']){
            $where .= " and (a.name1 like '%{$condition['pname']}%' or a.name2 like '%{$condition['pname']}%' or a.name3 like '%{$condition['pname']}%' or a.name4 like '%{$condition['pname']}%' or a.name5 like '%{$condition['pname']}%' or a.name6 like '%{$condition['pname']}%') ";
        }

        if ($condition['pphone']){
            $where .= " and (a.phone1 like '%{$condition['pphone']}%' or a.phone2 like '%{$condition['pphone']}%' or a.phone3 like '%{$condition['pphone']}%' or a.phone4 like '%{$condition['pphone']}%' or a.phone5 like '%{$condition['pphone']}%' or a.phone6 like '%{$condition['pphone']}%') ";
        }

        if ($condition['type']){
            $where .= " and a.gj_type='{$condition['type']}'" ;
        }

        if ($condition['salesperson']){
            $where .= " and a.gw_id={$condition['salesperson']} ";
        }

//        链表联查
        if (!empty($condition['page'])){
            $page = $condition['page'];
        }else{
            $page =1;
        }

        $count = M('wx_user as a')
            ->join("left join xueyuan_baoming as b on a.gw_id=b.user_id")
            ->where($where)
            ->field("a.baobao_name,a.name1,a.name2,a.name3,a.name4,a.name5,a.name6,a.phone1,a.phone2,a.phone3,a.phone4,a.phone5,a.phone6,a.gj_type,a.gw_id,a.user_id,b.username")
            ->count();
        $pageone=10;//每页数据
        $pagetotal=ceil($count/$pageone);
        $pyl=($page-1)*$pageone;//偏移量
        $results = M('wx_user as a')
            ->join("left join xueyuan_baoming as b on a.gw_id=b.user_id")
            ->limit($pyl, $pageone)
            ->where($where)
            ->field("a.baobao_name,a.name1,a.name2,a.name3,a.name4,a.name5,a.name6,a.phone1,a.phone2,a.phone3,a.phone4,a.phone5,a.phone6,a.gj_type,a.gw_id,a.user_id,b.username,a.baobao_sex,a.baobao_birthday,a.laiyuan,a.beizhu")
            ->select();
       foreach ($results as $key => $value) {
            $results[$key]['page'] = $page;
            $results[$key]['pagetotal'] = $pagetotal;
            $results[$key]['num'] = $count;
//            关系判断
            if (!empty($value['name1'])) {
                $results[$key]['p_name'] = $value['name1'];
                $results[$key]['guanxi'] = '爸爸';
            } else if (!empty($value['name2'])) {
                $results[$key]['p_name'] = $value['name2'];
                $results[$key]['guanxi'] = '妈妈';
            } else if (!empty($value['name3'])) {
                 $results[$key]['p_name'] = $value['name3'];
                 $results[$key]['guanxi'] = '爷爷';
            } else if (!empty($value['name4'])) {
                 $results[$key]['p_name'] = $value['name4'];
                 $results[$key]['guanxi'] = '奶奶';
            } else if (!empty($value['name5'])) {
                 $results[$key]['p_name'] = $value['name5'];
                 $results[$key]['guanxi'] = '姥爷';
            } else if (!empty($value['name6'])) {
                 $results[$key]['p_name'] = $value['name6'];
                 $results[$key]['guanxi'] = '姥姥';
            } else {
                 $results[$key]['p_name'] = "";
            }
//        手机
            if (!empty($value['phone1'])) {
                 $results[$key]['p_phone'] = $value['phone1'];
            } else if (!empty($value['phone2'])) {
                 $results[$key]['p_phone'] = $value['phone2'];
            } else if (!empty($value['phone3'])) {
                 $results[$key]['p_phone'] = $value['phone3'];
            } else if (!empty($value['phone4'])) {
                 $results[$key]['p_phone'] = $value['phone4'];
            } else if (!empty($value['phone5'])) {
                 $results[$key]['p_phone'] = $value['phone5'];
            } else if (!empty($value['phone6'])) {
                 $results[$key]['p_phone'] = $value['phone6'];
            } else {
                 $results[$key]['p_phone'] = "";
            }
            $last = M('crm_gj')->where("bao_id={$value['user_id']}")->order("create_time desc")->find();
            $results[$key]['last'] = $last['create_time'];
//
        }
       
       // $a = M()->getLastsql();
       // var_dump($a);die;

//        if ($da == false){
//            json('10002',"查询失败");
//        }
        if ($results == null){
            json('10003',"没有检索到数据");
        }
        json('10001',$results);

    }
     //会员新增名单
     public function hjrxz()
    {
//        根据回传条件判断拼接查询条件
        header("access-control-allow-origin:*");
        $condition = I('post.');
        $centerid = session('centre_id');
        $user_id=session('user_id');
        $gw=M('xueyuan_baoming')->where("user_id='$user_id'")->getField("gangwei");
        $time=I('post.nianyue');
        if(empty($time)){
            $time=date('Y-m-d');
        }
//        $centerid = session('centre_id');
        if($gw=='中心总监'){
            $where = "a.belong={$centerid} and a.status=1 and a.yon=2 and a.status=1 and a.create_time like '%$time%' and a.vip=1";
        }else{
            $where = "a.belong={$centerid} and a.status=1 and a.yon=2 and a.status=1 and a.create_time like '%$time%' and a.gw_id='$user_id'  and a.vip=1";
        }
        if ($condition['hetong']){
            $where .= " and b.hetong={$condition['hetong']} ";
        }

        if ($condition['name']){
            $where .= "  and (a.baobao_name like '%{$condition['name']}%' or a.baobao_name2 like '%{$condition['name']}%') ";
        }

        if ($condition['pname']){
            $where .= " and (a.name1 like '%{$condition['pname']}%' or a.name2 like '%{$condition['pname']}%' or a.name3 like '%{$condition['pname']}%' or a.name4 like '%{$condition['pname']}%' or a.name5 like '%{$condition['pname']}%' or a.name6 like '%{$condition['pname']}%') ";
        }

        if ($condition['pphone']){
            $where .= " and (a.phone1 like '%{$condition['pphone']}%' or a.phone2 like '%{$condition['pphone']}%' or a.phone3 like '%{$condition['pphone']}%' or a.phone4 like '%{$condition['pphone']}%' or a.phone5 like '%{$condition['pphone']}%' or a.phone6 like '%{$condition['pphone']}%') ";
        }

        if ($condition['type']){
            $where .= " and a.gj_type='{$condition['type']}'" ;
        }

        if ($condition['salesperson']){
            $where .= " and a.gw_id={$condition['salesperson']} ";
        }

//        链表联查
        if (!empty($condition['page'])){
            $page = $condition['page'];
        }else{
            $page =1;
        }

        $count = M('wx_user as a')
            ->join("left join crm_kjilu as b on a.jl_id=b.jl_id")
            ->join("left join xueyuan_baoming as c on a.gw_id=c.user_id")
            ->join("left join xueyuan_baoming as d on b.create_name=d.user_id")
            ->field("b.hetong,a.gj_type,a.baobao_name,a.baobao_name2,a.baobao_birthday,a.baobao_name2,b.receivable,b.receipt_type,b.shishou,b.create_time,b.guwen,d.username as create_name,b.bz,c.user_id,c.username")
            ->where($where)
            ->count();
        $pageone=10;//每页数据
        $pagetotal=ceil($count/$pageone);
        $pyl=($page-1)*$pageone;//偏移量
        $da = M('wx_user as a')
            ->join("left join crm_kjilu as b on a.jl_id=b.jl_id")
            ->join("left join xueyuan_baoming as c on a.gw_id=c.user_id")
            ->join("left join xueyuan_baoming as d on b.create_name=d.user_id")
            ->field('a.user_id,a.baobao_name,b.y_keshi,a.name1,a.name2,a.name3,a.name4,a.name5,a.name6,a.phone1,a.phone2,a.phone3,a.phone4,a.phone5,a.phone6,b.e_time,a.baobao_birthday,b.bz')
            ->limit($pyl,$pageone)
            ->where($where)
            ->select();
       
       // $a = M()->getLastsql();
       // var_dump($a);die;

       if ($da == false){
           json('10002',"查询失败");
       }
        if ($da == null){
            json('10003',"没有检索到数据");
        }
        foreach ($da as $key=>$value){
            if (!empty($value['name1'])) {
                $da[$key]['p_name'] = $value['name1'];
            } else if (!empty($value['name2'])) {
                $da[$key]['p_name'] = $value['name2'];
            } else if (!empty($value['name3'])) {
                 $da[$key]['p_name'] = $value['name3'];
            } else if (!empty($value['name4'])) {
                 $da[$key]['p_name'] = $value['name4'];
            } else if (!empty($value['name5'])) {
                 $da[$key]['p_name'] = $value['name5'];
            } else if (!empty($value['name6'])) {
                 $da[$key]['p_name'] = $value['name6'];
            } else {
                 $da[$key]['p_name'] = "";
            }
//        手机
            if (!empty($value['phone1'])) {
                 $da[$key]['p_phone'] = $value['phone1'];
            } else if (!empty($value['phone2'])) {
                 $da[$key]['p_phone'] = $value['phone2'];
            } else if (!empty($value['phone3'])) {
                 $da[$key]['p_phone'] = $value['phone3'];
            } else if (!empty($value['phone4'])) {
                 $da[$key]['p_phone'] = $value['phone4'];
            } else if (!empty($value['phone5'])) {
                 $da[$key]['p_phone'] = $value['phone5'];
            } else if (!empty($value['phone6'])) {
                 $da[$key]['p_phone'] = $value['phone6'];
            } else {
                 $da[$key]['p_phone'] = "";
            }
            $last = M('crm_gj')->where("bao_id={$value['user_id']}")->order("create_time desc")->find();
            $da[$key]['last'] = $last['create_time'];
            $da[$key]['page']=$page;
            $da[$key]['pagetotal']=$pagetotal;
            $da[$key]['num']=$count;
        }
        json('10001',$da);

    }
    //潜客今日紧急跟进
    public function qjrjj(){
        header("access-control-allow-origin:*");
        $condition = I('post.');
        $centre_id = session('centre_id');
        $user_id=session('user_id');
        $time=I('post.nianyue');
        if(empty($time)){
            $time=date("Y-m-d");
        }
        $gw=M('xueyuan_baoming')->where("user_id='$user_id'")->getField("gangwei");
        if($gw=='中心总监'){
        $bao_id=M('crm_gj')->where("centre_id='$centre_id' and lasttime like '%$time%' and vip=0")->field('bao_id')->select();
      }else{
        $bao_id=M('crm_gj')->where("centre_id='$centre_id' and lasttime like '%$time%' and gw_id='$user_id' and vip=0")->field('bao_id')->select();
      }
        $ke=0;
        foreach ($bao_id as $key => $value) {
            $bao[$ke]=$value['bao_id'];
            $ke++;
        }
        $ae=array_flip(array_flip($bao));
        $aaa=implode(",",$ae);
        $time=date('Y-m-d');
//        $centerid = session('centre_id');
        $where = "a.belong={$centre_id} and a.status=1 and a.yon=2 and a.user_id in({$aaa})";
        if ($condition['hetong']){
            $where .= " and b.hetong={$condition['hetong']} ";
        }

        if ($condition['name']){
            $where .= "  and (a.baobao_name like '%{$condition['name']}%' or a.baobao_name2 like '%{$condition['name']}%') ";
        }

        if ($condition['pname']){
            $where .= " and (a.name1 like '%{$condition['pname']}%' or a.name2 like '%{$condition['pname']}%' or a.name3 like '%{$condition['pname']}%' or a.name4 like '%{$condition['pname']}%' or a.name5 like '%{$condition['pname']}%' or a.name6 like '%{$condition['pname']}%') ";
        }

        if ($condition['pphone']){
            $where .= " and (a.phone1 like '%{$condition['pphone']}%' or a.phone2 like '%{$condition['pphone']}%' or a.phone3 like '%{$condition['pphone']}%' or a.phone4 like '%{$condition['pphone']}%' or a.phone5 like '%{$condition['pphone']}%' or a.phone6 like '%{$condition['pphone']}%') ";
        }

        if ($condition['type']){
            $where .= " and a.gj_type='{$condition['type']}'" ;
        }

        if ($condition['salesperson']){
            $where .= " and a.gw_id={$condition['salesperson']} ";
        }

//        链表联查
        if (!empty($condition['page'])){
            $page = $condition['page'];
        }else{
            $page =1;
        }

        $count = M('wx_user as a')
            ->join("left join xueyuan_baoming as b on a.gw_id=b.user_id")
            ->where($where)
            ->field("a.baobao_name,a.name1,a.name2,a.name3,a.name4,a.name5,a.name6,a.phone1,a.phone2,a.phone3,a.phone4,a.phone5,a.phone6,a.gj_type,a.gw_id,a.user_id,b.username,a.baobao_sex,a.baobao_birthday,a.laiyuan,a.beizhu")
            ->count();
        $pageone=10;//每页数据
        $pagetotal=ceil($count/$pageone);
        $pyl=($page-1)*$pageone;//偏移量
        $results = M('wx_user as a')
            ->join("left join xueyuan_baoming as b on a.gw_id=b.user_id")
            ->limit($pyl,$pageone)
            ->where($where)
            ->field("a.baobao_name,a.name1,a.name2,a.name3,a.name4,a.name5,a.name6,a.phone1,a.phone2,a.phone3,a.phone4,a.phone5,a.phone6,a.gj_type,a.gw_id,a.user_id,b.username,a.baobao_sex,a.baobao_birthday,a.laiyuan,a.beizhu")
            ->select();
foreach ($results as $key => $value) {
            $results[$key]['page'] = $page;
            $results[$key]['pagetotal'] = $pagetotal;
            $results[$key]['num'] = $count;
//            关系判断
            if (!empty($value['name1'])) {
                $results[$key]['p_name'] = $value['name1'];
                $results[$key]['guanxi'] = '爸爸';
            } else if (!empty($value['name2'])) {
                $results[$key]['p_name'] = $value['name2'];
                $results[$key]['guanxi'] = '妈妈';
            } else if (!empty($value['name3'])) {
                 $results[$key]['p_name'] = $value['name3'];
                 $results[$key]['guanxi'] = '爷爷';
            } else if (!empty($value['name4'])) {
                 $results[$key]['p_name'] = $value['name4'];
                 $results[$key]['guanxi'] = '奶奶';
            } else if (!empty($value['name5'])) {
                 $results[$key]['p_name'] = $value['name5'];
                 $results[$key]['guanxi'] = '姥爷';
            } else if (!empty($value['name6'])) {
                 $results[$key]['p_name'] = $value['name6'];
                 $results[$key]['guanxi'] = '姥姥';
            } else {
                 $results[$key]['p_name'] = "";
            }
//        手机
            if (!empty($value['phone1'])) {
                 $results[$key]['p_phone'] = $value['phone1'];
            } else if (!empty($value['phone2'])) {
                 $results[$key]['p_phone'] = $value['phone2'];
            } else if (!empty($value['phone3'])) {
                 $results[$key]['p_phone'] = $value['phone3'];
            } else if (!empty($value['phone4'])) {
                 $results[$key]['p_phone'] = $value['phone4'];
            } else if (!empty($value['phone5'])) {
                 $results[$key]['p_phone'] = $value['phone5'];
            } else if (!empty($value['phone6'])) {
                 $results[$key]['p_phone'] = $value['phone6'];
            } else {
                 $results[$key]['p_phone'] = "";
            }
            $last = M('crm_gj')->where("bao_id={$value['user_id']}")->order("create_time desc")->find();
            $results[$key]['last'] = $last['create_time'];
//
        }
       
       // $a = M()->getLastsql();
       // var_dump($a);die;

       if ($results == false){
           json('10002',"查询失败");
       }
        if ($results == null){
            json('10003',"没有检索到数据");
        }
        foreach ($results as $key=>$value){
            $results[$key]['page']=$page;
            $results[$key]['pagetotal']=$pagetotal;
            $results[$key]['num']=$count;
        }
        json('10001',$results);

    }
    //会员今日紧急跟进
    public function hjrjj(){
        header("access-control-allow-origin:*");
        $condition = I('post.');
        $centre_id = session('centre_id');
        $user_id=session('user_id');
        $time=I('post.nianyue');
        if(empty($time)){
            $time=date("Y-m-d");
        }
        $gw=M('xueyuan_baoming')->where("user_id='$user_id'")->getField("gangwei");
        if($gw=='中心总监'){
        $bao_id=M('crm_gj')->where("centre_id='$centre_id' and lasttime like '%$time%' and vip=1")->field('bao_id')->select();
      }else{
        $bao_id=M('crm_gj')->where("centre_id='$centre_id' and lasttime like '%$time%' and gw_id='$user_id' and vip=1")->field('bao_id')->select();
      }
        $ke=0;
        foreach ($bao_id as $key => $value) {
            $bao[$ke]=$value['bao_id'];
            $ke++;
        }
        $ae=array_flip(array_flip($bao));
        $aaa=implode(",",$ae);
//        $centerid = session('centre_id');
        $where = "a.belong={$centre_id} and a.status=1 and a.yon=2 and a.user_id in({$aaa})";
        if ($condition['hetong']){
            $where .= " and b.hetong={$condition['hetong']} ";
        }

        if ($condition['name']){
            $where .= "  and (a.baobao_name like '%{$condition['name']}%' or a.baobao_name2 like '%{$condition['name']}%') ";
        }

        if ($condition['pname']){
            $where .= " and (a.name1 like '%{$condition['pname']}%' or a.name2 like '%{$condition['pname']}%' or a.name3 like '%{$condition['pname']}%' or a.name4 like '%{$condition['pname']}%' or a.name5 like '%{$condition['pname']}%' or a.name6 like '%{$condition['pname']}%') ";
        }

        if ($condition['pphone']){
            $where .= " and (a.phone1 like '%{$condition['pphone']}%' or a.phone2 like '%{$condition['pphone']}%' or a.phone3 like '%{$condition['pphone']}%' or a.phone4 like '%{$condition['pphone']}%' or a.phone5 like '%{$condition['pphone']}%' or a.phone6 like '%{$condition['pphone']}%') ";
        }

        if ($condition['type']){
            $where .= " and a.gj_type='{$condition['type']}'" ;
        }

        if ($condition['salesperson']){
            $where .= " and a.gw_id={$condition['salesperson']} ";
        }

//        链表联查
        if (!empty($condition['page'])){
            $page = $condition['page'];
        }else{
            $page =1;
        }

        $count = M('wx_user as a')
            ->join("left join crm_kjilu as b on a.jl_id=b.jl_id")
            ->join("left join xueyuan_baoming as c on a.gw_id=c.user_id")
            ->join("left join xueyuan_baoming as d on b.create_name=d.user_id")
            ->field('a.user_id,a.baobao_name,b.y_keshi,a.name1,a.name2,a.name3,a.name4,a.name5,a.name6,a.phone1,a.phone2,a.phone3,a.phone4,a.phone5,a.phone6,b.e_time,a.baobao_birthday,b.bz')
            ->where($where)
            ->count();
        $pageone=10;//每页数据
        $pagetotal=ceil($count/$pageone);
        $pyl=($page-1)*$pageone;//偏移量
        $da = M('wx_user as a')
            ->join("left join crm_kjilu as b on a.jl_id=b.jl_id")
            ->join("left join xueyuan_baoming as c on a.gw_id=c.user_id")
            ->join("left join xueyuan_baoming as d on b.create_name=d.user_id")
            ->field('a.user_id,a.baobao_name,b.y_keshi,a.name1,a.name2,a.name3,a.name4,a.name5,a.name6,a.phone1,a.phone2,a.phone3,a.phone4,a.phone5,a.phone6,b.e_time,a.baobao_birthday,b.bz')
            ->limit($pyl,$pageone)
            ->where($where)
            ->select();
       
       // $a = M()->getLastsql();
       // var_dump($a);die;

       if ($da == false){
           json('10002',"查询失败");
       }
        if ($da == null){
            json('10003',"没有检索到数据");
        }
        foreach ($da as $key=>$value){
            $da[$key]['page']=$page;
            $da[$key]['pagetotal']=$pagetotal;
            $da[$key]['num']=$count;
            if (!empty($value['name1'])) {
                $da[$key]['p_name'] = $value['name1'];
            } else if (!empty($value['name2'])) {
                $da[$key]['p_name'] = $value['name2'];
            } else if (!empty($value['name3'])) {
                 $da[$key]['p_name'] = $value['name3'];
            } else if (!empty($value['name4'])) {
                 $da[$key]['p_name'] = $value['name4'];
            } else if (!empty($value['name5'])) {
                 $da[$key]['p_name'] = $value['name5'];
            } else if (!empty($value['name6'])) {
                 $da[$key]['p_name'] = $value['name6'];
            } else {
                 $da[$key]['p_name'] = "";
            }
//        手机
            if (!empty($value['phone1'])) {
                 $da[$key]['p_phone'] = $value['phone1'];
            } else if (!empty($value['phone2'])) {
                 $da[$key]['p_phone'] = $value['phone2'];
            } else if (!empty($value['phone3'])) {
                 $da[$key]['p_phone'] = $value['phone3'];
            } else if (!empty($value['phone4'])) {
                 $da[$key]['p_phone'] = $value['phone4'];
            } else if (!empty($value['phone5'])) {
                 $da[$key]['p_phone'] = $value['phone5'];
            } else if (!empty($value['phone6'])) {
                 $da[$key]['p_phone'] = $value['phone6'];
            } else {
                 $da[$key]['p_phone'] = "";
            }
            $last = M('crm_gj')->where("bao_id={$value['user_id']}")->order("create_time desc")->find();
            $da[$key]['last'] = $last['create_time'];
        }
        json('10001',$da);

    }

    //中心总监分配潜客列表
    public function shu(){
        header("access-control-allow-origin:*");
    	if(isset($_POST['p'])){
         $page=$_POST['p'];
        }else{
         $page=1;
        }
    	$centre_id=session('centre_id');
        $user_id=session('user_id');
        $gw=M('xueyuan_baoming')->where("user_id='$user_id'")->getField("gangwei");
        if($gw=='中心总监'){
    	$num=M('wx_user')->where("yon=2 and belong='$centre_id' and status=1 and vip=0 and gw_id=0")->count();
        $pageone=10;//每页数据
        $pagetotal=ceil($num/$pageone);
        $pyl=($page-1)*$pageone;//偏移量
    	$arr=M('wx_user')->where("yon=2 and belong='$centre_id' and status=1 and vip=0 and gw_id=0")->field('user_id,baobao_name,baobao_sex,name1,name2,name3,name4,name5,name6,phone1,phone2,phone3,phone4,phone5,phone6,baobao_birthday,beizhu,laiyuan,gj_type')->limit($pyl,$pageone)->select();
    	foreach ($arr as $key => $value) {
    		if(!empty($value['name1'])){
    			$arr[$key]['name']=$value['name1'];
                $arr[$key]['guanxi']='爸爸';
    		}else if(!empty($value['name2'])){
    			$arr[$key]['name']=$value['name2'];
                $arr[$key]['guanxi']='妈妈';
    		}else if(!empty($value['name3'])){
    			$arr[$key]['name']=$value['name3'];
                $arr[$key]['guanxi']='爷爷';
    		}else if(!empty($value['name4'])){
    			$arr[$key]['name']=$value['name4'];
                $arr[$key]['guanxi']='奶奶';
    		}else if(!empty($value['name5'])){
    			$arr[$key]['name']=$value['name5'];
                $arr[$key]['guanxi']='姥爷';
    		}else if(!empty($value['name6'])){
    			$arr[$key]['name']=$value['name6'];
                $arr[$key]['name']='姥姥';
    		}
    		if(!empty($value['phone1'])){
    			$arr[$key]['phone']=$value['phone1'];
    		}else if(!empty($value['phone2'])){
    			$arr[$key]['phone']=$value['phone2'];
    		}else if(!empty($value['phone3'])){
    			$arr[$key]['phone']=$value['phone3'];
    		}else if(!empty($value['phone3'])){
    			$arr[$key]['phone']=$value['phone3'];
    		}else if(!empty($value['phone4'])){
    			$arr[$key]['phone']=$value['phone4'];
    		}else if(!empty($value['phone5'])){
    			$arr[$key]['phone']=$value['phone5'];
    		}else if(!empty($value['phone6'])){
    			$arr[$key]['phone']=$value['phone6'];
    		}
    		$arr[$key]['page']=$page;
            $arr[$key]['pagetotal']=$pagetotal;
            $arr[$key]['num']=$num;
            $a=M('crm_gj')->where("user_id='$value[bao_id]'")->order("create_time desc")->field('create_time,lasttime')->find();//跟进时间
    		$arr[$key]['zhgj']=$a['create_time'];
            $arr[$key]['xcgj']=$a['lasttime'];
        }
    		
    	}
    	json("10001",$arr);
    }
    //分配
    public function fenpei(){
        header("access-control-allow-origin:*");
        $user_id=I('post.user_id');
        $data['gw_id']=I('post.xiaoshou');
        $data['gj_type']='新分配';
        foreach ($user_id as $key => $value) {
            M('wx_user')->where("user_id='$value'")->save($data);
        }
        json("10001","成功");
    }
    //根据日期筛选课程
    public function xzkc(){
        header("access-control-allow-origin:*");
        $week=I('post.week');
        // if(empty($week)){
        //     json("10002",'参数错误');
        // }
        // $str = strtotime($week);
        // $week = date('w', $str);
        // if($week==0){
        //     $week=7;
        // }
        $centre_id=session('centre_id');
        $time=date("Y-m-d");
        $arr=M('crm_kecheng')
            ->join("crm_ke on crm_kecheng.kc_id=crm_ke.kc_id")
            ->where("crm_kecheng.status=1 and crm_kecheng.centre_id='$centre_id' AND crm_kecheng.start_time<='$time' AND crm_kecheng.week=$week AND crm_kecheng.end_time>='$time'")
            ->field('crm_ke.kc_name,crm_kecheng.pk_id')
            ->select();
        json("10001",$arr);
    }
    //到访切换
    public function dfqh(){
        header("access-control-allow-origin:*");
        $id=I('post.id');
        $visittype=M('crm_gj')->where("gj_id='$id'")->field('dao,bao_id')->find();
        if($visittype['dao']==2){
            $data['dao']=1;
            M('crm_gj')->where("gj_id='$id'")->save($data);
            $da['gj_type']='已到访';
            M('wx_user')->where("user_id='$visittype[bao_id]'")->save($da);
            echo 1;
        }else{
            $data['dao']=2;
            M('crm_gj')->where("gj_id='$id'")->save($data);
            $da['gj_type']='预约未到访';
            M('wx_user')->where("user_id='$visittype[bao_id]'")->save($da);
            echo 0;
        }
    }
    //预约试听
    public function yyst(){
        header("access-control-allow-origin:*");
        $data['mdname']=I('post.name');
        $data['stny']=I('post.time');
        $data['kc_id']=I('post.kc_id');
        $data['bz']=I('post.bz');
        $data['week']=I('post.week');
        $data['baobao_id']=I('post.baobao_id');
        $data['centre_id']=session('centre_id');
        if(M('crm_yyst')->add($data)){
            json("10001",1);
        }
    }
    //销售下拉列表
    public function yxlb(){
        header("access-control-allow-origin:*");
        $centre_id=session('centre_id');
        $arr=M('xueyuan_baoming')->where("centre_id='$centre_id' and status=1 and gangwei='营销'")->field("user_id,username")->select();
        json("10001",$arr);
    }
    //转给他人
    public function zgtr(){
        header("access-control-allow-origin:*");
        $user_id=I('post.user_id');//会员id
        $data['gw_id']=I('post.uid');//营销id
        if(M('wx_user')->where("user_id='$user_id'")->save($data)){
            json("10001",'成功');
        }
    }
    //退回公海
    public function tuihui(){
        header("access-control-allow-origin:*");
        $user_id=I('post.user_id');//会员id
        $data['gw_id']=0;
        if(M('wx_user')->where("user_id='$user_id'")->save($data)){
            json("10001",'成功');
        }
    }
    //潜客跟进
    public function qkgj()
    {
//        根据回传条件判断拼接查询条件
        header("access-control-allow-origin:*");
        $condition = I('post.');
        $centerid = session('centre_id');
        $time=I('post.nianyue');
        $user_id=session('user_id');
        $gw=M('xueyuan_baoming')->where("user_id='$user_id'")->getField("gangwei");
//        $centerid = session('centre_id');
        if($gw=='中心总监'){
            if(empty($time)){
                $where = "a.belong={$centerid} and a.yon=2 and a.status=1 and a.vip=0";
            }else{
                $where = "a.belong={$centerid} and a.yon=2 and a.status=1 and a.vip=0 and a.create_time like '%$time%' and a.gw_id='$user_id'";
            }
        }else{
            if(empty($time)){
            $where = "a.belong={$centerid} and a.yon=2 and a.status=1 and a.gw_id='$user_id' and a.vip=0";
        }else{
            $where = "a.belong={$centerid} and a.yon=2 and a.status=1 and a.gw_id='$user_id' and a.vip=0 and a.create_time like '%$time%'";
        }
        }
        if ($condition['name']){
            $where .= "  and (a.baobao_name like '%{$condition['name']}%' or a.baobao_name2 like '%{$condition['name']}%') ";
        }

        if ($condition['pname']){
            $where .= " and (a.name1 like '%{$condition['pname']}%' or a.name2 like '%{$condition['pname']}%' or a.name3 like '%{$condition['pname']}%' or a.name4 like '%{$condition['pname']}%' or a.name5 like '%{$condition['pname']}%' or a.name6 like '%{$condition['pname']}%') ";
        }

        if ($condition['pphone']){
            $where .= " and (a.phone1 like '%{$condition['pphone']}%' or a.phone2 like '%{$condition['pphone']}%' or a.phone3 like '%{$condition['pphone']}%' or a.phone4 like '%{$condition['pphone']}%' or a.phone5 like '%{$condition['pphone']}%' or a.phone6 like '%{$condition['pphone']}%') ";
        }

        if ($condition['type']){
            $where .= " and a.gj_type='{$condition['type']}'" ;
        }

        if ($condition['salesperson']){
            $where .= " and a.gw_id={$condition['salesperson']} ";
        }

//        链表联查
        if (!empty($condition['page'])){
            $page = $condition['page'];
        }else{
            $page =1;
        }

        $count = M('wx_user as a')
            ->join("left join xueyuan_baoming as b on a.gw_id=b.user_id")
            ->field("a.baobao_name,a.name1,a.name2,a.name3,a.name4,a.name5,a.name6,a.phone1,a.phone2,a.phone3,a.phone4,a.phone5,a.phone6,a.gj_type,a.gw_id,a.user_id,b.username,a.baobao_sex,a.laiyuan,a.beizhu")
            ->where($where)
            ->count();
        $pageone=10;//每页数据
        $pagetotal=ceil($count/$pageone);
        $pyl=($page-1)*$pageone;//偏移量
        $results = M('wx_user as a')
            ->join("left join xueyuan_baoming as b on a.gw_id=b.user_id")
            ->limit($pyl,$pageone)
            ->where($where)
            ->field("a.baobao_name,a.name1,a.name2,a.name3,a.name4,a.name5,a.name6,a.phone1,a.phone2,a.phone3,a.phone4,a.phone5,a.phone6,a.gj_type,a.gw_id,a.user_id,b.username,a.baobao_sex,a.laiyuan,a.beizhu,a.baobao_birthday")
            ->select();
       foreach ($results as $key => $value) {
            $results[$key]['page'] = $page;
            $results[$key]['pagetotal'] = $pagetotal;
            $results[$key]['num'] = $count;
//            关系判断
            if (!empty($value['name1'])) {
                $results[$key]['p_name'] = $value['name1'];
            } else if (!empty($value['name2'])) {
                $results[$key]['p_name'] = $value['name2'];
            } else if (!empty($value['name3'])) {
                 $results[$key]['p_name'] = $value['name3'];
            } else if (!empty($value['name4'])) {
                 $results[$key]['p_name'] = $value['name4'];
            } else if (!empty($value['name5'])) {
                 $results[$key]['p_name'] = $value['name5'];
            } else if (!empty($value['name6'])) {
                 $results[$key]['p_name'] = $value['name6'];
            } else {
                 $results[$key]['p_name'] = "";
            }
//        手机
            if (!empty($value['phone1'])) {
                 $results[$key]['p_phone'] = $value['phone1'];
            } else if (!empty($value['phone2'])) {
                 $results[$key]['p_phone'] = $value['phone2'];
            } else if (!empty($value['phone3'])) {
                 $results[$key]['p_phone'] = $value['phone3'];
            } else if (!empty($value['phone4'])) {
                 $results[$key]['p_phone'] = $value['phone4'];
            } else if (!empty($value['phone5'])) {
                 $results[$key]['p_phone'] = $value['phone5'];
            } else if (!empty($value['phone6'])) {
                 $results[$key]['p_phone'] = $value['phone6'];
            } else {
                 $results[$key]['p_phone'] = "";
            }
            $last = M('crm_gj')->where("bao_id={$value['user_id']}")->order("create_time desc")->find();
            $results[$key]['last'] = $last['create_time'];
//
        }

       // $a = M()->getLastsql();
       // var_dump($a);die;

       if ($results == false){
           json('10002',"查询失败");
       }
        if ($results == null){
            json('10003',"没有检索到数据");
        }
        json('10001',$results);
    }
    //会员跟进 
    public function hygj()
    {
//        根据回传条件判断拼接查询条件
        header("access-control-allow-origin:*");
        $condition = I('post.');
        $centerid = session('centre_id');
        $time=I('post.nianyue');
        $user_id=session('user_id');
        $gw=M('xueyuan_baoming')->where("user_id='$user_id'")->getField("gangwei");
//        $centerid = session('centre_id');
        if($gw=='中心总监'){
            if(empty($time)){
                $where = "a.belong={$centerid} and a.yon=2 and a.status=1 and a.vip=1";
            }else{
                $where = "a.belong={$centerid} and a.yon=2 and a.status=1 and a.vip=1 and a.create_time like '%$time%' and a.gw_id='$user_id'";
            }
        }else{
            if(empty($time)){
            $where = "a.belong={$centerid} and a.yon=2 and a.status=1 and a.gw_id='$user_id' and a.vip=1";
        }else{
            $where = "a.belong={$centerid} and a.yon=2 and a.status=1 and a.gw_id='$user_id' and a.vip=1 and a.create_time like '%$time%'";
        }
        }
        if ($condition['name']){
            $where .= "  and (a.baobao_name like '%{$condition['name']}%' or a.baobao_name2 like '%{$condition['name']}%') ";
        }

        if ($condition['pname']){
            $where .= " and (a.name1 like '%{$condition['pname']}%' or a.name2 like '%{$condition['pname']}%' or a.name3 like '%{$condition['pname']}%' or a.name4 like '%{$condition['pname']}%' or a.name5 like '%{$condition['pname']}%' or a.name6 like '%{$condition['pname']}%') ";
        }

        if ($condition['pphone']){
            $where .= " and (a.phone1 like '%{$condition['pphone']}%' or a.phone2 like '%{$condition['pphone']}%' or a.phone3 like '%{$condition['pphone']}%' or a.phone4 like '%{$condition['pphone']}%' or a.phone5 like '%{$condition['pphone']}%' or a.phone6 like '%{$condition['pphone']}%') ";
        }

        if ($condition['type']){
            $where .= " and a.gj_type='{$condition['type']}'" ;
        }

        if ($condition['salesperson']){
            $where .= " and a.gw_id={$condition['salesperson']} ";
        }

//        链表联查
        if (!empty($condition['page'])){
            $page = $condition['page'];
        }else{
            $page =1;
        }

        $count = M('wx_user as a')
            ->join("left join crm_kjilu as b on a.jl_id=b.jl_id")
            ->field('a.user_id,a.baobao_name,b.y_keshi,a.name1,a.name2,a.name3,a.name4,a.name5,a.name6,a.phone1,a.phone2,a.phone3,a.phone4,a.phone5,a.phone6,b.e_time,a.baobao_birthday,b.bz')
            ->where($where)
            ->count();
        $pageone=10;//每页数据
        $pagetotal=ceil($count/$pageone);
        $pyl=($page-1)*$pageone;//偏移量
        $results = M('wx_user as a')
            ->join("left join crm_kjilu as b on a.jl_id=b.jl_id")
            ->limit($pyl,$pageone)
            ->where($where)
            ->field('a.user_id,a.baobao_name,b.y_keshi,a.name1,a.name2,a.name3,a.name4,a.name5,a.name6,a.phone1,a.phone2,a.phone3,a.phone4,a.phone5,a.phone6,b.e_time,a.baobao_birthday,b.bz')
            ->select();
       foreach ($results as $key => $value) {
            $results[$key]['page'] = $page;
            $results[$key]['pagetotal'] = $pagetotal;
            $results[$key]['num'] = $count;
//            关系判断
            if (!empty($value['name1'])) {
                $results[$key]['p_name'] = $value['name1'];
            } else if (!empty($value['name2'])) {
                $results[$key]['p_name'] = $value['name2'];
            } else if (!empty($value['name3'])) {
                 $results[$key]['p_name'] = $value['name3'];
            } else if (!empty($value['name4'])) {
                 $results[$key]['p_name'] = $value['name4'];
            } else if (!empty($value['name5'])) {
                 $results[$key]['p_name'] = $value['name5'];
            } else if (!empty($value['name6'])) {
                 $results[$key]['p_name'] = $value['name6'];
            } else {
                 $results[$key]['p_name'] = "";
            }
//        手机
            if (!empty($value['phone1'])) {
                 $results[$key]['p_phone'] = $value['phone1'];
            } else if (!empty($value['phone2'])) {
                 $results[$key]['p_phone'] = $value['phone2'];
            } else if (!empty($value['phone3'])) {
                 $results[$key]['p_phone'] = $value['phone3'];
            } else if (!empty($value['phone4'])) {
                 $results[$key]['p_phone'] = $value['phone4'];
            } else if (!empty($value['phone5'])) {
                 $results[$key]['p_phone'] = $value['phone5'];
            } else if (!empty($value['phone6'])) {
                 $results[$key]['p_phone'] = $value['phone6'];
            } else {
                 $results[$key]['p_phone'] = "";
            }
            $last = M('crm_gj')->where("bao_id={$value['user_id']}")->order("create_time desc")->find();
            $results[$key]['last'] = $last['create_time'];
//
        }

       // $a = M()->getLastsql();
       // var_dump($a);die;

       if ($results == false){
           json('10002',"查询失败");
       }
        if ($results == null){
            json('10003',"没有检索到数据");
        }
        json('10001',$results);
    }

}