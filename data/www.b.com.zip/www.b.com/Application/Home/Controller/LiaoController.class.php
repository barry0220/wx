<?php
namespace Home\Controller;
use Think\Controller;
class LiaoController extends Controller {
    //用户端查看聊天
    public function index(){
        ob_end_clean();
       header("access-control-allow-origin:*");
            //接口参数
            $t=I('get.');
            $us = M('wx_guanxi')->where("openid = '{$t['openid']}'")->field("id")->find();
            $t['id'] = $us['id'];
//            k($t);die;
            //拼接翻页地址
//            $t[url][0] ="http://".HTTP_HOST."Liao/index";

            //查询该用户是否有服务顾问 并批量刷新该用户服务顾问
//            $ppp =M("crm_msg")->where("id = {$t['id']} and user_id=0")->select();
//            if($ppp){
//                $this->shuagu($t['id']);
//            }

            //实例化 信息记录表
            $m = M("crm_msg");

            //查询条件
            $where = "id = {$t['id']}";

            $t = getfanye($m,$where,$t,10);

            $a=$m   ->where($where)
                    ->order("m_time desc")
                    ->select();
//
            foreach ($a as $k=>$v){
                $a[$k]['content'] = htmlspecialchars_decode($v['content']);
                if($v['f_ren'] == 1){
                    if($v['user_id'] == 1 || $v['user_id'] == 0){
                        $touxiang = "https://crm.gymbaby.cn/Uploads/1000.png";
                    }else{
                        $tou2 =  M('xueyuan_baoming')->field("img")->find("{$v['user_id']}");
                        $touxiang = $tou2['img'];
                    }
                }else{
                    $tou2 =  M('wx_guanxi')->field("img")->find("{$v['id']}");
                    $touxiang = $tou2['img'];
                }
                $a[$k]['touxiang'] = $touxiang;
            }
//            k($t);die;
            //判断翻页页数大于总页数 返回 3（停掉）
            if($t['p'] > $t['pages'] && $t['pages'] != 0){
                echo 3;die;
            }

            if(!$a){
                //判断如果该用户没有使用过提问系统，返回1，页面输出自动回答系统的首次聊天提示 同时在数据库插入一条首次聊天提示记录
                $xin['user_id'] = 1;                            //发信人=系统
                $xin['id'] = $t['id'];                          //收信人=当前登录人
                $xin['content'] = "首次聊天提示";                //内容=首次聊天提示
                $xin['read_status'] = 1;                        //阅读状态=已读
                $xin['f_ren'] = 1;                            //最后发信人 1=顾问 2=用户

                $da = M('wx_guanxi')->field("user_id,centre_id")->find("{$t['id']}");  //查询该登录人的宝宝ID 和 中心ID
//                k($da);die;
                if($da['user_id']){
                    $xin['bb_id'] = $da['user_id'];             //判断该登录人存在宝宝ID 写入聊天记录
                }
                $xin['centre_id'] = $da['centre_id'];             //判断该登录人存在宝宝ID 写入聊天记录
                $st = M("crm_msg")->add($xin);
                if($st){
                    echo 1;
                }
            }else{
                $data['fenye'] = $t;
                $data['data'] = $a;

                //打开页面查看数据后 把未读数据 状态修改成 已读
                $xxx['read_status'] = 1;
                $a=M("crm_msg")->where("id = {$t['id']} and read_status=0 and f_ren = 1")->save($xxx);

                $this->ajaxReturn($data,'JSON');
            }

   }
    //用户端发送新消息
    public function add(){
        header("access-control-allow-origin:*");
        ob_end_clean();
        $t=I('post.');
//        $t['id'] = M('wx_guanxi')->where("openid = '{$t['openid']}'")->find();
        //添加新的聊天记录
        $da = M('wx_guanxi')->field("user_id,centre_id")->find("{$t['id']}");  //查询该登录人的宝宝ID 和 中心ID
//                k($da);die;
        //判断该登录人是否 绑定 宝宝ID=宝宝ID 1.存在 收信人=查询宝宝的顾问  2.收信人=2；
        if($da['user_id']){
            $xin['bb_id'] = $da['user_id'];                 //判断该登录人存在宝宝ID 写入聊天记录
//                $yy = explode(",",$da['user_id']);
            $bao = M('wx_user')->where("user_id in({$da['user_id']})")->field("gw_id")->select();  //查询该登录人的宝宝ID 和 中心ID
            $gw_id = $bao[0]['gw_id'];               //收信人ID = 登录人宝宝的顾问
        }

        $xin['user_id'] = $gw_id ;                     //发信人=系统
        $xin['id'] = $t['id'];                         //收信人=当前登录人
        $xin['content'] = $t['content'];               //内容=首次聊天提示
        $xin['read_status'] = 0;                       //阅读状态=未读
        $xin['centre_id'] = $da['centre_id'];          //判断该登录人存在宝宝ID 写入聊天记录
        $xin['f_ren'] = 2;                             //最后发信人 1=顾问 2=用户

        $st = M("crm_msg")->add($xin);

        if($st){
            echo 2;
        }else{
            echo 3;
        }
    }
    //用户端自动回复后台存数据
    public function addzidong(){
        header("access-control-allow-origin:*");
        ob_end_clean();
        $t=I('post.');
//        $t['id'] = M('wx_guanxi')->where("openid = '{$t['openid']}'")->find();
        //判断如果该用户没有使用过提问系统，返回1，页面输出自动回答系统的首次聊天提示 同时在数据库插入一条首次聊天提示记录
        $xin['user_id'] = 1;                              //发信人=系统
        $xin['id'] = $t['id'];                            //收信人=当前登录人
        $xin['read_status'] = 1;                          //阅读状态=已读
        $da = M('wx_guanxi')->field("user_id,centre_id")->find("{$t['id']}");  //查询该登录人的宝宝ID 和 中心ID
        if($da['user_id']){
            $xin['bb_id'] = $da['user_id'];               //判断该登录人存在宝宝ID 写入聊天记录
        }
        $xin['centre_id'] = $da['centre_id'];             //判断该登录人存在宝宝ID 写入聊天记录

        for ($i=1;$i<3;$i++){
            $xin['f_ren'] = $i;                              //最后发信人 1=系统 2=用户
            $xin['content'] = $t['content'.$i];              //内容=首次聊天提示
            $st[] = M("crm_msg")->add($xin);
        }
        $this->ajaxReturn($st,'JSON');
    }
    //查询用户未读信息数量
    public function du(){
        header("access-control-allow-origin:*");
        ob_end_clean();
        $t=I('post.');
        $us = M('wx_guanxi')->where("openid = '{$t['openid']}'")->field("id")->find();
        $t['id'] = $us['id'];
        $a=M("crm_msg")->where("id = {$t['id']} and read_status=0 and f_ren = 1 and read_status = 0")->count();
//        k($a);die;
        echo $a;
    }


    //无客服用户  总监分配 客服后 批量修改 信息收信人  $id = 用户ID
    public function shuagu($id){
        header("access-control-allow-origin:*");
        ob_end_clean();
//        $id=I('post.id');
        $a=M("crm_msg")->where("id = {$id} and user_id=0")->order("m_time")->select();

        if($a){
            //修改某个（没有顾问的）用户的顾问ID
            $da = M('wx_guanxi')->field("user_id")->find("{$id}");  //查询该登录人的宝宝ID 和 中心ID
            //判断该登录人是否 绑定 宝宝ID=宝宝ID 1.存在 收信人=查询宝宝的顾问  2.收信人=2；
            if($da['user_id']){
                $bao = M('wx_user')->where("user_id in({$da['user_id']})")->field("gw_id")->select();  //查询该登录人的宝宝ID 和 中心ID
                if($bao[0]['gw_id'] != 0){
                    $gw_id['user_id'] = $bao[0]['gw_id'];               //收信人ID = 登录人宝宝的顾问

                    $a=M("crm_msg")->where("id = {$id} and user_id=0")->save($gw_id);
                    if($a){
                        echo 1;
                    }else{
                        echo 0;
                    }
                }
            }

        }
    }


    //客服的用户列表
    public function lie(){
        header("access-control-allow-origin:*");
        ob_end_clean();
        $t=I('post.');                  //user_id（顾问ID）

        $a=M("crm_msg as a")->join("wx_guanxi as b on a.id=b.id")
                            ->field("a.*,b.img,b.jz_name")
                            ->where("a.user_id={$t['user_id']}")
                            ->order("a.read_status,a.m_time desc")->select();
//        k($a);die;
        if($a){
            foreach ($a as $k=>$v){
                $w[$v['id']][] = $v;
            }
            foreach ($w as $k2=>$v2){
                $rr[] = $v2[0];
            }
//            k($rr);die;
            foreach ($rr as $k3=>$v3){
                $ming = M('wx_user')->where("user_id in({$v3['bb_id']})")->select();
                $ming2 = "";
                foreach ($ming as $k4=>$v4){
                    $ming2[] = $v4['baobao_name'];
                }
                $ming2 = implode("/",$ming2);
                $rr[$k3]['bao_name'] = $ming2;
                $rr[$k3]['m_time'] = substr($v3['m_time'],11,5);
                //判断消息状态 color=1=未读未回复  2=已读未回复 3=已读已回复
                if($v3['read_status'] == 0){
                    $rr[$k3]['color'] = 1;
                }else{
                    if($v3['hui_status'] == 0){
                        $rr[$k3]['color'] = 2;
                    }else{
                        $rr[$k3]['color'] = 3;
                    }
                }
            }
            $this->ajaxReturn($rr,'JSON');
        }else{
            echo 1;
        }
    }
    //客服端查看
    public function index2(){
        header("access-control-allow-origin:*");
        ob_end_clean();
        //接口参数
        $t=I('post.');                              //user_id = 顾问ID  id=用户ID

        //实例化 信息记录表
        $m = M("crm_msg");

        //查询条件
        $where = "id = {$t['id']}";

        $t = getfanye($m,$where,$t,10);

        $a=$m   ->where($where)
                ->order("m_time desc")
                ->select();

        //判断翻页页数大于总页数 返回 3（停掉）
        if($t['p'] > $t['pages']){
            echo 3;die;
        }

        foreach ($a as $k=>$v){
            if($v['f_ren'] == 1){
                if($v['user_id'] == 1 || $v['user_id'] == 0){
                    $touxiang = "https://crm.gymbaby.cn/Uploads/1000.png";
                }else{
                    $tou2 =  M('xueyuan_baoming')->field("img")->find("{$v['user_id']}");
                    $touxiang = $tou2['img'];
                }
            }else{
                $tou2 =  M('wx_guanxi')->field("img")->find("{$v['id']}");
                $touxiang = $tou2['img'];
            }
            $a[$k]['touxiang'] = $touxiang;
        }
            $data['fenye'] = $t;
            $data['data'] = $a;

            //打开页面查看数据后 把未读数据 状态修改成 已读
            $xxx['read_status'] = 1;
            $a=M("crm_msg")->where("id = {$t['id']} and read_status=0 and f_ren = 2")->save($xxx);

            $this->ajaxReturn($data,'JSON');
    }
    //客服端发送新消息
    public function addgu(){
        header("access-control-allow-origin:*");
        ob_end_clean();
        $t=I('post.');                      //user_id=客服ID id=用户ID 和 content=发信内容
        //添加新的聊天记录
        $da = M('wx_guanxi')->field("user_id,centre_id")->find("{$t['id']}");  //查询该登录人的宝宝ID 和 中心ID
        //判断该登录人是否 绑定 宝宝ID=宝宝ID 1.存在 收信人=查询宝宝的顾问  2.收信人=2；
        if($da['user_id']){
            $xin['bb_id'] = $da['user_id'];                 //判断该登录人存在宝宝ID 写入聊天记录
        }

        $xin['user_id'] = $t['user_id'] ;                   //发信人=系统
        $xin['id'] = $t['id'];                              //收信人=当前登录人
        $xin['content'] = $t['content'];                    //内容=首次聊天提示
        $xin['read_status'] = 0;                            //阅读状态=未读
        $xin['centre_id'] = $da['centre_id'];               //判断该登录人存在宝宝ID 写入聊天记录
        $xin['f_ren'] = 1;                                  //最后发信人 1=顾问 2=用户

        $st = M("crm_msg")->add($xin);
        if($st){
            //打开页面查看数据后 把未回复数据 状态修改成 已回复
            $xxx['hui_status'] = 1;
            $a=M("crm_msg")->where("id = {$t['id']} and hui_status=0 and f_ren = 2")->save($xxx);
            echo 2;
        }else{
            echo 3;
        }
    }



}