<?php
// 本类由系统自动生成，仅供测试用途
namespace Home\Controller;
use Think\Controller;
class IndexController extends CommonController {
    //首页
    public function index(){
        $cui = I('get.cui');
        if($cui==null){
            $cui=0;
        }
        $this->assign('cui',$cui);
//        k($cui);die;
        $a = M('wx_centre')->field('centre,ewm')->find(session('centre_id'));
        $user_id=session("user_id");
        $nav_id=M('xueyuan_baoming')->where("user_id='$user_id'")->getField("nav_id");
        $this->nav_id=explode(",", $nav_id);
        $this->assign('centre',$a['centre']);
        $arr=M('notice')->where("status=2")->select();
        foreach ($arr as $key => $value) {
            $time=explode(" ", $value['create_time']);
            $arr[$key]['time']=$time[0];
        }
        $gan=M('xueyuan_baoming')->where("user_id='$user_id'")->getField("gangwei");
        $this->gangwei=$gan;
        $this->ewm='http://www.yundongbaobei.cn'.$a['ewm'];
        $this->gg=$arr;
        $this->display();
    }
    //兔子捕蝴蝶
    public function right(){
        $this->display();
    }
    //Q1,提问自动回答
    public function wen(){
        header("access-control-allow-origin:*");
        $t = I('post.wen');
        $t = str_replace(' ','',$t);
//        $t = str_replace('\n\r','',$t);
//        k();
        $da = M('crm_wen')->where("(locate(guan,'{$t}') || wen like '%{$t}%' || da like '%{$t}%') and w_status=1")->select();
        $this->ajaxReturn($da,'JSON');
    }
}