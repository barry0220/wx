<?php
namespace Home\Controller;
use Think\Controller;
class GenjingController extends Controller {
  //跟进
    public function index(){
    	$this->display();
    }
    public function gqmingd(){
    	$this->display();
    }
    public function suogm(){
    	$this->display();
    }
    public function suogm2(){
        $this->display();
    }
    public function yuexinzengmd(){
        $this->display();
    }
    public function yuegenjinjl(){
        $this->display();
    }
    public function mingdanzs(){
        $this->display();
    }
    public function hetongshu(){
        $this->display();
    }
    public function qjinrienjinmd(){
        $this->display();
    }
    public function qjinrienjinxz(){
        $this->display();
    }
    public function hjinrienjinmd(){
        $this->display();
    }
    public function hjinrienjinxz(){
        $this->display();
    }
    public function hjinrijijigenj(){
        $this->display();
    }
    public function qjinrijijigenj(){
        $this->display();
    }

}