<?php
namespace Home\Controller;
use Think\Controller;
class ActivityController extends CommonController {
    public function index(){
      $time=date("Y-m-d");
      $centre_id=session("centre_id");
      $arr=M("crm_activity")->where("status=1 and is_kai=1 and start_time='$time' and centre_id='$centre_id'")->select();
      foreach ($arr as $key => $value) {
      	$d=explode(",",$value['user_id']);
      	$c=explode(",",$value['qian_id']);
      	foreach ($d as $k => $val) {
      	  $arr[$key]['user'][]=M("wx_user")->where("user_id='$val'")->field("baobao_name,user_id")->find();
      	}
      	$arr[$key]['user_id']=$d;
      	$arr[$key]['qian_id']=$c;
      }
      // echo "<pre>";
      // print_r($arr);die;
      $this->data=$arr;
      $this->display();
    }
    //签到
    public function qiandao(){
       $hd_id=I('post.hd_id');
       $user_id=I('post.user_id');
       $arr=M('crm_activity')->where("hd_id='$hd_id'")->field('qian_id,xiaohao')->find();
       $d=explode(",",$arr['qian_id']);
       if(in_array($user_id, $d)){
        $jl_id=M("wx_user")->where("user_id='$user_id'")->getField("jl_id");
       $f=explode(",",$jl_id);
       foreach ($f as $k => $val) {
         $y_keshi=M('crm_kjilu')->where("jl_id='$val'")->field("y_keshi,jl_id")->find();
         $jld=M('crm_activity')->where("hd_id='$hd_id'")->getField('jl_id');
         $jl=explode(",",$jld);
         if($y_keshi['y_keshi']>$arr['xiaohao']){
          if(empty($jl_id)){
            $data['jl_id']=$y_keshi['jl_id'];break;
          }else{
            $data['jl_id']=$jld.",".$y_keshi['jl_id'];break;
          }
         }else if($y_keshi['y_keshi']<$arr['xiaohao']){
           $this->ajaxReturn(3,'JSON');die;
          }
       }
        $qian_id=M('crm_activity')->where("hd_id='$hd_id'")->getField('qian_id');
        $d=explode(",",$qian_id);
        foreach ($d as $key => $value) {
          if($user_id!=$value){
            $user[] = $value;  //循环排除该用户
          }
        }
        $data['qian_id']=implode(",",$user);  //数组转成字符
        if(M('crm_activity')->where("hd_id='$hd_id'")->save($data)){
        echo 1;
       }
     }else{
       $jl_id=M("wx_user")->where("user_id='$user_id'")->getField("jl_id");
       $f=explode(",",$jl_id);
       foreach ($f as $k => $val) {
         $y_keshi=M('crm_kjilu')->where("jl_id='$val'")->field("y_keshi,jl_id")->find();
         $jld=M('crm_activity')->where("hd_id='$hd_id'")->getField('jl_id');
         if($y_keshi['y_keshi']>$arr['xiaohao']){
          if(empty($jl_id)){
            $data['jl_id']=$y_keshi['jl_id'];break;
          }else{
            $data['jl_id']=$jld.",".$y_keshi['jl_id'];break;
          }
         }else if($y_keshi['y_keshi']<$arr['xiaohao']){
           $this->ajaxReturn(3,'JSON');die;
          }
       }
        $qian_id=M('crm_activity')->where("hd_id='$hd_id'")->getField('qian_id');
        if($qian_id!=null){
         $data['qian_id']=$qian_id.",".$user_id;
        }else{
         $data['qian_id']=$user_id;
        }
        if(M('crm_activity')->where("hd_id='$hd_id'")->save($data)){
        echo 2;
       }
     }    
    }
    //结束活动
    public function hdjs(){
      $hd_id=I('post.hd_id');
      $arr=M('crm_activity')
      ->join('xueyuan_baoming on crm_activity.teacher=xueyuan_baoming.user_id')
      ->where("crm_activity.hd_id='$hd_id'")
      ->field('crm_activity.*,xueyuan_baoming.username')
      ->find();
      $centre_id=session('centre_id');
      $arrr=M('wx_centre')->where("centre_id='$centre_id'")->find();
      $d=explode(",",$arr['qian_id']);
      foreach ($d as $key => $value) {
        $jl=M("wx_user")
        ->join('crm_kjilu on wx_user.jl_id=crm_kjilu.jl_id')
        ->where("wx_user.user_id='$value'")
        ->field('wx_user.*,crm_kjilu.y_keshi')
        ->find();
        $jl_id=$jl['jl_id'];
         M('crm_kjilu')->where("jl_id='$jl_id'")->setDec('y_keshi',$arr['xiaohao']);
         $w['user_id']=$value;
         $w['pk_id'] = 0;
          $w['xiaohao'] = $arr['xiaohao'];
          $w['status'] = 2;
          $w['teacher']=$arr['teacher'];
          $w['create_time'] = date("Y-m-d",time());
          $w['centre_id'] = session("centre_id");
          $w['create_name'] = session("user_id");
          $w['source'] = "活动课";
          M('crm_user_skjl')->add($w);
          if($arrr['dx_kk']!=0 and $arrr['dx_y']>0){
             if($jl['phone1']!=null){
               $phone=$jl['phone1'];
             }else if($jl['phone2']!=null){
               $phone=$jl['phone2'];
             }else if($jl['phone3']!=null){
               $phone=$jl['phone3'];
             }else if($jl['phone4']!=null){
               $phone=$jl['phone4'];
             }else if($jl['phone5']!=null){
               $phone=$jl['phone5'];
             }else if($jl['phone6']!=null){
               $phone=$jl['phone6'];
             }
             $mb_id=$arrr['dx_kk'];
             $mb=M('crm_dx_mb')->where("mb_id='$mb_id'")->find();
             $ph=new \Org\dx\Photo;
             $aa=$ph->number($arrr['centre'],$jl['baobao_name'],$phone,$mb['alid'],$mb['mb_type'],$arr['start_time'],$arr['username'],$arr['title'],$arr['xiaohao'],$jl['y_keshi']);
             $dat['mb_id']=$arrr['dx_qianyue'];
             $dat['centre_id']=$centre_id;
             $dat['create_id']=session('user_id');
             $dat['phone']=$phone;
             $dat['user_id']=$value;
             $dat['nianyue']=date("Y-m");
             $dat['type']='自动';
             $vv=$aa->result->success[0];
               if($vv==true){
                 $dat['status']=1;
                 M('wx_centre')->where("centre_id='$centre_id'")->setDec('dx_y');
               }else{
                 $dat['status']=0;
               }
               M('crm_dx')->add($dat);
        }
      }
      $data['is_kai']=0;
      if(M('crm_activity')->where("hd_id='$hd_id'")->save($data)){
        echo 1;
       }
    }
    //搜索
    public function search(){
      $zhi=I('post.zhi');
      $shij=date("Y-m-d");
      $centre_id=session("centre_id");
      $sql="SELECT * FROM wx_user where yon=2 and belong='$centre_id' and status=1 and (baobao_name like '%$zhi%' or baobao_name2 like '%$zhi%' or name2 like '%$zhi%' or user_id like '%$zhi%')";
        $da=M()->query($sql);
        foreach ($da as $key => $val) {
          $d=strtotime($shij)-strtotime($val['baobao_birthday']);
          $e=$d/2592000;//一个月的时间，单位秒
          $f=round($e);//月龄取整
          $da[$key]['yueling']=$f;
        }
        $this->ajaxReturn($da);
    }
    //查询出可预约的课程
    public function dian(){
      $status=I('post.status');
      $centre_id=session('centre_id');
      $time=date("Y-m-d");
      if($status==1){
        $arr=M("crm_activity")->where("status=1 and is_kai=1 and centre_id='$centre_id' and start_time>='$time'")->order('start_time')->select();
        $this->ajaxReturn($arr);
      }
    }
    //预约课程
    public function yuy(){
      $hd_id=I('post.hd_id');
      $user_id=I('post.user_id');
      $id=M('crm_activity')->where("hd_id='$hd_id'")->getField('user_id');
      $d=explode(",",$id);
      if(in_array($user_id, $d)){
        echo 1;die;
      }else{
        if($id!=null){
        $data['user_id']=$id.",".$user_id;
        }else{
          $data['user_id']=$user_id;
        }
        if(M('crm_activity')->where("hd_id='$hd_id'")->save($data)){
        echo 0;
       }
      }
    }
    //活动设置
    public function hdsz(){
      $time=date("Y-m-d");
      $centre_id=session("centre_id");
      $this->teacher=M("xueyuan_baoming")->where("centre_id='$centre_id' and status=1")->field("user_id,username")->select();
      $arr=M("crm_activity")
      ->where("status=1 and is_kai=1 and centre_id='$centre_id' and start_time>='$time'")
      ->order('start_time')
      ->select();
      foreach ($arr as $key => $value) {
        $uu=explode(',', $value['teacher']);
        if($uu[0]==null){
          $arr[$key]['teach']=M('xueyuan_baoming')->where("user_id='$value[teacher]'")->field('user_id,username')->find();
        }else{
          foreach ($uu as $k => $val) {
          $arr[$key]['teach'][]=M('xueyuan_baoming')->where("user_id='$val'")->field('user_id,username')->find();
        }
        }
      }
      foreach ($arr as $key => $value) {
        $ac=explode(',', $value['user_id']);
        foreach ($ac as $k => $val) {
          if($value['user_id']!=null){
            $arr[$key]['yuyue'][]=M('wx_user')->where("user_id='$val'")->field('user_id,baobao_name')->find();
          }
        }
      }
      // echo "<pre>";
      // print_r($arr);die;
      $this->data=$arr;
      $this->display();
    }
    //取消预约
    function quxiaoyy(){
      $user_id=I('post.user_id');
      $hd_id=I('post.hd_id');
      $id=M('crm_activity')->where("hd_id='$hd_id'")->getField('user_id');
      $d=explode(",",$id);
      foreach ($d as $key => $value) {
        if($user_id!=$value){
          $aa[]=$value;
        }
      }
      $data['user_id']=implode(",",$aa);
        if(M('crm_activity')->where("hd_id='$hd_id'")->save($data)){
        echo 1;
       }
    }
    //添加活动
    public function add(){
      $upload = new \Think\Upload();        //实例化上传类
      $upload->maxSize   =     3145728 ;    // 设置附件上传大小
      $upload->exts      =     array('jpg', 'gif', 'png', 'jpeg');  // 设置附件上传类型
      $upload->savePath  =      './Activity/';                       // 设置附件上传目录
      $info   =   $upload->upload();                      // 上传文件
      $a=date("Y-m-d");                                             //获取并格式化当天日期
      $b=$info['img']['savename'];            // 实例化User对象
      $teacher=implode(',', I('post.teacher'));             //所有老师
      $centre_id=session("centre_id");
      $crm_activity = M("crm_activity");                // 实例化User对象
      $crm_activity->create();
      $crm_activity->img='https://img.gymbaby.org/Uploads/Activity/'.$a.'/'.$b;
      $crm_activity->teacher=$teacher;
      $crm_activity->centre_id=$centre_id;
      $crm_activity->add();
      $this->redirect("Activity/hdsz");
    }
    //修改活动
    public function xiu(){
      $teacher=implode(',', I('post.teacher'));             //所有老师
      $hd_id=I('post.hd');
      $crm_activity = M("crm_activity");                // 实例化User对象
      $crm_activity->create();
      $crm_activity->teacher=$teacher;
      $crm_activity->where("hd_id='$hd_id'")->save();
      $this->redirect("Activity/hdsz");
    }
    //往期活动
    public function wqhd(){
      if(isset($_GET['p'])){
         $page=$_GET['p'];
       }else{
         $page=1;
       }
       $centre_id=session("centre_id");
       $num=M('crm_activity')->where("status=1 and is_kai=0 and centre_id='$centre_id'")->count();
       $pageone=3;//每页数据
       $pagetotal=ceil($num/$pageone);
       $pyl=($page-1)*$pageone;//偏移量
       $this->page=$page;
       $this->pagetotal=$pagetotal;
       $this->num=$num;
       $sql="SELECT * FROM crm_activity where status=1 and is_kai=0 and centre_id='$centre_id' ORDER BY start_time desc limit $pyl,$pageone";
       $hh=M()->query($sql);
       foreach ($hh as $key => $value) {
         $uu=explode(',', $value['teacher']);
        if($uu[0]==null){
          $hh[$key]['teach']=M('xueyuan_baoming')->where("user_id='$value[teacher]'")->field('user_id,username')->find();
        }else{
          foreach ($uu as $k => $val) {
          $hh[$key]['teach'][]=M('xueyuan_baoming')->where("user_id='$val'")->field('user_id,username')->find();
        }
        }
       }
       foreach ($hh as $key => $value) {
         $d=explode(",",$value['user_id']);
         if(!empty($value['qian_id'])){
          $e=explode(",",$value['qian_id']);
          $keshi=count($e);
         }
         $hh[$key]['yuy']=count($d);
         $hh[$key]['qian']=$keshi;
         $hh[$key]['keshi']=$keshi*$value['xiaohao'];//总耗课时
         foreach ($e as $k => $val) {
           $hh[$key]['user'][]=M('wx_user')->where("user_id='$val'")->field("user_id,jl_id")->find();
         }
       }
       foreach ($hh as $key => $value) {
         foreach ($value['user'] as $k=> $val) {
           $hh[$key]['mon'][]=M('crm_kjilu')
           ->join('crm_goods on crm_kjilu.s_id=crm_goods.s_id')
           ->where("crm_kjilu.jl_id='$val[jl_id]'")
           ->find();
         }
       }
       foreach ($hh as $key => $value) {
         $c=0;
         foreach ($value['mon'] as $ke => $v) {
         // $g=$v['k_shu']+$v['zeng_ke'];
         $a=$v['shishou']/$v['k_shu'];
         $b=$a*$value['xiaohao'];
         $c=$c+$b;
         $hh[$key]['money']=round($c);
         continue;
         }
       }
      $this->data=$hh;
      $this->display();
    }
    public function qksz(){
      $this->display();
    }
    public function addqian(){
      $ph=new \Org\dx\Photo;
      $telephone=I('post.phone');
      $time=I('post.time');
      $title=I('post.title');
      $centre_id=session('centre_id');
      $user=M('wx_user')->where("belong='$centre_id' and vip=0 and yon=2")->select();
      foreach ($user as $key => $value) {
        $dx_y=M('wx_centre')->where("centre_id='$centre_id'")->getField('dx_y');
        if($dx_y>1){
        if($value['phone1']!=null){
          $phone=$value['phone1'];
        }else if($value['phone2']!=null){
          $phone=$value['phone2'];
        }else if($value['phone3']!=null){
          $phone=$value['phone3'];
        }else if($value['phone4']!=null){
          $phone=$value['phone4'];
        }else if($value['phone5']!=null){
          $phone=$value['phone5'];
        }else if($value['phone6']!=null){
          $phone=$value['phone6'];
        }
        $mb_id=7;
        $mb=M('crm_dx_mb')->where("mb_id='$mb_id'")->find();
        $aa=$ph->number($centre,$value['baobao_name'],$phone,$mb['alid'],$mb['mb_type'],$time,$title,$telephone);
        $data['mb_id']=$mb_id;
        $data['centre_id']=$centre_id;
        $data['create_id']=session('user_id');
        $data['phone']=$phone;
        $data['user_id']=$value['user_id'];
        $data['nianyue']=date("Y-m");
        $data['type']='手动';
        $vv=$aa->result->success[0];
     if($vv==true){
       $data['status']=1;
       M('wx_centre')->where("centre_id='$centre_id'")->setDec('dx_y');
     }else{
       $data['status']=0;
     }
     M('crm_dx')->add($data);
   }
      }
      $this->redirect("Activity/qksz");
    }
    public function shanchu(){
      $crm_activity=M("crm_activity");
      $id=I('post.id');
      $data['status']=0;
      $rel=$crm_activity->where("hd_id=".$id)->save($data);
      if($rel){
        echo 1;
      }
    }
}