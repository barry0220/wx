<?php
namespace Home\Controller;
use Think\Controller;
/**
 *
 * 进销存模块 出入库类别控制器
 *
*/
class JxcOutStorageController extends CommonController {
    //获取当前中心出入库类别信息
    public function index(){
        ob_clean();

        $centre_id = session('centre_id');   //获取当前门店ID  测试为1

        //判断是否存在条件查询
        $post_data = I('post.map');
        $search = $post_data['search'];
        $type = $post_data['type'];
        $is_use = $post_data['is_use'];
        $page = $post_data['page'] ? $post_data['page'] : 1;
        $pageone=$post_data['pageone'] ? $post_data['pageone'] : 10;//每页数据
        $map['search'] = $search;  //条件返回
        $map['type'] = $type;
        $map['is_use'] = $is_use;
        $map['page'] = $page;
        $map['pageone'] = $pageone;
        //组装where条件
        $where = [
            'centre_id' => $centre_id,
            'status'=>1
        ];

        if($search){
            $where['name'] = [['like', "%{$search}%"]];
        }
        if ($type) {
            $where['type']=$type;
        }
        if ($is_use){
            $where['is_use']= $is_use;
        }

        $Storages = M('jxc_out_storage');      //实例化

        $count = $Storages ->where($where)->count();   //获取数据总数
        $pagetotal=ceil($count/$pageone);   //总页数
        $map['pagetotal'] = $pagetotal; //返回参数 总页数
        $pyl=($page-1)*$pageone;//偏移量

        $res = $Storages  -> where($where)->order('id desc')->limit($pyl,$pageone) -> select();   //获取结果信息

        $data = ['map'=>$map,'data'=>$res];

        $this -> ajaxReturn($data,'JSON');
    }


    //执行添加出入库类别
    public function store()
    {
        ob_clean();
        //判断是否非法访问 非法方式返回错误
        if (!IS_POST) {
            $this -> ajaxReturn(['status'=>1,'msg'=>'请求方式不合法'],'JSON');
        }
        //创建验证规则
        $rules = [
            ["data['name']",'require','类别名称不能为空'],
            ["data['type']",'require','类型不能为空'],
            ["data['is_use']",'require','状态不能为空']
        ];

        $Storages = D("jxc_out_storage"); // 实例化对象
        $post_data = I('post.data');

        if (!$Storages->validate($rules) -> create($post_data)){     // 如果创建失败 表示验证没有通过 输出错误提示信息
            $this -> ajaxReturn(['status'=>1,'msg'=>"验证失败".$Storages->getError()],'JSON');
        }else{     // 验证通过 可以进行其他数据操作
            //获取数据
            $centre_id = session('centre_id');   //获取当前门店ID
            $fields['name'] = $post_data['name'];  //名称
            $fields['type'] = $post_data['type'];
            $fields['is_use'] = $post_data['is_use'];
            $fields['centre_id'] = $centre_id;
            $user_id = session("user_id");  //获取当前登陆用户的user_id  总部后台管理系统获取mg_id  会员管理系统获取user_id
            $fields['user_id'] = $user_id;
            $fields['status'] = 1;
            //创建模型对象
            $Storages->create($fields);
            //执行添加
            $res = $Storages->add();

            if($res){
                $this -> ajaxReturn(['status'=>2,'msg'=>'添加成功'],'JSON');
            } else {
                $this -> ajaxReturn(['status'=>1,'msg'=>'添加失败'],'JSON');
            }
        }
    }


    //获取单条出入库类别信息
    public function edit()
    {
        ob_clean();

        $Storages_id = I('post.id');    //获取要查询的供货商的ID

        $Storages= M('jxc_out_storage');

        $res = $Storages -> where("id='$Storages_id'") -> find();

        $data = ['data'=>$res];
        $this -> ajaxReturn($data,'JSON');
    }

    //修改出入库类别信息
    public function update()
    {
        ob_clean();
        //判断是否非法访问 非法方式返回错误
        if (!IS_POST) {
            $this -> ajaxReturn(['status'=>1,'msg'=>'请求方式不合法'],'JSON');
        }
        //创建验证规则
        $rules = [
            ['name','require','类别名称不能为空'],
            ['type','require','类型不能为空'],
            ['is_use','require','状态不能为空']
        ];

        $Storages = M("jxc_out_storage"); // 实例化对象
        //获取数据
        $post_data = I('post.data');
        if (!$Storages->validate($rules) -> create($post_data)){     // 如果创建失败 表示验证没有通过 输出错误提示信息
            $this -> ajaxReturn(['status'=>1,'msg'=>'验证失败'.$Storages->getError()],'JSON');

        }else{     // 验证通过 可以进行其他数据操作

            $Storages_id = $post_data['id'];
            $fields['name'] = $post_data['name'];  //名称
            $fields['type'] = $post_data['type'];
            $fields['is_use'] = $post_data['is_use'];

            //执行修改
            $res = $Storages->where('id='.$Storages_id)->save($fields);

            if($res){
                //写入LOG
                $content = "修改出入库类别".$fields['name']."成功";
                setLog($content);
                $this -> ajaxReturn(['status'=>2,'msg'=>'修改成功'],'JSON');
            } else {
                $this -> ajaxReturn(['status'=>1,'msg'=>'修改失败'],'JSON');
            }
        }


    }

    //删除出入库类别信息  安全删除  状态修改为0
    public function delete()
    {
        ob_clean();
        $Storages_id = I('post.id');

        $fields['status'] = 0;
        $res = M('jxc_out_storage')->where("id = '{$Storages_id}'")->save($fields);
        if($res){
            //写入LOG
            $storage_name = M('jxc_out_storage')->where("id = $Storages_id")->find()['name'];
            $content = "删除出入库类别".$storage_name."成功";
            setLog($content);
//       $this->success('删除成功', U('JxcGoodsType/index'), 3);
            $this -> ajaxReturn(['status'=>2,'msg'=>'删除成功'],'JSON');
        } else {
            $this -> ajaxReturn(['status'=>1,'msg'=>'删除失败'],'JSON');
//            $this->success('删除失败', U('JxcGoodsType/index'), 3);
        }
    }

    //禁用出入库状态信息
    public function notallow()
    {
        ob_clean();
        $Storages_id = I('post.id');

        $fields['is_use'] = 1;
        $res = M('jxc_out_storage')->where("id = '{$Storages_id}'")->save($fields);
        if( false !== $res){
            $this -> ajaxReturn(['status'=>2,'msg'=>'禁用成功'],'JSON');
        } else {
            $this -> ajaxReturn(['status'=>1,'msg'=>'禁用失败'],'JSON');
        }
    }
    //启用出入库状态信息
    public function allow()
    {
        ob_clean();
        $Storages_id = I('post.id');

        $fields['is_use'] = 2;
        $res = M('jxc_out_storage')->where("id = '{$Storages_id}'")->save($fields);
        if( false !== $res){
            $this -> ajaxReturn(['status'=>2,'msg'=>'启用成功'],'JSON');
        } else {
            $this -> ajaxReturn(['status'=>1,'msg'=>'启用失败'],'JSON');
        }
    }

}