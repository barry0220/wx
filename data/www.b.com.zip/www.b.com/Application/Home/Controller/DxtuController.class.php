<?php
namespace Home\Controller;
use Think\Controller;
class DxtuController extends Controller {
  //短信折线统计图
    public function index(){
      header("access-control-allow-origin:*");
      $centre_id=session('centre_id');
      $year=date("Y");
      $yue=date("m")+1;
      for ($i=1; $i < $yue; $i++) { 
      	if(strlen($i)==1){
      		$nianyue=$year.'-'.'0'.$i;
      	}else{
      		$nianyue=$year.'-'.$i;
      	}
      	$arr[]=M('crm_dx')->where("nianyue='$nianyue' and centre_id='$centre_id' and status=1")->count();
      }
      $this->ajaxReturn($arr,'JSON');
    }
}