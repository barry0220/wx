<?php
namespace Home\Controller;
use Think\Controller;
class DxfsdxController extends Controller {
  //发送短信
    public function index(){
       header("access-control-allow-origin:*");
       $mb_id=I('post.mb_id');
       $user_id=I('post.user_id');
       $phone=I('post.phone');
       $centre_id=session('centre_id');
       $mb=M('crm_dx_mb')->where("mb_id='$mb_id'")->field('mb_type,alid')->find();
       $w_key=$mb['alid'];
       $mb_type=$mb['mb_type'];
       $centre=M('wx_centre')->where("centre_id='$centre_id'")->getField('centre');
       $ph=new \Org\dx\Photo;
       switch ($mb_type) {
         case '生日提醒':
           foreach ($user_id as $key => $value) {
            $username=M('wx_user')->where("user_id='$value'")->getField('baobao_name');
            $aa=$ph->number($centre,$username,$phone[$key],$w_key,$mb_type);
            $data['mb_id']=$mb_id;
            $data['centre_id']=$centre_id;
            $data['create_id']=session('user_id');
            $data['phone']=$phone[$key];
            $data['user_id']=$value;
            $data['nianyue']=date("Y-m");
            $data['type']='手动';
              $vv=$aa->result->success[0];
             if($vv==true){
              $data['status']=1;
              M('wx_centre')->where("centre_id='$centre_id'")->setDec('dx_y');
            }else{
              $data['status']=0;
            }
            M('crm_dx')->add($data);
       }
          break;
          case '上课短信通知':
            foreach ($user_id as $key => $value) {
              $arr=M('crm_user_skjl')
              ->join("wx_user on crm_user_skjl.user_id=wx_user.user_id")
              ->join("crm_kjilu on wx_user.jl_id=crm_kjilu.jl_id")
              ->join("xueyuan_baoming on crm_user_skjl.teacher=xueyuan_baoming.user_id")
              ->join("crm_kecheng on crm_user_skjl.pk_id=crm_kecheng.pk_id")
              ->join("crm_ke on crm_kecheng.kc_id=crm_ke.kc_id")
              ->where("crm_user_skjl.user_id='$value' and crm_user_skjl.status=2")
              ->order('crm_user_skjl.sk_id desc')
              ->field('wx_user.baobao_name,crm_user_skjl.create_time,xueyuan_baoming.username,crm_ke.kc_name,crm_user_skjl.xiaohao,crm_kjilu.y_keshi')
              ->find();
            $aa=$ph->number($centre,$arr['baobao_name'],$phone[$key],$w_key,$mb_type,$arr['create_time'],$arr['username'],$arr['kc_name'],$arr['xiaohao'],$arr['y_keshi']);
            $data['mb_id']=$mb_id;
            $data['centre_id']=$centre_id;
            $data['create_id']=session('user_id');
            $data['phone']=$phone[$key];
            $data['user_id']=$value;
            $data['nianyue']=date("Y-m");
            $data['type']='手动';
              $vv=$aa->result->success[0];
             if($vv==true){
              $data['status']=1;
              M('wx_centre')->where("centre_id='$centre_id'")->setDec('dx_y');
            }else{
              $data['status']=0;
            }
            M('crm_dx')->add($data);
            }
            break;
            case '签约短信':
              foreach ($user_id as $key => $value) {
                $arr=M('wx_user')
                ->join("crm_kjilu on wx_user.jl_id=crm_kjilu.jl_id")
                ->join("crm_goods on crm_kjilu.s_id=crm_goods.s_id")
                ->where("wx_user.user_id='$value'")
                ->field('wx_user.name1,wx_user.name2,wx_user.name3,wx_user.name4,wx_user.name5,wx_user.name6,wx_user.baobao_name,crm_kjilu.hetong,crm_kjilu.shishou,crm_goods.k_shu,crm_kjilu.zeng_ke,crm_kjilu.create_time,crm_kjilu.e_time')
                ->find();
                if($arr['name1']!=null){
                  $name=$arr['name1'];
                }else if($arr['name2']!=null){
                  $name=$arr['name2'];
                }else if($arr['name3']!=null){
                  $name=$arr['name3'];
                }else if($arr['name4']!=null){
                  $name=$arr['name4'];
                }else if($arr['name5']!=null){
                  $name=$arr['name5'];
                }else if($arr['name6']!=null){
                  $name=$arr['name6'];
                }
                $keshi=$arr['k_shu']+$arr['zeng_ke'];
                $aa=$ph->number($centre,$arr['baobao_name'],$phone[$key],$w_key,$mb_type,$name,$arr['hetong'],$arr['shishou'],$keshi,$arr['create_time'],$arr['e_time']);
                $data['mb_id']=$mb_id;
                $data['centre_id']=$centre_id;
                $data['create_id']=session('user_id');
                $data['phone']=$phone[$key];
                $data['user_id']=$value;
                $data['nianyue']=date("Y-m");
                $data['type']='手动';
                $vv=$aa->result->success[0];
               if($vv==true){
                 $data['status']=1;
                 M('wx_centre')->where("centre_id='$centre_id'")->setDec('dx_y');
               }else{
                 $data['status']=0;
               }
               M('crm_dx')->add($data);
                 }
              break;
              case '合约到期提醒':
                foreach ($user_id as $key => $value) {
                  $arr=M('wx_user')
                  ->join("crm_kjilu on wx_user.jl_id=crm_kjilu.jl_id")
                  ->where("wx_user.user_id='$value'")
                  ->field('wx_user.baobao_name,crm_kjilu.y_keshi')
                  ->find();
                  $keshi=$arr['y_keshi']+1;
                  $time=date('Y-m-d');
                  $aa=$ph->number($centre,$arr['baobao_name'],$phone[$key],$w_key,$mb_type,$keshi,$time);
                $data['mb_id']=$mb_id;
                $data['centre_id']=$centre_id;
                $data['create_id']=session('user_id');
                $data['phone']=$phone[$key];
                $data['user_id']=$value;
                $data['nianyue']=date("Y-m");
                $data['type']='手动';
                $vv=$aa->result->success[0];
               if($vv==true){
                 $data['status']=1;
                 M('wx_centre')->where("centre_id='$centre_id'")->setDec('dx_y');
               }else{
                 $data['status']=0;
               }
               M('crm_dx')->add($data);
                }
                break;
       }
         echo $vv;
       
   }
}