<?php
namespace Home\Controller;
use Think\Controller;
class BiaoController extends CommonController {
    //合约列表
    public function indexh(){
        $t = I('get.');						//获取查询条件
        $centre_id 	=session("centre_id");		//中心ID
        
        //拼接翻页地址
        $t[url][0] ="https://".HTTP_HOST."Biao/indexh";
        //实例化 合约记录 表
        $m = M("crm_kjilu as a")->join("left join xueyuan_baoming as b on a.guwen=b.user_id")
                                ->join("left join crm_goods as d on a.s_id=d.s_id")
                                ->field("a.*,b.username,d.s_name");

        //查询条件
        $where = "a.centre_id='{$centre_id}'";
        if($t['time_s']){
            $where .= " and a.create_time>='{$t['time_s']}'";
            $t[url][0] .="/time_s/".$t['time_s'];
        }
        if($t['time_e']){
            $where .= " and '{$t['time_e']}'>=a.create_time";
            $t[url][0] .="/time_e/".$t['time_e'];
        }
        if($t['hetong']){
            $where .= " and a.hetong ='{$t['hetong']}'";
            $t[url][0] .="/hetong/".$t['hetong'];
        }
        if($t['user_id']){
            $where .= " and a.guwen ='{$t['user_id']}'";
            $t[url][0] .="/user_id/".$t['user_id'];
        }

        //判断不筛选宝宝姓名的时候 进行分页
        if(!$t['name']){
            //金额合计
            $m1=clone $m;//浅复制一个模型
            $he = $m1->where($where)->sum("shishou");
            $t = getfanye($m,$where,$t,20);
        }
        //查询 合约信息 销售人信息 商品信息
        $all=$m     ->where($where)
                    ->order("a.create_time desc")
                    ->select();
        
        //判断有姓名检索时 查询所有符合检索条件的宝宝的ID-->循环判断留下之前查出的数据中的符合条件的合约数据
        if($t['name']){
            $baouser_id = M('wx_user')->where("belong = '{$centre_id}' and (baobao_name like '%{$t['name']}%' || baobao_name2 like '%{$t['name']}%')")->field("user_id as bao_id")->select();
            foreach ($baouser_id as $k0){
                $cs[] = $k0['bao_id'];
            }
            foreach ($all as $k=>$v){
                $hy = explode(",",$v['user_id']);
                foreach ($cs as $k7=>$v7){
                    if(in_array($v7,$hy)){
                        $a[] = $v;
                    }
                }
            }
        }else{
            $a = $all;
        }
        
        //循环拼接宝宝姓名 截取签约日期
        foreach ($a as $k=>$v){
            //判断姓名检索时 重新计算订单合计
            if($t['name']){
                $he = $v['shishou'] + $he;
            }
            $a[$k]['create_time'] = substr($v['create_time'],0,-9);
            $baouser = M('wx_user')->where("user_id in({$v['user_id']})")->field("user_id as bao_id,baobao_name")->select();
//            k($baouser);die;
            $yy = '';
            foreach ($baouser as $k2=>$v2){
                $yy[] = $v2;
            }
//            $yy = implode(",",$yy);
            $a[$k]['baobao_name'] = $yy;
        }
        //判断姓名检索时 重新计算订单数量
        if($t['name']){
            $t['count'] = count($a);
        }
        //查询所有 营销姓名
        $this->ying = M('xueyuan_baoming')->where("centre_id='{$centre_id}' and gangwei='营销'")->field("user_id,username")->select();
        $this->assign('ar',$t);					//查询条件回传
        $this->assign('data',$a);
        $this->assign('he',$he);
        $this->display();
    }
    //耗课列表
    public function indexk(){
        $t = I('get.');						//获取查询条件
        $centre_id 	=session("centre_id");		//中心ID
        
        //拼接翻页地址
        $t[url][0] ="https://".HTTP_HOST."Biao/indexk";
//        k($t);die;
        //实例化上课记录表 （报名表-老师姓名 会员表-宝宝姓名 合约表-实收金额 商品表-课时数量 课程表-课程名称）
        $m = M("crm_user_skjl as a")->join("left join xueyuan_baoming as b on a.teacher=b.user_id")
                                    ->join("wx_user as c on a.user_id=c.user_id")
                                    ->join("left join crm_kecheng as f on f.pk_id=a.pk_id")
                                    ->join("left join crm_ke as g on g.kc_id=f.kc_id")
                                    ->join("left join crm_kjilu as d on c.jl_id=d.jl_id")
                                    ->join('left join crm_goods as e on d.s_id=e.s_id')
                                    ->field("a.*,b.username,c.baobao_name,g.kc_name");

        //查询条件 中心ID 已结课课程
        $where = "a.centre_id='{$centre_id}' and a.status=2";
        if($t['time_s']){
            $where .= " and a.create_time>='{$t['time_s']}'";
            $t[url][0] .="/time_s/".$t['time_s'];
        }
        if($t['time_e']){
            $where .= " and a.create_time<='{$t['time_e']}'";
            $t[url][0] .="/time_e/".$t['time_e'];
        }
        if($t['user_id']){
            $where .= " and b.user_id='$t[user_id]'";
            $t[url][0] .="/user_id/".$t['user_id'];
        }
        if($t['name']){
            $where .= " and (baobao_name like '%{$t['name']}%') and belong={$centre_id}";
            $t[url][0] .="/name/".$t['name'];
        }
        if($t['kc_name']){
            $where .= " and (g.kc_name like '%{$t['kc_name']}%')";
            $t[url][0] .="/kc_name/".$t['kc_name'];
        }

        //金额合计
        $m1=clone $m;//浅复制一个模型
        $he = $m1->where($where)->sum("a.xiaohao*round(d.shishou/e.k_shu)");

        //耗课合计(不包括课时修正)
        $m2=clone $m;//浅复制一个模型
        $haoke = $m2->where($where)->sum("a.xiaohao");

        $t = getfanye($m,$where,$t,20);
        // k($t);die;
        $this->assign('ar',$t);					//查询条件回传
        //查询 合约信息 销售人信息 商品信息
        $a=$m   ->where($where)
                ->order("a.create_time desc")
                ->select();

        foreach ($a as $k=>$v){
            if($v['source']=='活动课'){
                $a[$k]['kc_name']='活动课';
            }elseif($v['source']=='前台' || $v['source']=='后台'){
                $a[$k]['kc_name']='课时修正';
            }
        }
        // foreach ($a as $key => $value) {
        //     $a[$key]['heyue']=M('crm_kjilu')
        //     ->join("crm_goods on crm_kjilu.s_id=crm_goods.s_id")
        //     ->where("crm_kjilu.user_id='$value[user_id]' and (crm_kjilu.status=1 or crm_kjilu.status=3)")
        //     ->select();
        // }

        //    foreach ($a as $key => $value) {
        //     $zk=0;
        //     $zq=0;
        //     foreach ($value['heyue'] as $k => $val) {
        //         $zk=$val['k_shu']+$val['zeng_ke']+$zk;
        //         $zq=$val['shishou']+$zq;
        //         $dj=$zq/$zk;
        //         $a[$key]['k_d']=round($dj);
        //         $a[$key]['k_h']=$dj*$value['xiaohao'];
        //     }
            
        // }
        $are=M('crm_kjilu')
        ->join("crm_goods on crm_kjilu.s_id=crm_goods.s_id")
        ->where("crm_kjilu.centre_id='$centre_id' and (crm_kjilu.status=1 or crm_kjilu.status=3)")
        ->select();
        foreach ($are as $key => $value) {
            $are[$key]['user']=explode(",", $value['user_id']);
        }
        foreach ($a as $key => $value) {
            foreach ($are as $k => $val) {
                if(in_array($value['user_id'], $val['user'])){
                    $a[$key]['heyue'][]=$val;
                }
            }
        }
        foreach ($a as $key => $value) {
            $zk=0;
            $zq=0;
            foreach ($value['heyue'] as $k => $val) {
                $zk=$val['k_shu']+$val['zeng_ke']+$zk;
                $zq=$val['shishou']+$zq;
                $dj=round($zq/$zk);
                $a[$key]['k_d']=$dj;
                $a[$key]['k_h']=$dj*$value['xiaohao'];
            }
            
        }
        //查询所有 营销姓名
        $this->shi = M('xueyuan_baoming')->where("centre_id='{$centre_id}' and gangwei='老师'")->field("user_id,username")->select();
        $this->assign('ar',$t);					//查询条件回传
        $this->assign('data',$a);
        $this->assign('he',$he);
        $this->assign('ke',$haoke);
        $this->display();
    }
    //未结课列表
    public function wjk(){
        $t = I('get.');						//获取查询条件
        $centre_id 	=session("centre_id");		//中心ID

        //拼接翻页地址
        $t[url][0] ="https://".HTTP_HOST."Biao/wjk";
//        k($t);die;
        //实例化上课记录表 （报名表-老师姓名 会员表-宝宝姓名 合约表-实收金额 商品表-课时数量 课程表-课程名称）
        $m = M("crm_user_skjl as a")->join("left join xueyuan_baoming as b on a.teacher=b.user_id")
            ->join("wx_user as c on a.user_id=c.user_id")
            ->join("left join crm_kjilu as d on c.jl_id=d.jl_id")
            ->join("left join crm_goods as e on e.s_id=d.s_id")
            ->join("left join crm_kecheng as f on f.pk_id=a.pk_id")
            ->join("left join crm_ke as g on g.kc_id=f.kc_id")
            ->field("a.*,b.username,c.baobao_name,round(d.shishou/e.k_shu) as k_d,a.xiaohao*round(d.shishou/e.k_shu) as k_h,g.kc_name");

        //查询条件 中心ID 已结课课程
        $where = "a.centre_id='{$centre_id}' and a.status=1";
        if($t['time_s']){
            $where .= " and a.create_time>='{$t['time_s']}'";
            $t[url][0] .="/time_s/".$t['time_s'];
        }
        if($t['time_e']){
            $where .= " and a.create_time<='{$t['time_e']}'";
            $t[url][0] .="/time_e/".$t['time_e'];
        }
        if($t['user_id']){
            $where .= " and b.user_id='$t[user_id]'";
            $t[url][0] .="/user_id/".$t['user_id'];
        }
        if($t['name']){
            $where .= " and (baobao_name like '%{$t['name']}%') and belong={$centre_id}";
            $t[url][0] .="/name/".$t['name'];
        }
        if($t['kc_name']){
            $where .= " and (g.kc_name like '%{$t['kc_name']}%')";
            $t[url][0] .="/kc_name/".$t['kc_name'];
        }

        //金额合计
        $m1=clone $m;//浅复制一个模型
        $he = $m1->where($where)->sum("a.xiaohao*round(d.shishou/e.k_shu)");

        //耗课合计(不包括课时修正)
        $m2=clone $m;//浅复制一个模型
        $haoke = $m2->where($where." and a.xiaohao > 0")->sum("a.xiaohao");

        $t = getfanye($m,$where,$t,20);
        $this->assign('ar',$t);					//查询条件回传
        //查询 合约信息 销售人信息 商品信息
        $a=$m   ->where($where)
            ->order("a.create_time desc")
            ->select();

        foreach ($a as $k=>$v){
            if($v['source']=='活动课'){
                $a[$k]['kc_name']='活动课';
            }elseif($v['source']=='前台'){
                $a[$k]['kc_name']='课时修正';
            }
        }
//         k($t);die;
        //查询所有 营销姓名
        $this->shi = M('xueyuan_baoming')->where("centre_id='{$centre_id}' and gangwei='老师'")->field("user_id,username")->select();

        $this->assign('ar',$t);					//查询条件回传
        $this->assign('data',$a);
        $this->assign('he',$he);
        $this->assign('ke',$haoke);
        $this->display();
    }
}