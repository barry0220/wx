<?php
namespace Home\Controller;
use Think\Controller;
/**
 *
 * 进销存模块 商品信息控制器
 *
 */
class JxcGoodsController extends CommonController {
    //获取当前中心所有商品信息 相应商品类别 供应商 需求参数 {'search':'商品名称','typeid':'商品类别ID','supplierid':'供应商ID','page':'当前页码','pageone':'每页数量'}
    public function index(){
        ob_clean();
        $centre_id = session('centre_id');   //获取当前门店ID  测试为1

        //组装where条件
        $where = [
            'jxc_goods.centre_id' => $centre_id,
            'jxc_goods.status' => 1
        ];
        $param = I('post.map');
        //判断是否存在条件查询
        $search = $param['search'];
        $typeid = $param['typeid'];
        $supplierid = $param['supplierid'];
        $page = $param['page'] ? $param['page'] : 1;
        $pageone=$param['pageone'] ? $param['pageone'] : 10;//每页数据

        $map = $param;  //条件返回
        if ($search) {
            $where['jxc_goods.good_name']= ['like', "%{$search}%"];
        }
        if ($typeid) {
            $where['jxc_goods.type_id']= $typeid;
        }
        if ($supplierid) {
            $where['jxc_goods.supplier_id']= $supplierid;
        }


        $Goods = M('jxc_goods')->field('jxc_goods.*,jxc_goods_type.type_name,jxc_supplier.supplier_name')
            ->join('jxc_goods_type on jxc_goods.type_id = jxc_goods_type.id','left')
            ->join('jxc_supplier on jxc_goods.supplier_id = jxc_supplier.id','left');      //实例化
        $m = clone $Goods;
        $count = $Goods ->where($where)->count();   //获取数据总数
        $pagetotal=ceil($count/$pageone);   //总页数
        $map['pagetotal'] = $pagetotal; //返回参数 总页数
        $pyl=($page-1)*$pageone;//偏移量
        $Goods = $m;
        // 所有商品信息 相应商品类别 供应商
        $res = $Goods-> where($where)->order('id desc')->limit($pyl,$pageone) -> select();   //获取结果信息


        //获取所有的商品类别 供应商
        $suppliers = M('jxc_supplier') -> where(['status'=>1])->where('centre_id='.$centre_id)->select();
        $good_types = M('jxc_goods_type') -> where(['status'=>1])->where('centre_id='.$centre_id)->select();


        $data = ['map'=>$map,'suppliers'=>$suppliers,'good_types'=>$good_types,'data'=>$res];

        $this -> ajaxReturn($data);
    }

    //显示添加页面
    public function add()
    {
        ob_clean();
        $centre_id = session('centre_id');   //获取当前门店ID
        //获取所有的商品类别 供应商
        $suppliers = M('jxc_supplier') -> where(['status'=>1])->where('centre_id='.$centre_id)->select();
        $good_types = M('jxc_goods_type') -> where(['status'=>1])->where('centre_id='.$centre_id)->select();

        $data = ['suppliers'=>$suppliers,'good_types'=>$good_types];

        $this -> ajaxReturn($data);
    }

    //执行添加商品信息 需求参数 type_name 类别名称 消息返回1 错误信息 成功返回2 成功信息
    public function store()
    {
        ob_clean();
        //判断是否非法访问 非法方式返回错误
        if (!IS_POST) {
            $this -> ajaxReturn(['status'=>1,'msg'=>'请求方式不合法'],'JSON');
        }

        //创建验证规则
        $rules = [
            ['good_name','require','商品类别名称不能为空'],
            ['purchase_price','/^(-?\\d+)(\\.\\d+)?$/','采购价格必须为数字'],
            ['real_price','/^(-?\\d+)(\\.\\d+)?$/','销售价格必须为数字'],
        ];

        $Goods = D("jxc_goods"); // 实例化对象
        $post_data = I('post.data');
        if (!$Goods->validate($rules) -> create($post_data)){     // 如果创建失败 表示验证没有通过 输出错误提示信息
            $this -> ajaxReturn(['status'=>1,'msg'=>"验证失败".$Goods->getError()],'JSON');
        }else{     // 验证通过 可以进行其他数据操作
            //获取数据
            $centre_id = session('centre_id');   //获取当前门店ID  测试为1
            $good_num = $this -> getNum();

            $fields['good_num'] = $good_num;
            $fields['good_name'] = $post_data['good_name'];
            $fields['purchase_price'] = $post_data['purchase_price'];
            $fields['real_price'] = $post_data['real_price'];
            $fields['cost_price'] = $post_data['cost_price'];
            $fields['imgpath'] = $post_data['imgpath'];
            $fields['mini_imgpath'] = $post_data['mini_imgpath'];
            $fields['type_id'] = $post_data['type_id'];
            $fields['supplier_id'] = $post_data['supplier_id'];
            $fields['spec'] = $post_data['spec'];
            $fields['model'] = $post_data['model'];
            $fields['weight'] = $post_data['weight'];
            $fields['unit'] = $post_data['unit'];
            $fields['notes'] = $post_data['notes'];
            $fields['centre_id'] = $centre_id;
            $user_id = session("user_id");  //获取当前登陆用户的user_id  总部后台管理系统获取mg_id  会员管理系统获取user_id
            $fields['user_id'] = $user_id;
            $fields['status'] = 1;
            //创建模型对象
            $Goods->create($fields);
            //执行添加
            $res = $Goods->add();

            if($res){
                $this -> ajaxReturn(['status'=>2,'msg'=>'添加成功'],'JSON');
            } else {
                $this -> ajaxReturn(['status'=>1,'msg'=>'添加失败'],'JSON');
            }
        }
    }


    //获取单条商品信息 用于修改页面 查看页面数据展示 参数:商品ID  返回值:data 商品信息数组 suppliers 供应商信息 good_types 商品类别
    public function edit()
    {
        ob_clean();
        $centre_id = session('centre_id');   //获取当前门店ID
        $good_id = I('post.id');    //获取要查询的商品类别的ID
        $Goods = M('jxc_goods');

        $res = $Goods->field('jxc_goods.*,jxc_goods_type.type_name,jxc_supplier.supplier_name')
            ->join('jxc_goods_type on jxc_goods.type_id = jxc_goods_type.id','left')
            ->join('jxc_supplier on jxc_goods.supplier_id = jxc_supplier.id','left')
            -> where("jxc_goods.id=".$good_id)
            -> find();

        //获取所有的商品类别 供应商
        $suppliers = M('jxc_supplier') -> where(['status'=>1])->where('centre_id='.$centre_id)->select();
        $good_types = M('jxc_goods_type') -> where(['status'=>1])->where('centre_id='.$centre_id)->select();


        $data = ['suppliers'=>$suppliers,'good_types'=>$good_types,'data'=>$res];

        $this -> ajaxReturn($data);
    }


    //修改商品信息
    public function update()
    {
        ob_clean();
        //判断是否非法访问 非法方式返回错误
        if (!IS_POST) {
            $this -> ajaxReturn(['status'=>1,'msg'=>'请求方式不合法'],'JSON');
        }
        $post_data = I('post.data');
        $good_id= $post_data['id']; //获取要修改的商品ID

        //创建验证规则
        $rules = [
            ['good_name','require','商品类别名称不能为空'],
            ['purchase_price','/^(-?\\d+)(\\.\\d+)?$/','采购价格必须为数字'],
            ['real_price','/^(-?\\d+)(\\.\\d+)?$/','销售价格必须为数字'],
        ];

        $Goods = M("jxc_goods"); // 实例化对象

        if (!$Goods->validate($rules) -> create($post_data)){     // 如果创建失败 表示验证没有通过  输出错误提示信息
            $this -> ajaxReturn(['status'=>1,'msg'=>'验证失败'].$Goods->getError(),'JSON');
        }else{     // 验证通过 可以进行其他数据操作
            //判断是否修改了图片  如果修改过 删除旧图片
            $good = $Goods -> where('id='.$good_id)->find();
            $imgpath = $post_data['imgpath'];
            $mini_imgpath = $post_data['mini_imgpath'];
            if ($good['imgpath'] != $imgpath || $good['mini_imgpath'] != $mini_imgpath) {
                ShanTu($good['imgpath']);
                ShanTu($good['mini_imgpath']);
            }

            //获取数据
            $fields['good_name'] = $post_data['good_name'];
            $fields['purchase_price'] = $post_data['purchase_price'];
            $fields['real_price'] = $post_data['real_price'];
            $fields['cost_price'] = $post_data['cost_price'];
            $fields['imgpath'] = $post_data['imgpath'];
            $fields['mini_imgpath'] = $post_data['mini_imgpath'];
            $fields['type_id'] = $post_data['type_id'];
            $fields['supplier_id'] = $post_data['supplier_id'];
            $fields['spec'] = $post_data['spec'];
            $fields['model'] = $post_data['model'];
            $fields['weight'] = $post_data['weight'];
            $fields['unit'] = $post_data['unit'];
            $fields['notes'] = $post_data['notes'];

            //执行修改
            $res = $Goods->where('id='.$good_id)->save($fields);

            if(false !== $res){
                //写入LOG
                $content = "修改商品".$fields['good_name']."成功";
                setLog($content);
                $this -> ajaxReturn(['status'=>2,'msg'=>'修改成功'],'JSON');
            } else {
                $this -> ajaxReturn(['status'=>1,'msg'=>'修改失败'],'JSON');
            }
        }
    }

    //删除商品信息  安全删除  状态修改为0 需求参数id 修改的数据ID  消息返回1 错误信息 成功返回2 成功信息
    public function delete()
    {
        ob_clean();
        $good_id = I('post.id');

        $fields['status'] = 0;
        $res = M('jxc_goods')->where("id = '{$good_id}'")->save($fields);

        if($res){
            //写入LOG
            $good_name = M('jxc_goods')->where("id = $good_id")->find()['good_name'];
            $content = "删除商品".$good_name."成功";
            setLog($content);
//        $this->success('删除成功', U('JxcGoodsType/index'), 3);
            $this -> ajaxReturn(['status'=>2,'msg'=>'删除成功'],'JSON');
        } else {
            $this -> ajaxReturn(['status'=>1,'msg'=>'删除失败'],'JSON');
//        $this->success('删除失败', U('JxcGoodsType/index'), 3);
        }
    }
    
    //商品图片上传 上传成功返回大图地址缩略图地址
    public function imgupload()
    {
        ob_clean();

        $upload = new \Think\Upload();// 实例化上传类
        $upload->maxSize   =     3145728 ;// 设置附件上传大小
        $upload->exts      =     array('jpg', 'png', 'jpeg');// 设置附件上传类型
        $upload->savePath  =      './JxcGoodImg/'; // 设置附件上传目录    // 上传文件
        $info   =   $upload->upload();

        $create_time=date("Y-m-d H:i:s");
        $date=date("Y-m-d");
        $savename=$info['img_upload']['savename'];

        $image = new \Think\Image();
        $image->open("./Uploads/JxcGoodImg/$date/$savename");

        // 按照原图的比例生成一个缩略图并保存
        $image->thumb(110, 160)->save("./Uploads/JxcGoodImg/Mini/$savename");

        $big_img = "http://".HTTP_HOST."Uploads/JxcGoodImg/$date/$savename";
        $small_img = "http://".HTTP_HOST."Uploads/JxcGoodImg/Mini/$savename";


        $res = [
            'imgpath'=>$big_img,
            'mini_imgpath'=>$small_img
        ];

        $this -> ajaxReturn($res);

    }

    //生成流水编号
    public function getNum()
    {
        //设置编号开头
        $first = 'SP';
        $centre_id = session('centre_id');  //获取当前中心ID
//        获取当天日期
        $date = date('Ymd');
        $where = [
            'centre_id'=>$centre_id,
            'create_time'=>[
                'gt',$date
            ]
        ];
        //获取当前数据库当天使用的最后一个流水号
        $lastNum = M('jxc_goods')->where($where)->order('id desc')->find()['type_num'];
        //如果存在  截取后四位 并且加1  如果不存在生成当天第一条
        if ($lastNum){
            $last = substr($lastNum,-4);    //获取最后4位
            $a = substr($lastNum,0,-4);     //获取前面N位
            $var=sprintf("%04d", $last+1);
            $num = $a.$var;
            return $num;
        }else{
            $date = substr($date,2);
            $num = $first.$date.$centre_id.'0001';
            return $num;
        }
    }

    //添加商品列表获取数据
    public function goodsList()
    {
        ob_clean();
        $centre_id = session('centre_id');   //获取当前门店ID  测试为1

        //组装where条件
        $where = [
            'jxc_goods.centre_id' => $centre_id,
            'jxc_goods.status' => 1
        ];

        $param = I('post.map');
        //判断是否存在条件查询
        $search = $param['search'];
        $typeid = $param['typeid'];
        $supplierid = $param['supplierid'];
        $page = $param['page'] ? $param['page'] : 1;
        $pageone=$param['pageone'] ? $param['pageone'] : 10;//每页数据
        $type = $param['type'];  //用于判断从哪里点击的 出入库无此条件 盘点 只显示有库存的
        $map = $param;  //条件返回
        if ($search) {
            $where['jxc_goods.good_name']= ['like', "%{$search}%"];
        }
        if ($typeid) {
            $where['jxc_goods.type_id']= $typeid;
        }
        if ($supplierid) {
            $where['jxc_goods.supplier_id']= $supplierid;
        }
        if($type=='pd'){     //如果是盘点 那么只查找当前库存的商品
            //获取当前库存商品所有的good_id
            $good_ids = M('jxc_stock')->field('good_id')->select();
            //遍历商品ID 拼接id条件
            $string = '';
            foreach($good_ids as $k => $v){
                $string .= $v['good_id'].',';
            }
            $string = rtrim($string,',');
            $where['jxc_goods.id']=['IN',"$string"];
        }

        $Goods = M('jxc_goods');      //实例化
        $count = $Goods ->where($where)->count();   //获取数据总数
        $pagetotal=ceil($count/$pageone);   //总页数
        $map['pagetotal'] = $pagetotal; //返回参数 总页数
        $pyl=($page-1)*$pageone;//偏移量


        $Goods = M('jxc_goods');      //实例化
        // 所有商品信息 相应商品类别 供应商
        $res = $Goods->field('jxc_goods.*,jxc_goods_type.type_name,jxc_supplier.supplier_name')
            ->join('jxc_goods_type on jxc_goods.type_id = jxc_goods_type.id','left')
            ->join('jxc_supplier on jxc_goods.supplier_id = jxc_supplier.id','left')
            -> where($where)->order('id desc')->limit($pyl,$pageone) -> select();   //获取结果信息

        //获取当前中心所有采购订单信息 用于重组格式中上次采购价
        $purinfores = M('jxc_order_goods')
            ->join('jxc_order on jxc_order_goods.order_id = jxc_order.id')
            ->where(['jxc_order.centre_id'=>$centre_id,'jxc_order.status'=>1,'jxc_order.order_type'=>1])
            ->select();

        //重组订单信息结构
        $purinfos = [];
        foreach($purinfores as $k => $v){
            $purinfos[$v['good_id']] = $v['price'];
        }
        //获取当前中心的所有商品库存 用于重组格式中可用库存
        $stockres = M('jxc_stock')->where('centre_id='.$centre_id)->select();
        //重组库存信息结构
        $stocks = [];
        foreach($stockres as $k => $v){
            $stocks[$v['good_id']] = $v['number'];
        }
        //重组数组格式 返回需求的json
        $infos = [];
        foreach ($res as $k => $v){
            //组装查询上次
            $infos[$k]['id'] = $v['id'];
            $infos[$k]['good_num'] = $v['good_num'] ? $v['good_num'] : ''; //商品编号
            $infos[$k]['good_name'] = $v['good_name'] ? $v['good_name'] : '';   //商品名称
            $infos[$k]['mini_imgpath'] = $v['mini_imgpath'] ? $v['mini_imgpath'] : ''; //商品图片 缩略图
            $infos[$k]['imgpath'] = $v['imgpath'] ? $v['imgpath'] : '';   //商品图片 大图
            $infos[$k]['spec'] = $v['spec'] ? $v['spec'] : ''; //商品规格
            $infos[$k]['unit'] = $v['unit'] ? $v['unit'] : ''; //商品单位
            $infos[$k]['purchase_price'] = $v['purchase_price'] ? $v['purchase_price'] : ''; //商品采购价
            $infos[$k]['prev_purprice'] = $purinfos[$v['id']] ? $purinfos[$v['id']] : 0;    //上次采购价
            $infos[$k]['stock'] = $stocks[$v['id']] ? $stocks[$v['id']] : 0;    //可用库存
            $infos[$k]['real_price'] = $v['real_price'];
        }


        //获取所有的商品类别 供应商
        $suppliers = M('jxc_supplier') -> where(['status'=>1])->where('centre_id='.$centre_id)->select();
        $good_types = M('jxc_goods_type') -> where(['status'=>1])->where('centre_id='.$centre_id)->select();

        $data = ['map'=>$map,'suppliers'=>$suppliers,'good_types'=>$good_types,'data'=>$infos];

        $this -> ajaxReturn($data);

    }
}