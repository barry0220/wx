<?php
namespace Home\Controller;
use Think\Controller;
class YuangonController extends CommonController {
    public function index(){
      if(isset($_GET['p'])){
         $page=$_GET['p'];
       }else{
         $page=1;
       }
       $centre_id=session("centre_id");

       $num=M("xueyuan_baoming")->where("(role=1 or role=0 or role=5 or role=7) and status=1 and centre_id='$centre_id'")->count();
       $pageone=10;//每页数据
       $pagetotal=ceil($num/$pageone);
       $pyl=($page-1)*$pageone;//偏移量
       $this->page=$page;
       $this->pagetotal=$pagetotal;
       $this->num=$num;
       $sql="SELECT * FROM xueyuan_baoming where (role=1 or role=0 or role=5 or role=7) and status=1 and centre_id='$centre_id' order by user_id desc limit $pyl,$pageone";
       $this->data=M()->query($sql);
       $id=I('get.id');
       if(empty($id)){
        $id=0;
       }
       $this->user_id=$id;
       if(!empty($id)){
        $arr=M('xueyuan_baoming')->where("user_id='$id'")->find();
        $arr['shu']=explode(",", $arr['nav_id']);
        $this->xiu=$arr;
       }
       $this->display();
    }
    //添加员工
    public function add(){
      $data['username']=I('post.username');
      $data['gangwei']=I('post.gangwei');
      $data['sex']=I('post.sex');
      $data['phone']=I('post.phone');
        //验证是否重复添加
        if (match_phone($data['phone']) == false){
            $this->error("手机号为空，或者手机号格式不正确");
        }
        $repeat = M('xueyuan_baoming')->where("phone={$data['phone']}")->find();
        if ($repeat){
            $this->error("禁止重复添加员工");
        }
      $data['centre_id']=session('centre_id');
      $data['role']=0;
      $nav_id=I('post.nav_id');
      $data['nav_id']=implode(",", $nav_id);
      if(M('xueyuan_baoming')->add($data)){
        $this->redirect("index");
      }
    }
    //删除员工
    public function shanchu(){
      $xueyuan_baoming=M("xueyuan_baoming");
      $id=I('post.id');
      $data['status']=0;
      $rel=$xueyuan_baoming->where("user_id=".$id)->save($data);
      if($rel){
        echo 1;
      }
    }
    public function search(){
      $zhi=I('post.zhi');
      $centre_id=session("centre_id");
      $sql="SELECT * FROM `xueyuan_baoming` where (role=1 or role=0 or role=5 or role=7) and centre_id='$centre_id' and (username like '%$zhi%' or phone like '%$zhi%') and gangwei!='中心总监' and status=1";
      $arr=M()->query($sql);
      $this->ajaxReturn($arr,'JSON');
    }
    //二维码生成
    public function erm(){
      ob_end_clean();
      $centre_id=session("centre_id");
      $market=I('get.user_id');
      $p=I('get.p');
      Vendor('phpqrcode.phpqrcode');
        //生成二维码图片
        $object = new \QRcode();
        $url="http://wx.gymbaby.cn/xx/index.html?centre_id=$centre_id&market=$market";//网址或者是文本内容
        $level=3;
        $size=8;
        $filename ="Uploads/Erwm/centre$centre_id"."sc_id$market.png"; //图片输出路径和文件名
        $errorCorrectionLevel =intval($level) ;//容错级别
        $matrixPointSize = intval($size);//生成图片大小
        $object->png($url, $filename, $errorCorrectionLevel, $matrixPointSize, 2);
        $data['erwm']="https://".HTTP_HOST.$filename;
        M('xueyuan_baoming')->where("user_id='$market'")->save($data);
        $this->redirect("index?p=$p");
    }
    //查看二维码
    public function erlist(){
      $user_id=I('get.user_id');
      $this->user_id=$user_id;
      $this->erwm=M('xueyuan_baoming')->where("user_id='$user_id'")->getField("erwm");
      $this->display();
    }
    //二维码下载
    public function xiazai(){
      ob_end_clean();
      $user_id = $_GET['user_id'];
      $erwm=M('xueyuan_baoming')->where("user_id='$user_id'")->field("erwm,username")->find();
      $erm=$erwm['erwm'];
      $username=$erwm['username'];
      header("Content-type: octet/stream");
      header("Content-disposition:attachment;filename=".$username.'.'.'png'.";");
      header("Content-Length:".filesize($erm));
      readfile($erm);
      exit;
    }
    //修改
    public function xiu(){
      $user_id=I('post.uuid');
      $phone=M('xueyuan_baoming')->where("user_id='$user_id'")->getField('phone');
      $data['username']=I('post.username');
      $data['gangwei']=I('post.gangwei');
      $data['phone']=I('post.phone');
      M('xueyuan_user')->where("phone='$phone'")->save($data);
      $da['jz_phone']=I('post.phone');
      $da['jz_name']=I('post.username');
      M('wx_user')->where("jz_phone='$phone'")->save($da);
      $nav_id=I('post.nav_id');
      $data['sex']=I('post.sex');
      $data['nav_id']=implode(",", $nav_id);
      if(M('xueyuan_baoming')->where("user_id='$user_id'")->save($data)){
        $this->redirect("index");
      }else{
        $this->redirect("index");
      }
    }
    //验证手机号唯一
    public function yz(){
      $phone=I('post.phone');
      $id=M('xueyuan_baoming')->where("phone='$phone'")->getField('user_id');
      if(!empty($id)){
        echo 1;
      }
    }
    //员工详情
    public function details(){
      $id=I('get.id');
      $this->data=M('xueyuan_baoming')->where("user_id='$id'")->find();
      $this->img=M('crm_user_certificate')->where("user_id='$id'")->select();
      $this->display();
    }
    public function shangchuan(){
      $upload = new \Think\Upload();        //实例化上传类
      $upload->maxSize   =     3145728 ;    // 设置附件上传大小
      $upload->exts      =     array('jpg', 'gif', 'png', 'jpeg');  // 设置附件上传类型
      $upload->savePath  =      './zhengshu/';                       // 设置附件上传目录
      $info   =   $upload->upload();                           // 上传文件
      $a=date("Y-m-d");                                             //获取并格式化当天日期
      $b=$info['img']['savename'];
      $id=$_POST['user_id'];
      $data['img']="http://".HTTP_HOST."Uploads/zhengshu/$a/$b";
      $data['user_id']=$id;
      // 保存上传的照片根据需要自行组装
      if(M('crm_user_certificate')->add($data)){
        $this->redirect("Yuangon/details?id=$id");  
      }
    }
    public function jianj(){
      $data['content']=I('post.content');
      $user_id=I('post.user_id');
      if(M('xueyuan_baoming')->where("user_id='$user_id'")->save($data)){
        echo 1;
      }
    }
    public function toux(){
      $upload = new \Think\Upload();        //实例化上传类
      $upload->maxSize   =     3145728 ;    // 设置附件上传大小
      $upload->exts      =     array('jpg', 'gif', 'png', 'jpeg');  // 设置附件上传类型
      $upload->savePath  =      './touxiang/';                       // 设置附件上传目录
      $info   =   $upload->upload();                           // 上传文件
      $a=date("Y-m-d");                                             //获取并格式化当天日期
      $b=$info['uploadPicture']['savename'];
      $id=$_POST['user_id'];
      $data['img']="http://".HTTP_HOST."Uploads/touxiang/$a/$b";
      // 保存上传的照片根据需要自行组装
      if(M('xueyuan_baoming')->where("user_id='$id'")->save($data)){
        $this->redirect("Yuangon/details?id=$id");  
      }
    }
    public function shan(){
      $img=I('post.img');
      $user_id=I('post.id');
      if(M('crm_user_certificate')->where("user_id='$user_id' and img='$img'")->delete()){
        echo 1;
      }
    }
    public function geren(){
      $id=session('user_id');
      $this->data=M('xueyuan_baoming')->where("user_id='$id'")->find();
      $this->img=M('crm_user_certificate')->where("user_id='$id'")->select();
      $this->display();
    }
}