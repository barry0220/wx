<?php
namespace Home\Controller;
use Think\Controller;
class QianController extends Controller {
    //客服的用户列表(问答)
    public function lie(){
        header("access-control-allow-origin:*");
//        echo 123;die;
//        $t=I('post.');
        $t['user_id'] = session("user_id");             //获取登录顾问ID
        $t['centre_id'] = session("centre_id");         //获取中心ID

//        $t['user_id'] = 2268;               //获取登录顾问ID
//        $t['centre_id'] = 223;              //获取中心ID
        //查询该顾问是否存在历史聊天记录
        $a=M("crm_msg as a")->join("right join wx_guanxi as b on a.id=b.id")
                            ->field("a.*,b.img,b.jz_name")
                            ->where("a.user_id={$t['user_id']}")
                            ->order("a.read_status,a.m_time desc")->select();
        //查询该顾问的所有用户家长信息
        $jz_name = M('wx_guanxi as a')  ->field("a.id,a.user_id,jz_name,centre_id,img")
                                        ->where("a.gw_id = '{$t['user_id']}' and a.centre_id='{$t['centre_id']}'")
                                        ->select();
        //循环查出所有家长的宝宝名字 多个宝宝名字用"/"隔开
        foreach ($jz_name as $k5 => $v5){
            $baobao_ming = M('wx_user')->where("user_id in({$v5['user_id']})")->select();
            $baobao_ming2 = '';
            foreach ($baobao_ming as $k6=>$v6){
                $baobao_ming2[] = $v6['baobao_name'];
            }
            $baobao_ming2 = implode("/",$baobao_ming2);
            $jz_name[$k5]['bao_name'] = $baobao_ming2;
        }
        //判断该顾问是否有过聊天记录 如果没有 直接返回 该顾问的所有用户家长信息 如果有 查询历史聊天记录里最后一条记录
        if($a){
            //循环把所有聊天记录按用户家长ID分组
            foreach ($a as $k=>$v){
                $w[$v['id']][] = $v;
            }
            //循环取出每个用户家长的最后一条聊天记录  并取出所有有聊天记录的家长ID
            foreach ($w as $k2=>$v2){
                $rr[] = $v2[0];
                $jz_ids[] = $k2;
            }

            foreach ($rr as $k3=>$v3){
                $ming = M('wx_user')->where("user_id in({$v3['bb_id']})")->select();    //查询出该条聊天记录的宝宝信息
                $ming2 = "";
                foreach ($ming as $k4=>$v4){
                    $ming2[] = $v4['baobao_name'];
                }
                $ming2 = implode("/",$ming2);                                           //把该聊天记录的宝宝信息拼入数组
                $rr[$k3]['bao_name'] = $ming2;
                $rr[$k3]['m_time'] = substr($v3['m_time'],11,5);
                //判断消息状态 color=1=未读未回复  2=已读未回复 3=已读已回复
                if($v3['read_status'] == 0){
                    $rr[$k3]['color'] = 1;
                }else{
                    if($v3['hui_status'] == 0){
                        $rr[$k3]['color'] = 2;
                    }else{
                        $rr[$k3]['color'] = 3;
                    }
                }
            }
            foreach ($jz_name as $k7 => $v7){
                if(in_array($v7['id'],$jz_ids)){
                    unset($jz_name[$k7]);
                }
            }
            $www = array_merge($rr,$jz_name);
            $this->ajaxReturn($www,'JSON');
        }else{
            $this->ajaxReturn($jz_name,'JSON');
        }
    }
    //客服端查看(问答)
    public function index3(){
        header("access-control-allow-origin:*");
        //接口参数
        $t=I('post.');                              //id=用户ID
        $t['user_id'] = session("user_id");         //获取登录顾问ID
//        $t['user_id'] = 2268;                       //获取登录顾问ID
        //实例化 信息记录表
        $m = M("crm_msg");

        //查询条件
        $where = "id = {$t['id']}";

        $t = getfanye($m,$where,$t,10);

        $a=$m   ->where($where)
                ->order("m_time desc")
                ->select();

        //判断翻页页数大于总页数 返回 3（停掉）
        if($t['p'] > $t['pages']){
            echo 3;die;
        }

        foreach ($a as $k=>$v){
            if($v['f_ren'] == 1){
                if($v['user_id'] == 1){
                    $touxiang = "https://".HTTP_HOST."Uploads/1000.png";
                }elseif($v['user_id'] == 0){
                    $touxiang = "https://".HTTP_HOST."Uploads/logo.png";
                }else{
                    $tou2 =  M('xueyuan_baoming')->field("img")->find("{$v['user_id']}");
                    $touxiang = $tou2['img'];
                }
            }else{
                $tou2 =  M('wx_guanxi')->field("img")->find("{$v['id']}");
                $touxiang = $tou2['img'];
            }
            $a[$k]['touxiang'] = $touxiang;
        }
        unset($t['url']);

        foreach ($a as $k2=>$v2){
            if($v2['content'] != "首次聊天提示"){
               $rrr[] = $v2;
            }
        }
        $data['fenye'] = $t;
        $data['data'] = $rrr;
        //打开页面查看数据后 把未读数据 状态修改成 已读
        $xxx['read_status'] = 1;
        $a=M("crm_msg")->where("id = {$t['id']} and read_status=0 and f_ren = 2")->save($xxx);

        $this->ajaxReturn($data,'JSON');
    }
    //客服端发送新消息(问答)
    public function addgu(){
        header("access-control-allow-origin:*");
        $t=I('post.');                      //id=用户ID 和 content=发信内容
        $t['user_id'] = session("user_id");             //获取登录顾问ID
//        $t['user_id'] = 2268;                           //获取登录顾问ID
        //添加新的聊天记录
        $da = M('wx_guanxi')->field("user_id,centre_id")->find("{$t['id']}");  //查询该登录人的宝宝ID 和 中心ID
        //判断该登录人是否 绑定 宝宝ID=宝宝ID 1.存在 收信人=查询宝宝的顾问  2.收信人=2；
        if($da['user_id']){
            $xin['bb_id'] = $da['user_id'];                 //判断该登录人存在宝宝ID 写入聊天记录
        }

        $xin['user_id'] = $t['user_id'] ;                   //发信人=系统
        $xin['id'] = $t['id'];                              //收信人=当前登录人
        $xin['content'] = $t['content'];                    //内容=首次聊天提示
        $xin['read_status'] = 0;                            //阅读状态=未读
        $xin['centre_id'] = $da['centre_id'];               //判断该登录人存在宝宝ID 写入聊天记录
        $xin['f_ren'] = 1;                                  //最后发信人 1=顾问 2=用户

        $st = M("crm_msg")->add($xin);
        if($st){
            //打开页面查看数据后 把未回复数据 状态修改成 已回复
            $xxx['hui_status'] = 1;
            $a=M("crm_msg")->where("id = {$t['id']} and hui_status=0 and f_ren = 2")->save($xxx);
            echo 2;
        }else{
            echo 3;
        }
    }


    //潜客列表
    public function index(){
        $centre_id 	=session("centre_id");		//中心ID
        $user_id 	=session("user_id");		//登录人ID
        $t = I('get.');						    //获取查询条件
        //拼接翻页地址
        $t[url][0] ="https://".HTTP_HOST."Qian/index";
        //实例化会员表
        $m = M("wx_user")->order("gj_type,create_time desc");
        //拼接基础查询条件 1.数据为会员管理系统 2.状态正常 3.合约会员 4.中心id过滤 5.过滤顾问
        $where = "status=1 and yon=2 and belong='{$centre_id}' and gw_id ='{$user_id}' ";
        if($t['gj_type']){
            $t[url][0] .="/gj_type/".$t['gj_type'];
        }
        //根据会员状态筛选
        if($t['gj_type'] !="" && $t['gj_type'] != 7){
            $where .= " and gj_type='{$t['gj_type']}'";
        }
        //根据会员姓名电话筛选
        if($t['name']){
            $where .= " and (baobao_name like '%{$t['name']}%' or name2 like '%{$t['name']}%' or name1 like '%{$t['name']}%' or phone1 like '%{$t['name']}%' or phone2 like '%{$t['name']}%' or baobao_name2 like '%{$t['name']}%')";
            $t[url][0] .="/name/".$t['name'];
        }
        //注册时间筛选 开始日期
        if($t['time_s']){
            $where .= " and create_time>='{$t['time_s']}' ";
            $t[url][0] .="/time_s/".$t['time_s'];
        }
        //注册时间筛选 结束日期
        if($t['time_e']){
            $where .= " and '{$t['time_e']}'>=create_time ";
            $t[url][0] .="/time_e/".$t['time_e'];
        }
        if($t['gj_type'] == 7){
            $where .= " and vip = 2 ";
        }else{
            $where .= " and vip = 0 ";
        }

        if($t['yue1']!="" || $t['yue2']!=""){

        }else{
            $t = getfanye($m,$where,$t,20);
        }
        $a=$m   ->where($where)
                ->select();
        $this->assign('ar',$t);					//查询条件回传
//        k($a);die;
        foreach ($a as $k=>$v){
            $he=$k+1;         //拥有学员总数
            //截取创建时间
            $a[$k]['create_time'] = substr($v['create_time'],0,-9);
            //计算宝宝月龄
            $d=time()-strtotime($v['baobao_birthday']);
            $e=$d/2592000;                  //一个月的时间，单位秒
            $a[$k]['yueling'] = round($e);  //月龄取整
            //根据学员ID 查询宝宝跟进记录
            $gjjl =  M('crm_gj')->where("gw_id='{$user_id}' and bao_id='{$v['user_id']}'")->order("create_time")->select();
            foreach ($gjjl as $kk=>$vv){
                $gjjl[$kk]['create_time'] = substr($vv['create_time'],0,-9);    //循环截取创建日期
                $ci = $kk+1;                                                    //跟进次数
                $time2 = $gjjl[$kk]['create_time'];                             //查询最后跟进日期
            }
            $a[$k]['gjjl']['ci']=$ci;                                           //跟进次数拼入数组
            $a[$k]['gjjl']['time1']=$gjjl[0]['create_time'];                    //首次跟进日期拼入数组
            $a[$k]['gjjl']['time2']=$time2;                                     //最近跟进日期拼入数组
            unset($time2);  //释放函数
            unset($ci);     //释放函数
            //判断宝宝大名不存在 使用小名
            if(!$v['baobao_name']){
                $a[$k]['baobao_name'] = $v['baobao_name2'];
            }
            //判断家长姓名，那个存在显示哪个
            if($v['name1']){
                $a[$k]['jzName'] = $v['name1'];
            }elseif($v['name2']){
                $a[$k]['jzName'] = $v['name2'];
            }elseif($v['name3']){
                $a[$k]['jzName'] = $v['name3'];
            }elseif($v['name4']){
                $a[$k]['jzName'] = $v['name4'];
            }elseif($v['name5']){
                $a[$k]['jzName'] = $v['name5'];
            }elseif($v['name6']){
                $a[$k]['jzName'] = $v['name6'];
            }
        }
        //根据月龄开始筛选
        if($t['yue1']!=""){
            foreach ($a as $k=>$v){
                if($v['yueling'] >= $t['yue1']){
                    $a[$k] = $v;
                }else{
                    unset($a[$k]);
                }
            }
        }
        //根据月龄结束筛选
        if($t['yue2']!=""){
            foreach ($a as $k=>$v){
                if($t['yue2'] >= $v['yueling']){
                    $a[$k] = $v;
                }else{
                    unset($a[$k]);
                }
            }
        }

//        k($a);die;
        $this->assign('data',$a);
        $this->assign('he',$he);
        $this->display();
    }
    //会员跟进详情(已准备废弃)
    public function detail(){
        $centre_id 	=session("centre_id");		                //中心ID
        $user_id 	=session("user_id");		                //登录人ID
        $t = I('get.id');                                       //查看某个会员的跟进记录

        $b['biao1'] = "wx_user as a";                           //会员信息表
        $b['biao3'] = "crm_kjilu as c on a.jl_id=c.jl_id";      //合约表
        $b['field'] = "a.*,c.y_keshi,c.e_time";                 //查询会员信息 剩余课时 合约到期日期
        $b['order'] = "a.create_time";                          //根据创建时间排序
        $b['where'][] = "a.status=1 and a.yon=2";               //判断安全删除 数据用途
        $b['where'][] = "a.belong='{$centre_id}'";              //所属中心

        $b['limit'][] = 1;
        //判断是新增跟进记录，查询
        if($t){
            $b['where'][] = "a.user_id=$t";                     //查看某个会员的跟进记录

            $c['biao1'] = "crm_gj as a";                            //会员信息表
            $c['biao2'] = "crm_kecheng as b on a.pk_id=b.pk_id";    //排课记录表
            $c['biao3'] = "crm_ke as c on b.kc_id=c.kc_id";         //课程表
            $c['field'] = "a.*,b.s_time,c.kc_name";                 //查询会员信息 剩余课时 合约到期日期
            $c['order'] = "a.create_time desc";                     //根据创建时间排序
            $c['where'][] = "a.centre_id='{$centre_id}'";           //所属中心
            $c['where'][] = "a.gw_id='{$user_id}'";                 //所属中心
            $c['where'][] = "a.bao_id='{$t}'";                      //所属中心

            $jl = D('HuiUser')->get_all($c);		                //带条件查询会员表
        }else{
            $b['where'][] = "a.gw_id=0 and vip=0 and yon=2";        //无顾问 无合约
        }
        $a = D('HuiUser')->get_all($b);		                    //带条件查询会员表
        if(!$t){
            $www['user_id'] = $a[0]['user_id'];
            $www['gw_id'] = $user_id;
            M('wx_user')->save($www);
//            k($ttt);die;
        }
        if(!$a){
            $this->redirect('index',array("tishi"=>"1"));
        }

        $this->assign('data',$a[0]);
        $this->assign('jl',$jl);
        $ye = I('get.ye');
//        k($ye);die;
        if($ye){
            $heyue = M("crm_kjilu as a")->join("left join xueyuan_baoming as b on a.guwen=b.user_id")
                                        ->join("left join crm_goods as d on a.s_id=d.s_id")
                                        ->field("a.*,b.username,d.s_name,d.k_shu")
                                        ->where("a.centre_id='{$centre_id}' and a.user_id like '%{$t}%'")
                                        ->order("a.create_time desc")
                                        ->select();
            foreach ($heyue as $k=>$v){
                $hy = explode(",",$v['user_id']);
                if(in_array($t,$hy)){
                    $heyueall[] = $v;
                }
            }
            $this->assign('ye',$ye);
            $this->assign('heyue',$heyueall);
//            k($heyueall);die;
        }
        $this->display();
    }
    //潜客跟进详情
    public function detail3(){
        $centre_id 	=session("centre_id");		                //中心ID
        $user_id 	=session("user_id");		                //登录人ID
        $t = I('get.id');                                       //查看某个会员的跟进记录

        $aaa = M('wx_user')->field("*,floor((unix_timestamp(now())-unix_timestamp(baobao_birthday))/2592000) as yue")->find($t);

        $jl = M('crm_gj')->field("*,left(create_time,10) as time")->where("bao_id = {$t} and centre_id = {$centre_id} ")->order("create_time desc")->select();

        foreach ($jl as $k=>$v){
            $keke = "";
            if($v['ty_type'] == 2){
                $keke = M('crm_kecheng as a')->join("crm_ke as c on a.kc_id=c.kc_id")->where("a.pk_id = {$v['pk_id']}")->find();
            }elseif($v['ty_type'] == 3 || $v['ty_type'] == 4){
                $keke = M('crm_activity')->find($v['pk_id']);
            }
            if($keke){
                $jl[$k] = array_merge($jl[$k],$keke);
            }
        }

//        k($jl);
//        k($a);
//        die;
        $ww = I('get.');
        $this->assign('ar',$ww);
        $this->assign('jl',$jl);
        $this->assign('data',$aaa);
        $this->display();
    }

    //添加跟进记录
    public function add3(){
        $centre_id 	=session("centre_id");		//中心ID
        $user_id 	=session("user_id");		//登录人ID
        $t = I('post.');
//        k($t);die;
//        $ppp = M('wx_user')->field('gw_id')->find($t['bao_id']);
//        if($ppp['gw_id']){
//            $this->redirect('index',array("tishi"=>"2"));
//        }

        $t['centre_id'] = $centre_id;
        $t['gw_id'] = $user_id;

        $w = M('crm_gj')->add($t);

        if($w){
            if($t['vip'] == 0){
                if($t['gj'] == 2){
                    $user['vip'] = 2;
                }
            }elseif($t['vip'] == 2){
                if($t['gj'] == 1){
                    $user['vip'] = 0;
                }
            }
            $rrr = "";
            if($t['gj'] == 4){
                $user['status'] = 0;
            }

            if($t['st_time']){
                if($t['ty_type'] == 2){
                    $user['gj_type'] = 2;
                }elseif ($t['ty_type'] == 3){
                    $user['gj_type'] = "已预约活动";
                    $rrr = 1;
                }elseif ($t['ty_type'] == 4){
                    $user['gj_type'] = "已预约测评";
                    $rrr = 2;
                }elseif ($t['ty_type'] == 1){
                    $user['gj_type'] = "已预约到店";
                    $rrr = 2;
                }
            }else{
                $user['gj_type'] = 3;
            }

            $user['user_id'] = $t['bao_id'];
            $user['gw_id'] = $t['gw_id'];
            $aaa =  M('wx_user')->save($user);

            if($aaa && $rrr == 2){
                $ttw = M('crm_activity')->field("hd_id,user_id")->find($t['pk_id']);
                if(!$ttw['user_id']){
                    $ttw['user_id'] = $t['bao_id'];
                }else{
                    $ttw['user_id'] = $ttw['user_id'].",".$t['bao_id'];
                }
                $pp2 = M('crm_activity')->save($ttw);
            }

            $this->redirect($t['opp']);
        }
    }



    //录入潜客信息
    public function luruqiank(){
        if($t = I('post.')){
            $aa=M('region')->where("REGION_ID='{$t['coun']}'")->getField("REGION_NAME");
            $bb=M('region')->where("REGION_ID='{$t['sheng']}'")->getField("REGION_NAME");
            $cc=M('region')->where("REGION_ID='{$t['qu']}'")->getField("REGION_NAME");
            $data['site'] = $aa.' '.$bb.' '.$cc.' '.$t['site'];
            $data['baobao_name'] = $t['baobao_name'];
            $data['baobao_name2'] = $t['baobao_name2'];
            $data['baobao_birthday'] = $t['baobao_birthday'];
            $data['baobao_sex'] = $t['baobao_sex'];
            $data['laiyuan'] = $t['laiyuan'];
            $data['belong'] = session('centre_id');
            $data['gw_id'] = session('user_id');
            $data['yon'] = 2;
//            foreach ($t as $k => $v){
//                for($i=0;$i<7;$i++){
//                    if($k == "guanxi".$i){
//                        $data['name'.$v] = $t['name'.$i];
//                        $data['phone'.$v] = $t['phone'.$i];
//                    }
//                }
//            }
            for($i=0;$i<7;$i++){
                $data['name'.$t['guanxi'][$i]] = $t['name'][$i];
                $data['phone'.$t['guanxi'][$i]] = $t['phone'][$i];
            }
            unset($data['name']);
            unset($data['phone']);
//                        k($data);die;
            M('wx_user')->add($data);
            $this->redirect('Qian/luruqiank');
        }else{
            $this->guo=M("region")->where("PARENT_ID=1")->select();
            $this->display();
        }
    }


    //添加跟进记录
    public function add(){
        $centre_id 	=session("centre_id");		//中心ID
        $user_id 	=session("user_id");		//登录人ID
        $t = I('post.');
//        k($t);die;
        $ppp = M('wx_user')->field('gw_id')->find($t['bao_id']);
//        if($ppp['gw_id']){
//            $this->redirect('index',array("tishi"=>"2"));
//        }
        $t['centre_id'] = $centre_id;
            $t['gw_id'] = $user_id;
            $w = M('crm_gj')->add($t);
            if($w){
                if($t['vip'] == 0){
                    if($t['gj'] == 2){
                        $user['vip'] = 2;
                    }
                }elseif($t['vip'] == 2){
                    if($t['gj'] == 1){
                        $user['vip'] = 0;
                    }
                }

                if($t['st_time']){
                    $user['gj_type'] = 2;
                }else{
                    $user['gj_type'] = 3;
                }

                $user['user_id'] = $t['bao_id'];
                $user['gw_id'] = $t['gw_id'];
                M('wx_user')->save($user);
                if($t['ye']){
                    $this->redirect('index2');
                }else{
                    $this->redirect('index');
                }
            }
    }

    //查询当天体验课程 或 活动 或 测评(ajax)
    public function kecheng(){
        $centre_id 	=session("centre_id");		//中心ID
        $t = I('post.');
        if($t['ty_type'] == 2){
            $tt = date("N",strtotime($t['time']));
            $b['biao1'] = "crm_kecheng as a";
            $b['biao2'] = "crm_ke as b on a.kc_id=b.kc_id";
            $b['biao3'] = "flexo as c on a.xuhao=c.id";
            $b['biao4'] = "xueyuan_baoming as d on a.user_id=d.user_id";
            $b['field'] = "a.*,b.kc_name,b.yueling,b.yueling2,c.content,d.username";
            $b['where'][] =	"a.status=1";
            $b['where'][] = "a.centre_id={$centre_id}";
            $b['where'][] = "a.start_time <='{$t['time']}'";
            $b['where'][] = "a.end_time >='{$t['time']}'";
            $b['where'][] = "a.week='{$tt}'";
            $b['order'] = "a.s_time";

            $w = D('HuiUser')->get_all($b);		//带条件查询排课记录表
        }elseif($t['ty_type'] == 3){
            $w = M('crm_activity')->where("start_time = '{$t['time']}' and tai = 1 and centre_id={$centre_id} and xiaohao=0")->select();
        }elseif($t['ty_type'] == 4){
            $w = M('crm_activity')->where("start_time = '{$t['time']}' and tai = 2 and centre_id={$centre_id} and xiaohao=0")->select();
        }
        $aw['type'] =  $t['ty_type'];
        $aw['data'] =  $w;
        $this->ajaxReturn($aw,'JSON');
    }
    //到访状态修改
    public function dao(){
        $t = I('post.');
        $ttt =M('crm_gj')->save($t);
        if($t['dao'] == 1){
            $w['user_id'] = $t['id'];
            $w['gj_type'] = 4;
        }
        if($t['dao'] == 2){
            $w['user_id'] = $t['id'];
            $w['gj_type'] = 3;
        }
        M('wx_user')->save($w);
        $this->ajaxReturn($ttt,'JSON');
    }


    //已有会员列表
    public function index2(){
        $centre_id 	=session("centre_id");		//中心ID
        $user_id 	=session("user_id");		//登录人ID
        $t = I('get.');                         //获取get传值
        //拼接翻页地址
        $t[url][0] ="https://".HTTP_HOST."Qian/index2";
        //实例化会员表 连 合约表
        $m = M("wx_user as a")  ->join("crm_kjilu as c on a.jl_id=c.jl_id")
                                ->field("a.*,c.y_keshi,c.e_time")
                                ->order("a.create_time desc");
        //拼接基础查询条件 1.数据为会员管理系统 2.状态正常 3.合约会员 4.中心id过滤 5.过滤顾问
        $where = "a.status=1 and a.yon=2 and a.vip=1 and a.belong='{$centre_id}' and a.gw_id = {$user_id}";
        //根据会员姓名电话筛选
        if($t['name']){
            $where .= " and (baobao_name like '%{$t['name']}%' or name2 like '%{$t['name']}%' or name1 like '%{$t['name']}%' or phone1 like '%{$t['name']}%' or phone2 like '%{$t['name']}%' or baobao_name2 like '%{$t['name']}%')";
            $t[url][0] .="/name/".$t['name'];
        }
        //根据会员合约期筛选
        if($t['gj_type'] == 6){
            $nian = date("Y-m-d",strtotime("+1 month"));  //合约还有30天
            $where .= " and c.e_time<'{$nian}'";
            $t[url][0] .="/gj_type/".$t['gj_type'];
        }
        //根据会员剩余课时筛选
        if($t['gj_type'] == 7){
            $where .= " and c.y_keshi<10";
            $t[url][0] .="/gj_type/".$t['gj_type'];
        }
        //注册时间筛选 开始日期
        if($t['time_s']){
            $where .= " and a.create_time>='{$t['time_s']}'";
            $t[url][0] .="/time_s/".$t['time_s'];
        }
        //注册时间筛选 结束日期
        if($t['time_e']){
            $where .= " and '{$t['time_e']}'>=a.create_time";
            $t[url][0] .="/time_e/".$t['time_e'];
        }
        
        if($t['yue1']!="" || $t['yue2']!=""){

        }else{
            $t = getfanye($m,$where,$t,20);
        }
        $a=$m->where($where)
                ->select();
        $this->assign('ar',$t);					//查询条件回传

        foreach ($a as $k=>$v){
            $he=$k+1;                               //拥有学员总数
            //截取创建时间
            $a[$k]['create_time'] = substr($v['create_time'],0,-9);
            //计算宝宝月龄
            $d=time()-strtotime($v['baobao_birthday']);
            $e=$d/2592000;                          //一个月的时间，单位秒
            $a[$k]['yueling'] = round($e);          //月龄取整
            //根据学员ID 查询宝宝跟进记录
            $gjjl =  M('crm_gj')->where("gw_id='{$user_id}' and bao_id='{$v['user_id']}'")->order("create_time")->select();
            foreach ($gjjl as $kk=>$vv){
                $gjjl[$kk]['create_time'] = substr($vv['create_time'],0,-9);    //循环截取创建日期
                $ci = $kk+1;                                                    //跟进次数
                $time2 = $gjjl[$kk]['create_time'];                             //查询最后跟进日期
            }
            $a[$k]['gjjl']['ci']=$ci;                                           //跟进次数拼入数组
            $a[$k]['gjjl']['time1']=$gjjl[0]['create_time'];                    //首次跟进日期拼入数组
            $a[$k]['gjjl']['time2']=$time2;                                     //最近跟进日期拼入数组
            unset($time2);  //释放函数
            unset($ci);     //释放函数
        }
        //根据月龄开始筛选
        if($t['yue1']!=""){
            foreach ($a as $k=>$v){
                if($v['yueling'] >= $t['yue1']){
                    $a[$k] = $v;
                }else{
                    unset($a[$k]);
                }
            }
        }
        //根据月龄结束筛选
        if($t['yue2']!=""){
            foreach ($a as $k=>$v){
                if($t['yue2'] >= $v['yueling']){
                    $a[$k] = $v;
                }else{
                    unset($a[$k]);
                }
            }
        }
        //获取get传值 tishi=是否存在新客户 1=存在 0=没有 接收后原值传入页面
        $this->assign('data',$a);
        $this->assign('he',$he);
        $this->display();
    }

    
    //批量导入潜客
    public function daoru(){
        //判断文件是否上传
        if($_FILES['file']){
            $centre_id = session("centre_id");          //中心ID
            $user_id = session("user_id");              //顾问ID
            $ge = array('xls','xlsx');				    //限制格式
            $info = Tu($centre_id,"../Uploads/Excel/",$ge);     //文件上传
            $url = "./Uploads/Excel/".$centre_id."/".$info['file']['savename']; //拼接文件保存路径
            //EXCel表 列对应的数据表字段（$a）
            $a = array( "baobao_name"   =>  "A",
                        "baobao_name2"  =>  "B",
                        "baobao_sex"    =>  "C",
                        "baobao_birthday"  =>  "D",
                        "name1"     =>  "E",
                        "phone1"    =>  "F",
                        "name2"     =>  "G",
                        "phone2"    =>  "H",
                        "name3"     =>  "I",
                        "phone3"    =>  "J",
                        "name4"     =>  "K",
                        "phone4"    =>  "L",
                        "name5"     =>  "M",
                        "phone5"    =>  "N",
                        "name6"     =>  "O",
                        "phone6"    =>  "P",
                        "site"    =>  "Q",
                        "laiyuan"    =>  "R"
                        );
            //非EXCel表 中的通用值  （$b） $b默认为空 如果没有可以不填写
            $b = array(
                    "belong"=>$centre_id,
                    "gw_id"=>$user_id,
                    "yon"=>2
                );
            importExcel($url,$a,$b);    //调用导入函数
            $this->redirect('index');   //导入完成跳转页面
        }else{
            $this->display();
        }
    }


}