<?php
namespace Home\Controller;
use Think\Controller;
use PHPExcel_IOFactory;
class UserController extends CommonController {
    public function index(){
       if(isset($_GET['p'])){
         $page=$_GET['p'];
       }else{
         $page=1;
       }
       $this->zz=I('get.zz');
       $centre_id=session("centre_id");
       $num=M('wx_user')->where("yon=2 and belong='$centre_id' and status=1")->count();
       $pageone=15;//每页数据
       $pagetotal=ceil($num/$pageone);
       $pyl=($page-1)*$pageone;//偏移量
       $this->page=$page;
       $this->pagetotal=$pagetotal;
       $this->num=$num;
       $sql="SELECT wx_user.baobao_birthday,wx_user.laiyuan,wx_user.user_id,wx_user.baobao_name,wx_user.baobao_name2,wx_user.baobao_sex,crm_kjilu.y_keshi,crm_kjilu.e_time,crm_kjilu.create_time,wx_user.phone2,wx_user.name2 FROM wx_user LEFT JOIN crm_kjilu on wx_user.jl_id=crm_kjilu.jl_id where wx_user.yon=2 and wx_user.belong='$centre_id' and wx_user.status=1 and crm_kjilu.status=1 limit $pyl,$pageone";
       $hh=M()->query($sql);
       $shij=date("Y-m-d");
      foreach ($hh as $key => $value) {
        $d=strtotime($shij)-strtotime($value['baobao_birthday']);
        $e=$d/2592000;//一个月的时间，单位秒
        $f=round($e);//月龄取整
        if($f==576){
          $hh[$key]['yueling']=0;
        }else{
          $hh[$key]['yueling']=$f;
        }
        
      }
      $this->data=$hh;
       $this->guo=M("region")->where("PARENT_ID=1")->select();
       $this->keshi=M("crm_goods")->where("l_id=10 and status=1 and (centre_id=0 or centre_id='$centre_id')")->order("k_shu")->select();
       $this->youhui=M("crm_goods")->where("l_id=11 and status=1 and (centre_id=0 or centre_id='$centre_id')")->select();
       $this->guwen=M("xueyuan_baoming")->where("status=1 and centre_id='$centre_id'")->field("user_id,username")->select();
       $this->display();
    }
    public function hy(){
      $zhi=I('post.zhi');
      $centre_id=session('centre_id');
      $shij=date("Y-m-d");
      $sql="SELECT wx_user.baobao_birthday,wx_user.laiyuan,wx_user.user_id,wx_user.baobao_name,wx_user.baobao_name2,wx_user.baobao_sex,crm_kjilu.y_keshi,crm_kjilu.create_time,crm_kjilu.e_time,wx_user.phone2,wx_user.name2 FROM wx_user LEFT JOIN crm_kjilu on wx_user.jl_id=crm_kjilu.jl_id where wx_user.yon=2 and wx_user.belong='$centre_id' and wx_user.status=1 and wx_user.vip='$zhi'";
       $da=M()->query($sql);
       foreach ($da as $key => $value) {
        $d=strtotime($shij)-strtotime($value['baobao_birthday']);
        $e=$d/2592000;//一个月的时间，单位秒
        $f=round($e);//月龄取整
        if($f==576){
          $da[$key]['yueling']=0;
        }else{
          $da[$key]['yueling']=$f;
        }
      }
      $this->ajaxReturn($da,'JSON');
    }
    //添加会员
    public function add(){
       $coun=I('post.coun');
       $sheng=I('post.sheng');
       $qu=I('post.qu');
       $site=I('post.site');
       $data['baobao_birthday']=I('post.baobao_birthday');
       $data['baobao_name']=I('post.baobao_name');
       $data['baobao_name2']=I('post.baobao_name2');
       $aa=M('region')->where("REGION_ID='$coun'")->getField("REGION_NAME");
       $bb=M('region')->where("REGION_ID='$sheng'")->getField("REGION_NAME");
       $cc=M('region')->where("REGION_ID='$qu'")->getField("REGION_NAME");
       $data['site']=$aa.' '.$bb.' '.$cc.' '.$site;
       $data['baobao_sex']=I('post.sex');
       $data['laiyuan']=I('post.laiyuan');
       $guanxi=I('post.guanxi');
       switch ($guanxi)
          {
          case '1':
            $data['name1']=I('post.name');
            $data['phone1']=I('post.phone');
            break;
          case '2':
            $data['name2']=I('post.name');
            $data['phone2']=I('post.phone');
            break;
          case '3':
            $data['name3']=I('post.name');
            $data['phone3']=I('post.phone');
            break;
          case '4':
            $data['name4']=I('post.name');
            $data['phone4']=I('post.phone');
            break;
          case '5':
            $data['name5']=I('post.name');
            $data['phone5']=I('post.phone');
            break;
          case '6':
            $data['name6']=I('post.name');
            $data['phone6']=I('post.phone');
            break;
            default:
          }
       $guanxi1=I('post.guanxi1');
       if(!empty($guanxi1)){
        switch ($guanxi1)
          {
          case '1':
            $data['name1']=I('post.name1');
            $data['phone1']=I('post.phone1');
            break;
          case '2':
            $data['name2']=I('post.name1');
            $data['phone2']=I('post.phone1');
            break;
          case '3':
            $data['name3']=I('post.name1');
            $data['phone3']=I('post.phone1');
            break;
          case '4':
            $data['name4']=I('post.name1');
            $data['phone4']=I('post.phone1');
            break;
          case '5':
            $data['name5']=I('post.name1');
            $data['phone5']=I('post.phone1');
            break;
          case '6':
            $data['name6']=I('post.name1');
            $data['phone6']=I('post.phone1');
            break;
            default:
          }
       }
       $guanxi2=I('post.guanxi2');
       if(!empty($guanxi2)){
        switch ($guanxi2)
          {
          case '1':
            $data['name1']=I('post.name2');
            $data['phone1']=I('post.phone2');
            break;
          case '2':
            $data['name2']=I('post.name2');
            $data['phone2']=I('post.phone2');
            break;
          case '3':
            $data['name3']=I('post.name2');
            $data['phone3']=I('post.phone2');
            break;
          case '4':
            $data['name4']=I('post.name2');
            $data['phone4']=I('post.phone2');
            break;
          case '5':
            $data['name5']=I('post.name2');
            $data['phone5']=I('post.phone2');
            break;
          case '6':
            $data['name6']=I('post.name2');
            $data['phone6']=I('post.phone2');
            break;
            default:
          }
       }
       $guanxi3=I('post.guanxi3');
       if(!empty($guanxi3)){
         switch ($guanxi3)
          {
          case '1':
            $data['name1']=I('post.name3');
            $data['phone1']=I('post.phone3');
            break;
          case '2':
            $data['name2']=I('post.name3');
            $data['phone2']=I('post.phone3');
            break;
          case '3':
            $data['name3']=I('post.name3');
            $data['phone3']=I('post.phone3');
            break;
          case '4':
            $data['name4']=I('post.name3');
            $data['phone4']=I('post.phone3');
            break;
          case '5':
            $data['name5']=I('post.name3');
            $data['phone5']=I('post.phone3');
            break;
          case '6':
            $data['name6']=I('post.name3');
            $data['phone6']=I('post.phone3');
            break;
            default:
          }
       }
       $guanxi4=I('post.guanxi4');
       if(!empty($guanxi4)){
        switch ($guanxi4)
          {
          case '1':
            $data['name1']=I('post.name4');
            $data['phone1']=I('post.phone4');
            break;
          case '2':
            $data['name2']=I('post.name4');
            $data['phone2']=I('post.phone4');
            break;
          case '3':
            $data['name3']=I('post.name4');
            $data['phone3']=I('post.phone4');
            break;
          case '4':
            $data['name4']=I('post.name4');
            $data['phone4']=I('post.phone4');
            break;
          case '5':
            $data['name5']=I('post.name4');
            $data['phone5']=I('post.phone4');
            break;
          case '6':
            $data['name6']=I('post.name4');
            $data['phone6']=I('post.phone4');
            break;
            default:
          }
       }
       $guanxi5=I('post.guanxi5');
       if(!empty($guanxi5)){
         switch ($guanxi5)
          {
          case '1':
            $data['name1']=I('post.name5');
            $data['phone1']=I('post.phone5');
            break;
          case '2':
            $data['name2']=I('post.name5');
            $data['phone2']=I('post.phone5');
            break;
          case '3':
            $data['name3']=I('post.name5');
            $data['phone3']=I('post.phone5');
            break;
          case '4':
            $data['name4']=I('post.name5');
            $data['phone4']=I('post.phone5');
            break;
          case '5':
            $data['name5']=I('post.name5');
            $data['phone5']=I('post.phone5');
            break;
          case '6':
            $data['name6']=I('post.name5');
            $data['phone6']=I('post.phone5');
          break;
          default:
          }
       }
       $data['yon']=2;
       $data['kahao']=I('post.kahao');
       $centre_id=session("centre_id");
       $data['belong']=$centre_id;
       $hetong=I('post.hetong');
       if(!empty($hetong)){
        $da['hetong']=$hetong;
        $shuju=M("crm_kjilu")->where("hetong='$hetong' and centre_id='$centre_id'")->getField('jl_id');
        if(!empty($shuju)){
           $this->ajaxReturn(2,'JSON');die;
        }
        $da['dindan']=I('post.dindan');
        $da['s_id']=I('post.s_id');
        $you=I('post.you');
        $aaa=M("crm_goods")->where("s_id='$you'")->find();
        $da['youhui_name']=$aaa['s_name'];
        $da['youhui_money']=$aaa['price'];
        $da['e_time']=I('post.end_time');
        $da['create_name']=session("user_id");
        $da['zeng_ke']=I('post.zeng_ke');
        $da['receivable']=I('post.yingshou');
        $da['shishou']=I('post.shishou');
        $da['shoudong_money']=$da['receivable']-$da['shishou'];
        $da['y_keshi']=I('post.y_keshi')+$da['zeng_ke'];
        $da['guwen']=I('post.guwen');
        $da['create_time']=I('post.start_time');
        $da['bz']=I('post.bz');
        $da['centre_id']=session("centre_id");
        $data['vip']=1;//会员等级
        $time=date("Y-m-d H:i:s");
        $jl_id=M('crm_kjilu')->add($da);
        $data['jl_id']=$jl_id;
        $arr=M('wx_centre')->where("centre_id='$centre_id'")->find();
       }
       $user_id=M("wx_user")->add($data);
       if(!empty($user_id)){
        $ddd['user_id']=$user_id;
        M('crm_kjilu')->where("jl_id='$jl_id'")->save($ddd);
        if($arr['dx_qianyue']!=0 and $arr['dx_y']>0 and $hetong!=null){
             if($data['name1']!=null){
               $name=$data['name1'];
             }else if($data['name2']!=null){
               $name=$data['name2'];
             }else if($data['name3']!=null){
               $name=$data['name3'];
             }else if($data['name4']!=null){
               $name=$data['name4'];
             }else if($data['name5']!=null){
               $name=$data['name5'];
             }else if($data['name6']!=null){
               $name=$data['name6'];
             }
             if($data['phone1']!=null){
               $phone=$data['phone1'];
             }else if($data['phone2']!=null){
               $phone=$data['phone2'];
             }else if($data['phone3']!=null){
               $phone=$data['phone3'];
             }else if($data['phone4']!=null){
               $phone=$data['phone4'];
             }else if($data['phone5']!=null){
               $phone=$data['phone5'];
             }else if($data['phone6']!=null){
               $phone=$data['phone6'];
             }
             $k_shu=M('crm_goods')->where("s_id='$da[s_id]'")->getField('k_shu');
             $keshi=$k_shu+$da['zeng_ke'];
             $mb_id=$arr['dx_qianyue'];
             $mb=M('crm_dx_mb')->where("mb_id='$mb_id'")->find();
             $ph=new \Org\dx\Photo;
             $aa=$ph->number($arr['centre'],$jl['baobao_name'],$phone,$mb['alid'],$mb['mb_type'],$name,$da['hetong'],$da['shishou'],$keshi,$time,$da['e_time']);
             $dat['mb_id']=$arr['dx_qianyue'];
             $dat['centre_id']=$centre_id;
             $dat['create_id']=session('user_id');
             $dat['phone']=$phone;
             $dat['user_id']=$user_id;
             $dat['nianyue']=date("Y-m");
             $dat['type']='自动';
             $vv=$aa->result->success[0];
               if($vv==true){
                 $dat['status']=1;
                 M('wx_centre')->where("centre_id='$centre_id'")->setDec('dx_y');
               }else{
                 $dat['status']=0;
               }
               M('crm_dx')->add($dat);
        }
       $this->ajaxReturn(1,'JSON');
      }
    }
    //搜索
    public function search(){
    	$zhi=I('post.zhi');
      $sere=I('post.sere');
      $shij=date("Y-m-d");
      $centre_id=session("centre_id");
      if($sere==2){
        $sql="SELECT * FROM wx_user where yon=2 and belong='$centre_id' and status=1 and (baobao_name like '%$zhi%' or baobao_name2 like '%$zhi%' or name2 like '%$zhi%')";
        $da=M()->query($sql);
        foreach ($da as $key => $val) {
          $d=strtotime($shij)-strtotime($val['baobao_birthday']);
          $e=$d/2592000;//一个月的时间，单位秒
          $f=round($e);//月龄取整
          $da[$key]['yueling']=$f;
        }
      }else if($sere==1){
        $zh=explode("-", $zhi);
        if(count($zh)<2){
          $sql="SELECT wx_user.baobao_birthday,wx_user.laiyuan,wx_user.user_id,wx_user.baobao_name,wx_user.baobao_name2,wx_user.baobao_sex,crm_kjilu.y_keshi,crm_kjilu.create_time,crm_kjilu.e_time,wx_user.phone2,wx_user.name2 FROM wx_user LEFT JOIN crm_kjilu on wx_user.jl_id=crm_kjilu.jl_id where wx_user.yon=2 and wx_user.belong='$centre_id' and wx_user.status=1 and (wx_user.baobao_name like '%$zhi%' or wx_user.baobao_name2 like '%$zhi%' or wx_user.name2 like '%$zhi%' or crm_kjilu.y_keshi='$zhi')";
        }else{
          $sql="SELECT wx_user.baobao_birthday,wx_user.laiyuan,wx_user.user_id,wx_user.baobao_name,wx_user.baobao_name2,wx_user.baobao_sex,crm_kjilu.y_keshi,crm_kjilu.create_time,crm_kjilu.e_time,wx_user.phone2,wx_user.name2 FROM wx_user LEFT JOIN crm_kjilu on wx_user.jl_id=crm_kjilu.jl_id where wx_user.yon=2 and wx_user.belong='$centre_id' and wx_user.status=1";
        }
       $da=M()->query($sql);
       foreach ($da as $key => $value) {
        $d=strtotime($shij)-strtotime($value['baobao_birthday']);
        $e=$d/2592000;//一个月的时间，单位秒
        $f=round($e);//月龄取整
        if($f==576){
          $da[$key]['yueling']=0;
        }else{
          $da[$key]['yueling']=$f;
        }
      }
      foreach ($da as $key => $value) {
        if(count($zh)>1){
        if($da[$key]['yueling']>=$zh[0] and $da[$key]['yueling']<=$zh[1]){
                  $da[$key] = $value;
              }else{
                  unset($da[$key]);
              }
      }
      }
      }else if($sere==3){
        $user_id=I('post.user_id');
        $sql="SELECT crm_user_skjl.create_time,crm_ke.kc_name,crm_kecheng.s_time,crm_kecheng.x_time,crm_user_skjl.status FROM crm_user_skjl INNER JOIN crm_kecheng on crm_user_skjl.pk_id=crm_kecheng.pk_id INNER JOIN crm_ke on crm_kecheng.kc_id=crm_ke.kc_id where crm_user_skjl.user_id='$user_id' and (crm_user_skjl.status=1 or crm_user_skjl.status=2) and (crm_ke.kc_name like '%$zhi%' or crm_user_skjl.create_time='$zhi' or crm_kecheng.s_time='$zhi' or crm_kecheng.x_time='$zhi')";
        $da=M()->query($sql);
      }
        $this->ajaxReturn($da,'JSON');
    }
   //地区联动
    public function sel_coun(){
        $coun=$_POST['coun'];
        $region_info=M('region');
        $region_arr=$region_info->where("PARENT_id=".$coun)->select();
        echo json_encode($region_arr);
  }
  //课时
    public function keshi(){
      $zhi=I('post.zhi');
      $youh=I('post.youh');
      $price=M('crm_goods')->where("s_id='$youh'")->getField("price");
      $arr=M('crm_goods')->where("s_id='$zhi'")->select();
      foreach ($arr as $key => $val) {
        $arr[$key]['yingshou']=$val['price']-$price;
      }
      $this->ajaxReturn($arr[0],'JSON');
    }
  //优惠劵
    public function youhui(){
      $zhi=I('post.zhi');
      $price=I('post.price');
      $str=M('crm_goods')->where("s_id='$zhi'")->getField("price");
      $ss=$price-$str;
      $this->ajaxReturn($ss,'JSON');
    }
    //合约信息
    public function heyue(){
      $user_id=I('post.user_id');
      $jl_id=M('wx_user')->where("user_id='$user_id'")->getField("jl_id");
      $arr=M('crm_kjilu')->where("jl_id='$jl_id'")->find();
      $arrr=explode(' ',$arr['create_time']);
      $start_time=$arrr[0];
      $arr['start_time']=$start_time;
      $this->ajaxReturn($arr,'JSON');
    }
    //添加续约
    public function addyue(){
      $user_id=I('post.user_id');
      $jl=M('wx_user')->where("user_id='$user_id'")->find();
      $jl_id=$jl['jl_id'];
      $y=M('crm_kjilu')->where("jl_id='$jl_id'")->field("y_keshi,user_id")->find();
      $y_keshi=$y['y_keshi'];
      $uuid=$y['user_id'];
      $xuy=explode(",", $uuid);
      $hetong=I('post.hetong');
      $da['hetong']=$hetong;
      $centre_id=session("centre_id");
      $da['centre_id']=$centre_id;
      $shuju=M("crm_kjilu")->where("hetong='$hetong' and centre_id='$centre_id'")->getField('jl_id');
        if(!empty($shuju)){
           $this->ajaxReturn(2,'JSON');die;
        }
      $da['dindan']=I('post.dindan');
      $da['s_id']=I('post.s_id');
      $you=I('post.you');
      $aaa=M("crm_goods")->where("s_id='$you'")->find();
      $da['youhui_name']=$aaa['s_name'];
      $da['create_time']=I('post.start_time');
      $da['youhui_money']=$aaa['price'];
      $da['e_time']=I('post.end_time');
      $da['create_name']=session("user_id");
      $da['zeng_ke']=I('post.zeng_ke');
      $da['receivable']=I('post.yingshou');
      $da['shishou']=I('post.shishou');
      if($uuid==null){
        $da['user_id']=$user_id;
      }else{
        $da['user_id']=$uuid;
      }
      $da['shoudong_money']=$da['receivable']-$da['shishou'];
      $da['y_keshi']=I('post.y_keshi')+$da['zeng_ke']+$y_keshi;//课时包加上赠课加上上份合约剩余课时
      $da['guwen']=I('post.guwen');
      $da['bz']=I('post.bz');
      $id=M('crm_kjilu')->add($da);
      if($jl_id!=null){
        $data['status']=3;
        $data['y_keshi']=0;
        M('crm_kjilu')->where("jl_id='$jl_id'")->save($data);
      }
      $as['jl_id']=$id;
      foreach ($xuy as $key => $value) {
        if($user_id!=$value){
          M('wx_user')->where("user_id='$value'")->save($as);
        }
      }
      $dd['jl_id']=$id;//会员变成新合约数据
      $dd['vip']=1;
      $dd['kahao']=I('post.kahao');
      if(M('wx_user')->where("user_id='$user_id'")->save($dd)){
        $arr=M('wx_centre')->where("centre_id='$centre_id'")->find();
        $arr1=M('crm_kjilu')
        ->join("crm_goods on crm_kjilu.s_id=crm_goods.s_id")
        ->field('crm_kjilu.*,crm_goods.k_shu')
        ->where("crm_kjilu.jl_id='$id'")
        ->find();
        if($arr['dx_qianyue']!=0 and $arr['dx_y']>0){
             if($jl['name1']!=null){
               $name=$jl['name1'];
             }else if($jl['name2']!=null){
               $name=$jl['name2'];
             }else if($jl['name3']!=null){
               $name=$jl['name3'];
             }else if($jl['name4']!=null){
               $name=$jl['name4'];
             }else if($jl['name5']!=null){
               $name=$jl['name5'];
             }else if($jl['name6']!=null){
               $name=$jl['name6'];
             }
             if($jl['phone1']!=null){
               $phone=$jl['phone1'];
             }else if($jl['phone2']!=null){
               $phone=$jl['phone2'];
             }else if($jl['phone3']!=null){
               $phone=$jl['phone3'];
             }else if($jl['phone4']!=null){
               $phone=$jl['phone4'];
             }else if($jl['phone5']!=null){
               $phone=$jl['phone5'];
             }else if($jl['phone6']!=null){
               $phone=$jl['phone6'];
             }
             $keshi=$arr1['k_shu']+$arr1['zeng_ke'];
             $mb_id=$arr['dx_qianyue'];
             $mb=M('crm_dx_mb')->where("mb_id='$mb_id'")->find();
             $ph=new \Org\dx\Photo;
             $aa=$ph->number($arr['centre'],$jl['baobao_name'],$phone,$mb['alid'],$mb['mb_type'],$name,$arr1['hetong'],$arr1['shishou'],$keshi,$arr1['create_time'],$arr1['e_time']);
             $data['mb_id']=$arr['dx_qianyue'];
             $data['centre_id']=$centre_id;
             $data['create_id']=session('user_id');
             $data['phone']=$phone;
             $data['user_id']=$user_id;
             $data['nianyue']=date("Y-m");
             $data['type']='自动';
             $vv=$aa->result->success[0];
               if($vv==true){
                 $data['status']=1;
                 M('wx_centre')->where("centre_id='$centre_id'")->setDec('dx_y');
               }else{
                 $data['status']=0;
               }
               M('crm_dx')->add($data);
        } 
        $this->ajaxReturn(1,'JSON');
      }
      
    }
    //会员详细信息
    public function xianxi(){
      $user_id=I('post.user_id');
      $user=M('wx_user')->where("user_id='$user_id'")->find();
      $jl_id=$user['jl_id'];
      $time=date("Y-m-d");
      $het=M("crm_kjilu")
      ->join("crm_goods on crm_kjilu.s_id=crm_goods.s_id")
      ->where("crm_kjilu.jl_id='$jl_id' and crm_kjilu.e_time>='$time'")
      ->field("crm_goods.k_shu,crm_kjilu.*")
      ->find();
      if($het['e_time']<$time){
        $guoq=M("crm_kjilu")
        ->join("crm_goods on crm_kjilu.s_id=crm_goods.s_id")
        ->where("crm_kjilu.jl_id='$jl_id' and crm_kjilu.e_time<'$time'")
        ->field("crm_goods.k_shu,crm_kjilu.*")
        ->select();
      }else{
        $guoq=M("crm_kjilu")
        ->join("crm_goods on crm_kjilu.s_id=crm_goods.s_id")
        ->where("crm_kjilu.user_id='$user_id'")
        ->field("crm_goods.k_shu,crm_kjilu.*")
        ->select();
      }
      $arr['baobao_name']=$user['baobao_name'];
      $arr['baobao_name2']=$user['baobao_name2'];
      $arr['baobao_birthday']=$user['baobao_birthday'];
      $arr['baobao_sex']=$user['baobao_sex'];
      $arr['name1']=$user['name1'];
      $arr['name2']=$user['name2'];
      $arr['name3']=$user['name3'];
      $arr['name4']=$user['name4'];
      $arr['name5']=$user['name5'];
      $arr['name6']=$user['name6'];
      $arr['phone1']=$user['phone1'];
      $arr['phone2']=$user['phone2'];
      $arr['phone3']=$user['phone3'];
      $arr['phone4']=$user['phone4'];
      $arr['phone5']=$user['phone5'];
      $arr['phone6']=$user['phone6'];
      $arr['site']=$user['site'];
      $arr['hetong5']=$het['hetong'];
      $arr['dindan5']=$het['dindan'];
      $arr['k_shu']=$het['k_shu'];
      $arr['zeng_ke']=$het['zeng_ke'];
      $arr['shishou']=$het['shishou'];
      $arr['bz']=$het['bz'];
      $num=M('crm_user_skjl')->where("user_id='$user_id' and (status=1 or status=2) and source='PC'")->count();
       $pageone=8;//每页数据
       $pagetotal=ceil($num/$pageone);
      $arr['num']=$num;
      $arr['pagetotal']=$pagetotal;
      $arrrr=explode(' ',$het['create_time']);
      $start_time2=$arrrr[0];
      $arr['start_time5']=$start_time2;
      $arr['end_time5']=$het['e_time'];
      $jilu=M('crm_user_skjl')
      ->join("crm_kecheng on crm_user_skjl.pk_id=crm_kecheng.pk_id")
      ->join("crm_ke on crm_kecheng.kc_id=crm_ke.kc_id")
      ->where("crm_user_skjl.user_id='$user_id' and (crm_user_skjl.status=1 or crm_user_skjl.status=2)")
      ->field("crm_user_skjl.create_time,crm_ke.kc_name,crm_kecheng.s_time,crm_kecheng.x_time,crm_user_skjl.status")
      ->limit(8)
      ->select();
      $zhu['jilu']=$jilu;
      $zhu['xxx']=$arr;
      $zhu['guoq']=$guoq;
      $this->ajaxReturn($zhu,'JSON');
    }
    //修改会员信息
    public function xiu(){
      if(empty($_POST)){
        $user_id=I('get.user_id');
        $this->guo=M("region")->where("PARENT_ID=1")->select();
        $this->keshi=M("crm_goods")->where("l_id=10 and status=1 and (centre_id=0 or centre_id='$centre_id')")->select();
        $this->youhui=M("crm_goods")->where("l_id=11 and status=1 and (centre_id=0 or centre_id='$centre_id')")->select();
        $this->guwen=M("xueyuan_baoming")->where("status=1 and centre_id='$centre_id'")->field("user_id,username")->select();
        $user=M('wx_user')->where("user_id='$user_id'")->find();
        $arr=explode(" ", $user['site']);
        $user['sheng']=$arr[0];
        $user['shi']=$arr[1];
        $user['qu']=$arr[2];
        $user['dz']=$arr[3];
        $this->data=$user;
        $this->display();
      }else{
       $centre_id=session("centre_id");
       $username=I('post.username');
       if(!empty($username)){
        $jl_id=M('wx_user')->where("belong='$centre_id' and baobao_name='$username'")->getField("jl_id");
        $data['vip']=1;
        $data['jl_id']=$jl_id;
       }
       $data['baobao_name']=I('post.baobao_name');
       $data['baobao_name2']=I('post.baobao_name2');
       $data['laiyuan']=I('post.laiyuan');
       $data['baobao_sex']=I('post.sex');
       $data['kahao']=I('post.kahao');
       $data['baobao_birthday']=I('post.baobao_birthday');
       $guanxi=I('post.guanxi');
       $name=I('post.name');
       $phone=I('post.phone');
       foreach ($guanxi as $key => $value) {
          switch ($value)
          {
          case '1':
            $data['name1']=$name[$key];
            $data['phone1']=$phone[$key];
            break;
          case '2':
            $data['name2']=$name[$key];
            $data['phone2']=$phone[$key];
            break;
          case '3':
            $data['name3']=$name[$key];
            $data['phone3']=$phone[$key];
            break;
          case '4':
            $data['name4']=$name[$key];
            $data['phone4']=$phone[$key];
            break;
          case '5':
            $data['name5']=$name[$key];
            $data['phone5']=$phone[$key];
            break;
          case '6':
            $data['name6']=$name[$key];
            $data['phone6']=$phone[$key];
            break;
        }
       }
       $user_id=I('post.user_id');
       $us=M('crm_kjilu')->where("jl_id='$jl_id'")->getField("user_id");
       $ddd['user_id']=$us.",".$user_id;
       M('crm_kjilu')->where("jl_id='$jl_id'")->save($ddd);
       if(M('wx_user')->where("user_id='$user_id'")->save($data)){
        $this->redirect('index');
       }
      }
    }
    //会员上课记录分页
    public function fenye(){
      $page=I('post.fy');
      $user_id=I('post.user_id');
      $num=M('crm_user_skjl')->where("user_id='$user_id' and (status=1 or status=2)")->count();
       $pageone=8;//每页数据
       $pagetotal=ceil($num/$pageone);
       if($page=='尾页'){
        $page=$pagetotal;
      }
       $pyl=($page-1)*$pageone;//偏移量
       $sql="SELECT crm_user_skjl.create_time,crm_ke.kc_name,crm_kecheng.s_time,crm_kecheng.x_time,crm_user_skjl.status FROM crm_user_skjl INNER JOIN crm_kecheng on crm_user_skjl.pk_id=crm_kecheng.pk_id INNER JOIN crm_ke on crm_kecheng.kc_id=crm_ke.kc_id where crm_user_skjl.user_id='$user_id' and (crm_user_skjl.status=1 or crm_user_skjl.status=2) limit $pyl,$pageone";
       $hh=M()->query($sql);
       foreach ($hh as $key => $value) {
         $hh[$key]['num']=$num;
         $hh[$key]['page']=$page;
         $hh[$key]['pagetotal']=$pagetotal;
       }
       $this->ajaxReturn($hh,'JSON');
    }
    //手动扣课
    public function kouke(){
    $user_id = I('post.did');
    $xiaohao=I('post.result');
    $w['user_id']=$user_id;
    $w['pk_id'] = 0;
    $w['xiaohao'] = $xiaohao;
    $w['status'] = 2;
    $w['create_time'] = date("Y-m-d",time());
    $w['centre_id'] = session("centre_id");
    $w['create_name'] = session("user_id");
    $w['source'] = "前台";
    $qq = M('crm_user_skjl')->add($w);
    if($qq){
      $jl_id=M('wx_user')->where("user_id='$user_id'")->getField('jl_id');
      M("crm_kjilu")->where("jl_id='$jl_id'")->setDec('y_keshi',$xiaohao);
      $this->redirect("index"); 
    }
  }
  //合约用户检索
    public function user(){
      $zhi=I('post.serch');
      $centre_id=session("centre_id");
      $sql="SELECT baobao_name,user_id FROM wx_user WHERE yon=2 AND status=1 AND jl_id is not NULL and belong='$centre_id' AND baobao_name LIKE '%$zhi%'";
      $arr=M()->query($sql);
      $this->ajaxReturn($arr,'JSON');
    }
    //验证手机号唯一
    public function yz(){
      $phone=I('post.phone');
      $id=M('wx_user')->where("phone1='$phone' or phone2='$phone' or phone3='$phone' or phone4='$phone' or phone5='$phone' or phone6='$phone'")->getField('user_id');
      if(!empty($id)){
        echo 1;
      }
    }
    //会员详细信息
    public function huiyuanlieb(){
      if(isset($_GET['p'])){
         $page=$_GET['p'];
       }else{
         $page=1;
       }
      $xx=I('get.xx');
      if($xx==null){
        $xx=0;
      }
      $this->xx=$xx;
      $zz=I('get.zz');
      if($zz==null){
        $zz=0;
      }
      $this->zz=$zz;
      $user_id=I('get.id');
      $this->user_id=$user_id;
      $user=M('wx_user')->where("user_id='$user_id'")->find();
      $jl_id=$user['jl_id'];
      $centre_id=$user['belong'];
      $time=date("Y-m-d");
      
      $sql="select flexo.content,crm_goods.price,crm_kjilu.guwen,crm_goods.s_id,crm_goods.k_shu,crm_goods.s_name,xueyuan_baoming.username,crm_kjilu.* from crm_kjilu left join crm_goods on crm_kjilu.s_id=crm_goods.s_id left join xueyuan_baoming on crm_kjilu.guwen=xueyuan_baoming.user_id left join flexo on crm_kjilu.type=flexo.xuhao where crm_kjilu.jl_id='$jl_id' and crm_kjilu.status=1 and flexo.yon=17";
      $het=M()->query($sql);
      // if($het[0]['e_time']<$time){
      //   $sql1="select crm_goods.k_shu,crm_goods.s_name,xueyuan_baoming.username,crm_kjilu.* from crm_kjilu left join crm_goods on crm_kjilu.s_id=crm_goods.s_id left join xueyuan_baoming on crm_kjilu.user_id=xueyuan_baoming.user_id where crm_kjilu.jl_id='$jl_id' and crm_kjilu.e_time>='$time'";
      //   $guoq=M()->query($sql1);
      // }else{
        // $guoq=M("crm_kjilu")
        // ->join("crm_goods on crm_kjilu.s_id=crm_goods.s_id")
        // ->join("xueyuan_baoming on crm_kjilu.user_id=xueyuan_baoming.user_id")
        // ->where("crm_kjilu.user_id='$user_id' and crm_kjilu.status=3")
        // ->field("crm_goods.k_shu,crm_goods.s_name,xueyuan_baoming.username,crm_kjilu.*")
        // ->select();

        $sql2="select flexo.content,crm_goods.k_shu,crm_goods.s_name,xueyuan_baoming.username,crm_kjilu.* from crm_kjilu left join crm_goods on crm_kjilu.s_id=crm_goods.s_id left join xueyuan_baoming on crm_kjilu.guwen=xueyuan_baoming.user_id left join flexo on flexo.xuhao=crm_kjilu.type where crm_kjilu.centre_id='$centre_id' and crm_kjilu.status=3 and flexo.yon=17";
        $guo=M()->query($sql2);
        foreach ($guo as $key => $value) {
          $uu=explode(",", $value['user_id']);
          if(in_array($user_id, $uu)){
            $guoq[]=$value;
          }
        }
      // }
      $arr['user_id']=$user_id;
      $arr['baobao_name']=$user['baobao_name'];
      $arr['baobao_name2']=$user['baobao_name2'];
      $arr['baobao_birthday']=$user['baobao_birthday'];
      $arr['baobao_sex']=$user['baobao_sex'];
      $arr['kahao']=$user['kahao'];
      $arr['name1']=$user['name1'];
      $arr['name2']=$user['name2'];
      $arr['name3']=$user['name3'];
      $arr['name4']=$user['name4'];
      $arr['name5']=$user['name5'];
      $arr['name6']=$user['name6'];
      $arr['phone1']=$user['phone1'];
      $arr['phone2']=$user['phone2'];
      $arr['phone3']=$user['phone3'];
      $arr['phone4']=$user['phone4'];
      $arr['phone5']=$user['phone5'];
      $arr['phone6']=$user['phone6'];
      $arr['site']=$user['site'];
      $arr['hetong']=$het[0]['hetong'];
      $arr['dindan']=$het[0]['dindan'];
      $arr['k_shu']=$het[0]['k_shu'];
      $arr['jl_id']=$jl_id;
      $arr['zeng_ke']=$het[0]['zeng_ke'];
      $arr['shishou']=$het[0]['shishou'];
      $arr['s_name']=$het[0]['s_name'];
      $arr['username']=$het[0]['username'];
      $arr['youhui_money']=$het[0]['youhui_money'];
      $arr['create_time']=$het[0]['create_time'];
      $arr['e_time']=$het[0]['e_time'];
      $arr['img']=$user['img'];
      $arr['receivable']=$het[0]['receivable'];
      $arr['price']=$het[0]['price'];
      $arr['bz']=$het[0]['bz'];
      $arr['s_id']=$het[0]['s_id'];
      $arr['uuid']=$het[0]['guwen'];
      $arr['content']=$het[0]['content'];
      $num=M('crm_user_skjl')->where("user_id='$user_id' and (status=1 or status=2) and source='PC'")->count();
       $pageone=2;//每页数据
       $pagetotal=ceil($num/$pageone);
       $pyl=($page-1)*$pageone;//偏移量
       $this->page=$page;
       $this->pagetotal=$pagetotal;
       $this->num=$num;
      $arrrr=explode(' ',$het[0]['create_time']);
      $start_time2=$arrrr[0];
      $arr['start_time5']=$start_time2;
      $arr['end_time5']=$het[0]['e_time'];
      $jilu=M('crm_user_skjl')
      ->join("crm_kecheng on crm_user_skjl.pk_id=crm_kecheng.pk_id")
      ->join("crm_ke on crm_kecheng.kc_id=crm_ke.kc_id")
      ->where("crm_user_skjl.user_id='$user_id' and (crm_user_skjl.status=1 or crm_user_skjl.status=2)")
      ->field("crm_user_skjl.create_time,crm_ke.kc_name,crm_kecheng.s_time,crm_kecheng.x_time,crm_user_skjl.status")
      ->limit($pyl,$pageone)
      ->select();
      $sql5="select crm_goods.k_shu,crm_goods.s_name,xueyuan_baoming.username,crm_kjilu.* from crm_kjilu left join crm_goods on crm_kjilu.s_id=crm_goods.s_id left join xueyuan_baoming on crm_kjilu.guwen=xueyuan_baoming.user_id where crm_kjilu.centre_id='$centre_id'";
        $guo13=M()->query($sql5);
        foreach ($guo13 as $key => $value) {
          $uuq=explode(",", $value['user_id']);
          if(in_array($user_id, $uuq)){
            $guoqx[]=$value;
          }
        }
      $zs=$het[0]['k_shu']+$het[0]['zeng_ke'];
      foreach ($guoq as $key => $value) {
        $zs=$value['k_shu']+$value['zeng_ke']+$zs;
      }
      // $uuu=explode(',', $guoq[0]['user_id']);
      $aax='';
      foreach ($guoqx as $key => $value) {
        $aax=$value['user_id'].','.$aax;
      }
      $aae=$aax.','.$user_id;
      $uuu=explode(',', $aae);
      foreach ($uuu as $k => $val) {
        if($val!=null){
          $sd[]=$val;
        }
      }
      $aaz=array_flip(array_flip($sd));
      $kks=0;
      $wjk=0;
      foreach ($aaz as $key => $value) {
        $kkss=M('crm_user_skjl')->where("user_id='$value' and status=2")->sum('xiaohao');
        $kks=$kks+$kkss;
        $wjks=M('crm_user_skjl')->where("user_id='$value' and status=1")->sum('xiaohao');
        $wjk=$wjk+$wjks;
      }
      $arr['kks']=$kks;
      $arr['wjk']=$wjk;
      $arr['zks']=$zs;
      $arr['syks']=$het[0]['y_keshi'];
      $this->shi=$jilu;
      $this->vo=$arr;
      $this->guoq=$guoq;
      // k($arr);die;
      $this->keshi=M("crm_goods")->where("l_id=10 and status=1 and (centre_id=0 or centre_id='$centre_id')")->order("k_shu")->select();
       $this->youhui=M("crm_goods")->where("l_id=11 and status=1 and (centre_id=0 or centre_id='$centre_id')")->select();
       $this->guwen=M("xueyuan_baoming")->where("status=1 and centre_id='$centre_id'")->field("user_id,username")->select();
      // echo $zs;die;
      // $zhu['jilu']=$jilu;
      // $zhu['xxx']=$arr;
      // $zhu['guoq']=$guoq;
      // $this->ajaxReturn($zhu,'JSON');
      $this->display();
    }
    //头像上传
    public function tonx(){
      $upload = new \Think\Upload();        //实例化上传类
      $upload->maxSize   =     3145728 ;    // 设置附件上传大小
      $upload->exts      =     array('jpg', 'gif', 'png', 'jpeg');  // 设置附件上传类型
      $upload->savePath  =      './touxiang/';                       // 设置附件上传目录
      $info   =   $upload->upload();                           // 上传文件
      $a=date("Y-m-d");                                             //获取并格式化当天日期
      $b=$info['img']['savename'];
      $id=$_POST['uid'];
      $data['img']="/Uploads/touxiang/$a/$b";
      // 保存上传的照片根据需要自行组装
      if(M('wx_user')->where("user_id='$id'")->save($data)){
        $this->redirect("User/huiyuanlieb?id=$id");  
      }
    }
    //会员详情搜索上课记录
    public function sou(){
      $zhi=I('post.zhi');
      $user_id=I('post.user_id');
      $arr=M('crm_user_skjl')
      ->join("crm_kecheng on crm_user_skjl.pk_id=crm_kecheng.pk_id")
      ->join("crm_ke on crm_kecheng.kc_id=crm_ke.kc_id")
      ->where("crm_user_skjl.user_id='$user_id' and (crm_user_skjl.create_time='$zhi' or crm_ke.kc_name='$zhi')")
      ->field("crm_user_skjl.create_time,crm_ke.kc_name,crm_kecheng.s_time,crm_kecheng.x_time,crm_user_skjl.status")
      ->select();
      $this->ajaxReturn($arr,'JSON');
    }
    public function impuser(){
            if($_FILES['ex']){
            $centre_id = session("centre_id");          //中心ID
            $user_id = session("user_id");              //顾问ID
            $ge = array('xls','xlsx');            //限制格式
            $info = Tu($centre_id,"../Uploads/Excel/",$ge);     //文件上传
            $url = "./Uploads/Excel/".$centre_id."/".$info['ex']['savename']; //拼接文件保存路径
            //EXCel表 列对应的数据表字段（$a）
            $a = array( "baobao_name"   =>  "A",
                        "baobao_name2"  =>  "B",
                        "baobao_sex"    =>  "C",
                        "baobao_birthday"  =>  "D",
                        "name1"     =>  "E",
                        "name2"     =>  "F",
                        "name3"     =>  "G",
                        "name4"     =>  "H",
                        "name5"     =>  "I",
                        "name6"     =>  "J",
                        "phone1"    =>  "K",
                        "phone2"    =>  "L",
                        "phone3"    =>  "M",
                        "phone4"    =>  "N",
                        "phone5"    =>  "O",
                        "phone6"    =>  "P",
                        "site"      =>  "Q",
                        "gw_id"     =>   "R",
                        "create_time"=>  "S",
                        "laiyuan"    =>  "T"     
                        );
            //非EXCel表 中的通用值  （$b） $b默认为空 如果没有可以不填写
            $b = array(
                    "belong"=>$centre_id,
                    "yon"=>2
                );
            importExcel($url,$a,$b);    //调用导入函数
            $this->redirect('index');   //导入完成跳转页面
        }else{
            $this->error("导入失败");
        }
  }
    public function xiaz(){
      // $m['cb_url'] = "http://".HTTP_HOST.$m['cb_url ']; //拼接url地址
//    $m['cb_url'] = "D:/bao/baby/File/232/593920b1c5a08.rar";

      $erm="https://".HTTP_HOST.'Public/daoru.xlsx';
      $username='导入潜客模板';
      header("Content-type: octet/stream");
      header("Content-disposition:attachment;filename=".$username.'.'.'xlsx'.";");
      header("Content-Length:".filesize($erm));
      readfile($erm);
      exit;
    }
    public function huiyuanlie(){
      $this->display();
    }
    public function xinzenghui(){
      $zi=I('get.zi');
       if($zi==null){
        $zi=0;
       }
       $this->zi=$zi;
       $uuid=I('get.uuid');
       if($uuid==null){
        $uuid=0;
       }
       $this->uuid=$uuid;
      $this->display();
    }
    public function huiyuanqian(){
      $uuid=I('get.uuid');
       if($uuid==null){
        $uuid=0;
       }
       $this->uuid=$uuid;
       $centre_id=session('centre_id');
       $hytype=M('wx_centre')->where("centre_id='$centre_id'")->getField('hytype');
       $arr=explode(",", $hytype);
       foreach ($arr as $key => $value) {
          $ar[]=M('flexo')->where("yon=17 and xuhao='$value'")->field("xuhao,content")->find();
       }
       $this->leix=$ar;
       // $this->leix=M('flexo')->where("yon=17")->select();
      $this->display();
    }
    //课时
    public function kesh(){
      $zhi=I('post.zhi');
      $arr=M('crm_goods')->where("s_id='$zhi'")->find();
      $this->ajaxReturn($arr,'JSON');
    }
    public function xiuhy(){
      $s_id=I('post.s_id');
      $data['x_s_id']=$s_id;
      $data['x_s_name']=M('crm_goods')->where("s_id='$s_id'")->getField('s_name');
      $data['x_dindan']=I('post.dindan');
      $jl_id=I('post.jl_id');
      $arr=M('crm_kjilu')->where("jl_id='$jl_id'")->find();
      $data['y_dindan']=$arr['dindan'];
      $data['y_s_id']=$arr['s_id'];
      $data['y_s_name']=M('crm_goods')->where("s_id='$arr[s_id]")->getField('s_name');
      $data['y_create_time']=$arr['create_time'];
      $data['y_e_time']=$arr['e_time'];
      $data['y_zeng_ke']=$arr['zeng_ke'];
      $data['y_guwen']=$arr['guwen'];
      $data['y_bz']=$arr['bz'];
      $data['y_price']=$arr['receivable'];
      $data['x_create_time']=I('post.create_time');
      $data['x_e_time']=I('post.e_time');
      $price=I('post.price');
      $data['x_price']=$price;
      $data['x_zeng_ke']=I('post.zeng_ke');
      $data['x_guwen']=I('post.guwen');
      $data['x_bz']=I('post.bz');
      $data['centre_id']=session('centre_id');
      $centre_id=session('centre_id');
      $data['jl_id']=$jl_id;
      $data['x_zs']=I('post.k_shu');
      $data['xiu_user_id']=session('user_id');
      $user_id=I('post.user_id');
      $zhi=M('crm_kjilu_r')->where("jl_id='$jl_id' and x_status=0")->getField('jl_id');
      if($zhi!=null){
        $this->redirect("user/huiyuanlieb?id=$user_id&zz=1");die;
      }
      // $da['yuan_id']=M('crm_kjilu')->add($data);
      // if(M('crm_kjilu')->where("jl_id='$jl_id'")->save($da)){
      //   $this->redirect("user/huiyuanlieb?id=$user_id");
      // }
      if(M('crm_kjilu_r')->add($data)){
        
        $uidd=session('user_id');
        $time=date('Y-m-d H:i:s');
        $username=M('xueyuan_baoming')->where("user_id='$uidd'")->getField('username');
        $template_id='MaW80HxBimaCivcZWqtohS-PkSWxX1CdkAVI0AW0q4Q';
        $open=M('xueyuan_user')->where("centre_id='$centre_id' and role=2")->field('openid')->select();
        foreach ($open as $key => $value) {
          $da['touser']=$value['openid'];
        $da['template_id']=$template_id;
        $da['data']['first']=array("value"=>"尊敬的$value[username]，您好：");
        $da['url']='http://wx.gymbaby.cn/quanxian/index.php?zzz=1';
        $da['data']['keyword1']=array("value"=>"$username","color"=>"#173177");
        $da['data']['keyword2']=array("value"=>"$time","color"=>"#173177");
        $da['data']['remark']=array("value"=>'运动宝贝温馨提示',"color"=>"#173177");
          $a[]=wxts($da);
        }
        $this->redirect("user/huiyuanlieb?id=$user_id");
        // var_dump($a);
      }
    }
}