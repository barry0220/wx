<?php
namespace Home\Controller;
use Think\Controller;
class JxcStockController extends CommonController {

    public function index(){
        ob_clean();
        $centre_id = session('centre_id');   //获取当前门店ID

        //判断是否存在条件查询
        $post_data = I('post.map');
        $search = $post_data['search'];
        $type_id = $post_data['type_id'];
        $page = I('post.page') ? I('post.page') : 1;
        $pageone=I('post.pageone') ? I('post.pageone') : 10;//每页数据
        $map['search'] = $search;  //条件返回
        $map['type_id'] = $type_id;
        $map['page'] = $page;
        $map['pageone'] = $pageone;
        //组装where条件
        $where = [
            'jxc_stock.centre_id' => $centre_id,
            'jxc_stock.number'=>['neq',0]
        ];
        if($search){
            $where['supplier_name'] = [['like', "%{$search}%"]];
        }
        if ($type_id) {
            $where['type_id']=$type_id;
        }

        $Stock = M('jxc_stock')
            ->join('jxc_goods on jxc_stock.good_id = jxc_goods.id');
        $m = clone $Stock;    //复制一个模型

        $count = $Stock ->where($where)->count();   //获取数据总数
        $pagetotal=ceil($count/$pageone);   //总页数
        $map['pagetotal'] = $pagetotal; //返回参数 总页数
        $pyl=($page-1)*$pageone;//偏移量
        $Stock = $m;
        $res = $Stock  -> where($where)->order('jxc_stock.id desc')->limit($pyl,$pageone) -> select();   //获取结果信息

        //获取商品类别信息
        $typeres = M('jxc_goods_type') ->where('centre_id='.$centre_id)->select();
        //重组数据结构
        foreach ($typeres as $k =>$v){
            $types[$v['id']] = $v['type_name'];
        }
        //重组$res 数组结构 添加前台需要的字段数据
        foreach($res as $k => $v){
            $res[$k]['type_name'] = $types[$v['type_id']];  //类别名称
            $res[$k]['stock_sum_price'] = sprintf("%.2f",$v['number'] * $v['purchase_price'] );    //库存金额
        }
        $data = ['map'=>$map,'types'=>$typeres,'data'=>$res];
        $this -> ajaxReturn($data,'JSON');
    }


    //库存报表
    public function orderdetails()
    {
        ob_clean();
        $centre_id = session('centre_id');   //获取当前门店ID
        //组装where条件
        $where = [
            'jxc_goods.centre_id' => $centre_id,
            'jxc_goods.status'=>1,
            'jxc_order.status'=>1,
            'jxc_order_goods.pd_status'=>['neq','3']    //盘点单对应的订单商品表pd_status为3 代表盘点时数量未变化 不计入统计
        ];
        //判断是否存在条件查询
        $prev_date = '';    //用于查询上期结存
        //判断是否存在条件查询
        $post_data = I('post.map');
        $search = $post_data['search'];
        $time_s = $post_data['time_s'];
        $time_e = $post_data['time_e'];
        $type_id = $post_data['type_id'];
        $page = I('post.page') ? I('post.page') : 1;
        $pageone=I('post.pageone') ? I('post.pageone') : 10;//每页数据
        $map['search'] = $search;  //条件返回
        $map['type_id'] = $type_id;
        $map['time_s'] = $time_s;
        $map['time_e'] = $time_e;
        $map['page'] = $page;
        $map['pageone'] = $pageone;
        $string = '';    //条件字符串
        if($search){
            $where['jxc_goods.good_name'] = [['like', "%{$search}%"]];
        }
        if ($type_id) {
            $where['jxc_goods.type_id']=$type_id;
        }
        if ($time_s) { //开始日期条件
            $string .= "and jxc_order.date >='{$time_s}'";
            $prev_date = $time_s;
        }
        if ($time_e) { //结束日期条件
            $string .= "and jxc_order.date<='{$time_e}'";
        }


        //判断是否存在查询条件
        if($string){
            $where['_string'] = substr($string,4);
        }
        $Order = M('jxc_order') //实例化对象
            ->join('jxc_order_goods on jxc_order.id = jxc_order_goods.order_id','right')
            ->join('jxc_goods on jxc_order_goods.good_id = jxc_goods.id','left');
        $m = clone $Order;

        $count = $Order ->where($where)->count();   //获取数据总数
        $pagetotal=ceil($count/$pageone);   //总页数
        $map['pagetotal'] = $pagetotal; //返回参数 总页数
        $pyl=($page-1)*$pageone;//偏移量

        $Order = $m;
        $orders = $Order  -> where($where)->order('jxc_order.id desc')->limit($pyl,$pageone) -> select();   //获取结果信息

        //获取当前库存信息
        $stockres = M('jxc_stock')->where('centre_id='.$centre_id)->select();
        //重组结构 库存的商品ID为键 数量为值
        foreach($stockres as $k => $v){
            $stocks[$v['good_id']] = $v['number'];
        }
        //获取商品类别信息
        $typeres = M('jxc_goods_type') ->where('centre_id='.$centre_id)->select();
        //重组数据结构
        foreach ($typeres as $k =>$v){
            $types[$v['id']] = $v['type_name'];
        }
        //查询上期结存
        $prev_orders = $Order->join('jxc_order_goods on jxc_order_goods.order_id = jxc_order.id','left')
            ->where(['jxc_order.centre_id'=>$centre_id,'jxc_order.status'=>1,'jxc_order_goods,pd_status'=>['neq','3'],'_string'=>"jxc_order.date <'$prev_date'"])
            ->select();
        //循环数据 根据当前选择的开始时间 判断出上月结存 商品ID为键
        $prev = [];
        foreach($prev_orders as $k => $v){
            //判断当前商品是否已经存在
            if (array_key_exists($v['good_id'],$prev)){
                //判断当前订单为出库还是入库
                if($v['order_type']==1) {   //入库
                    $prev[$v['good_id']] = $prev[$v['good_id']]+$v['number'];
                }else{
                    $prev[$v['good_id']] = $prev[$v['good_id']]-$v['number'];
                }
            }else{
                $prev[$v['good_id']] = $v['number'];
            }
        }
        //循环数据 判断出每个商品的出库数量 入库数量 重组数据结构 商品ID为键
        $infos = [];
        foreach($orders as $k => $v){
            //判断当前商品是否存在数组中 如果存在 数量相加 不存在添加商品
            if (array_key_exists($v['good_id'],$infos)) {
                //判断当前记录是入库还是出库 入库增加入库数量字段 出库增加出库数量字段
                if ($v['order_type'] == 1) {    //状态为入库
                    $infos[$v['good_id']]['enter_number'] =  $infos[$v['good_id']]['enter_number']+$v['number'];   //本月入库
                }else if($v['order_type'] == 3){ //状态为盘点
                    //根据订单商品表判断是出库还是入库
                    if($v['pd_status'] == 1){   //盘点出库
                        $infos[$v['good_id']]['out_number'] = $infos[$v['good_id']]['out_number']+$v['number']; //本月出库
                    }else if($v['pd_status'] == 2){ //盘点入库
                        $infos[$v['good_id']]['enter_number'] =  $infos[$v['good_id']]['enter_number']+$v['number'];   //本月入库
                    }
                }else { //状态为出库
                    $infos[$v['good_id']]['out_number'] = $infos[$v['good_id']]['out_number']+$v['number']; //本月出库
                }
            }else{
                $infos[$v['good_id']] = [
                    'good_num'=> $v['good_num'],
                    'good_name'=>$v['good_name'],
                    'mini_imgpath'=>$v['mini_imgpath'],
                    'imgpath'=>$v['imgpath'],
                    'type_name'=>$types[$v['type_id']],
                    'spec'=>$v['spec'],
                    'unit'=>$v['unit'],
                    'prev_stock'=>$prev[$v['good_id']] ? $prev[$v['good_id']] : '0' //上期结存
                ];
                //判断当前记录是入库还是出库 入库增加入库数量字段 出库增加出库数量字段
                if ($v['order_type'] == 1) {    //状态为入库
                    $infos[$v['good_id']]['enter_number'] =  $v['number'];   //本月入库
                    $infos[$v['good_id']]['out_number'] = 0;
                }else { //状态为出库
                    $infos[$v['good_id']]['enter_number'] = 0 ;   //本月入库
                    $infos[$v['good_id']]['out_number'] = $v['number'];
                }
            }
        }
        //添加当前库存字段
        foreach($infos as $k => $v){
            $infos[$k]['stock'] = $v['prev_stock']+$v['enter_number']-$v['out_number'];
        }

        $data = ['map'=>$map,'types'=>$typeres,'data'=>$infos];

        $this -> ajaxReturn($data,'JSON');

    }
    //出入库明细
    public function stockdetails()
    {
        ob_clean();
        $centre_id= session('centre_id');
        //组装where条件
        $where = [
            'jxc_order.centre_id' => $centre_id,
            'jxc_order.status'=>1,
            'jxc_order_goods.pd_status'=>['neq','3']    //盘点单对应的订单商品表pd_status为3 代表盘点时数量未变化 不计入统计
        ];

        //判断是否存在条件查询
        $post_data = I('post.map');
        $search = $post_data['search'];
        $time_s = $post_data['time_s'];
        $time_e = $post_data['time_e'];
        $type_id = $post_data['type_id'];
        $order_type = $post_data['order_type'];
        $page = I('post.page') ? I('post.page') : 1;
        $pageone=I('post.pageone') ? I('post.pageone') : 10;//每页数据
        $map['search'] = $search;  //条件返回
        $map['type_id'] = $type_id;
        $map['time_s'] = $time_s;
        $map['time_e'] = $time_e;
        $map['order_type'] = $order_type;
        $map['page'] = $page;
        $map['pageone'] = $pageone;
        $string = '';    //条件字符串
        if($search){
            $where['jxc_goods.good_name'] = [['like', "%{$search}%"]];
        }
        if ($type_id) {
            $where['jxc_goods.type_id']=$type_id;
        }
        if ($time_s) { //开始日期条件
            $string .= "and jxc_order.date >='{$time_s}'";
            $prev_date = $time_s;
        }
        if ($time_e) { //结束日期条件
            $string .= "and jxc_order.date<='{$time_e}'";
        }
        if ($order_type) { //出入库类别
            if ($order_type == 2) {    //出库
                $where['_query'] = 'order_type=0&pd_status=1&_logic=or';
            }else{  //入库
                $where['_query'] = 'order_type=1&pd_status=2&_logic=or';
            }

        }

        //判断是否存在查询条件
        if($string){
            $where['_string'] = substr($string,4);
        }

        $Order = M('jxc_order') //实例化对象
        ->join('jxc_order_goods on jxc_order.id = jxc_order_goods.order_id','right')
            ->join('jxc_goods on jxc_order_goods.good_id = jxc_goods.id','left');
        $m = clone $Order;

        $count = $Order ->where($where)->count();   //获取数据总数
        $pagetotal=ceil($count/$pageone);   //总页数
        $map['pagetotal'] = $pagetotal; //返回参数 总页数
        $pyl=($page-1)*$pageone;//偏移量

        $Order = $m;
        $orders = $Order  -> where($where)->order('date desc')->limit($pyl,$pageone) -> select();   //获取结果信息


        //获取商品类别信息
        $typeres = M('jxc_goods_type') ->where('centre_id='.$centre_id)->select();
        //重组数据结构
        foreach ($typeres as $k =>$v){
            $types[$v['id']] = $v['type_name'];
        }
        //获取所有的入库类别 出入库类别表
//        $storageres = M('jxc_out_storage')->where(['is_use'=>2,'status'=>1,'centre_id'=>$centre_id])->select();
        $storageres = M('jxc_out_storage')->where(['centre_id'=>$centre_id])->select();
        //遍历类别信息 重组结构 类别ID为键
        $storages = [];
        foreach($storageres as $k => $v){
            $storages[$v['id']] = $v['name'];
        }

        //重组返回数组 数据结构
        $infos = [];
        foreach ($orders as $k => $v){
            $infos[$k]['order_num'] = $v['order_num'];  //订单编号
            $infos[$k]['good_num'] = $v['good_num'];    //商品编号
            $infos[$k]['good_name'] = $v['good_name'];  //商品名称
            $infos[$k]['mini_imgpath'] = $v['mini_imgpath'];    //缩略图地址
            $infos[$k]['imgpath'] = $v['imgpath'];  //大图地址
            $infos[$k]['type_name'] = $types[$v['type_id']];    //类别名称
            $infos[$k]['spec'] = $v['spec'];    //商品规格
            $infos[$k]['unit'] = $v['unit'];    //商品单位
            $infos[$k]['price'] = $v['price'];  //价格
            if($v['order_type'] == 3){  //如果订单为盘点单
                $infos[$k]['storage_name'] = $storages[$v['pd_status']];    //业务类别
                if($v['pd_status']== 2){   //判断盘点的商品是不是入库 ==2
                    $infos[$k]['enter_number'] = $v['number'];  //入库数量
                    $infos[$k]['out_number'] = 0;   //出库数量
                    $infos[$k]['enter_price'] = sprintf("%.2f",$v['number']*$v['price']);   //入库金额
                    $infos[$k]['out_price'] = 0;
                }else{  //盘点的商品是不是出库 ==1
                    $infos[$k]['enter_number'] = 0;  //入库数量
                    $infos[$k]['out_number'] = $v['number'];   //出库数量
                    $infos[$k]['enter_price'] = 0;   //入库金额
                    $infos[$k]['out_price'] = sprintf("%.2f",$v['number']*$v['price']);
                }
            }else{  //正常出入库单
                $infos[$k]['storage_name'] = $storages[$v['order_status']]; //业务类别
                if($v['order_type']== 1){   //判断订单是不是入库 ==1
                    $infos[$k]['enter_number'] = $v['number'];  //入库数量
                    $infos[$k]['out_number'] = 0;   //出库数量
                    $infos[$k]['enter_price'] = sprintf("%.2f",$v['number']*$v['price']);   //入库金额
                    $infos[$k]['out_price'] = 0;
                }else{  //订单是不是出库 ==0
                    $infos[$k]['enter_number'] = 0;  //入库数量
                    $infos[$k]['out_number'] = $v['number'];   //出库数量
                    $infos[$k]['enter_price'] = 0;   //入库金额
                    $infos[$k]['out_price'] = sprintf("%.2f",$v['number']*$v['price']);
                }
            }

        }

        $data = ['map'=>$map,'types'=>$typeres,'data'=>$infos];

        $this -> ajaxReturn($data,'JSON');
    }


    public function exportdetails(){

        $centre_id= session('centre_id');
        //组装where条件
        $where = [
            'jxc_order.centre_id' => $centre_id,
            'jxc_order.status'=>1,
            'jxc_order_goods.pd_status'=>['neq','3']    //盘点单对应的订单商品表pd_status为3 代表盘点时数量未变化 不计入统计
        ];

        $Order = M('jxc_order') //实例化对象
        ->join('jxc_order_goods on jxc_order.id = jxc_order_goods.order_id','right')
            ->join('jxc_goods on jxc_order_goods.good_id = jxc_goods.id','left');

        //获取符合条件的所有信息
        $orders = $Order-> where($where)->order('date desc')->select();

        //获取商品类别信息
        $typeres = M('jxc_goods_type') ->where('centre_id='.$centre_id)->select();
        //重组数据结构
        foreach ($typeres as $k =>$v){
            $types[$v['id']] = $v['type_name'];
        }
        //获取所有的入库类别 出入库类别表
        $storageres = M('jxc_out_storage')->where(['centre_id'=>$centre_id])->select();
        //遍历类别信息 重组结构 类别ID为键
        $storages = [];
        foreach($storageres as $k => $v){
            $storages[$v['id']] = $v['name'];
        }

//        重组结构
        foreach($orders as $k => $v){
            $orders[$k]['date'] = date('Y-m-d',strtotime($v['date']));  //格式化日期
            $orders[$k]['good_type'] = $types[$v['type_id']];   //写入商品类别
            if($v['order_type'] == 3){      //如果订单类型为盘点
                $orders[$k]['storage_type'] = $storages[$v['pd_status']];   //写入业务类别
                $orders[$k]['enter_num'] = $v['pd_status'] == 2 ? $v['number'] : 0; //入库数量
                $orders[$k]['out_num'] = $v['pd_status'] == 1 ? $v['number'] : 0;   //出库数量
                $orders[$k]['enter_sprice'] = $v['pd_status'] == 2 ? sprintf("%.2f",$v['number']*$v['price']) : 0;  //入库金额
                $orders[$k]['out_sprice'] = $v['pd_status'] == 1 ? sprintf("%.2f",$v['number']*$v['price']) : 0;    //出库金额
            }else{
                $orders[$k]['storage_type'] = $storages[$v['order_status']];    //业务类别
                $orders[$k]['enter_num'] = $v['order_type'] == 1 ? $v['number']: 0; //入库数量
                $orders[$k]['out_num'] = $v['order_type'] == 0 ? $v['number']: 0;   //出库数量
                $orders[$k]['enter_sprice'] = $v['order_type'] == 1 ? sprintf("%.2f",$v['number']*$v['price']): 0;  //入库金额
                $orders[$k]['out_sprice'] = $v['order_type'] == 0 ? sprintf("%.2f",$v['number']*$v['price']): 0;    //出库金额
            }
        }
        $xlsData =$orders;
        $date = date("Y年m月d", time());
        $xlsName = "出入库明细列表" . $date;
        $xlsCell = array(
            array('date', '出入库日期'),
            array('order_num', '单据编号'),
            array('good_num', '商品编号'),
            array('good_name', '商品名称'),
            array('good_type', '商品类别'),
            array('spec', '商品规格'),
            array('unit', '单位'),
            array('storage_type', '业务类别'),
            array('price', '价格'),
            array('enter_num', '入库数量'),
            array('out_num', '出库数量'),
            array('enter_sprice', '入库金额'),
            array('out_sprice', '出库金额'),
        );
        //导出Excel $expTitle,$expCellName=字段对应,$expTableData=数据,$aname=文件名
//        R("Login/exportExcel", array($xlsName, $xlsCell, $xlsData, $xlsName));
        $this -> exportExcel($xlsName, $xlsCell, $xlsData, $xlsName);
    }

    public function exportExcel($expTitle,$expCellName,$expTableData,$aname){
        $xlsTitle = iconv('utf-8', 'gb2312', $expTitle); //文件名称
        $fileName = $aname;//or $xlsTitle 文件名称可根据自己情况设定
        $cellNum = count($expCellName);
        $dataNum = count($expTableData);
        vendor("PHPExcel.PHPExcel");
        $objPHPExcel = new \PHPExcel();
        $cellName = array('A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','AA','AB','AC','AD','AE','AF','AG','AH','AI','AJ','AK','AL','AM','AN','AO','AP','AQ','AR','AS','AT','AU','AV','AW','AX','AY','AZ');

        $objPHPExcel->getActiveSheet(0)->mergeCells('A1:'.$cellName[$cellNum-1].'1');//合并单元格
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A1', $expTitle.'        导出时间:'.date('Y-m-d H:i:s'));
        for($i=0;$i<$cellNum;$i++){
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue($cellName[$i].'2', $expCellName[$i][1]);
        }
        // Miscellaneous glyphs, UTF-8
        for($i=0;$i<$dataNum;$i++){
            for($j=0;$j<$cellNum;$j++){
                $objPHPExcel->getActiveSheet(0)->setCellValue($cellName[$j].($i+3), $expTableData[$i][$expCellName[$j][0]]);
            }
        }
        ob_end_clean();
        header('pragma:public');

        header('Content-type:application/vnd.ms-excel;charset=utf-8;name="'.$xlsTitle.'.xls"');
        header("Content-Disposition:attachment;filename=$fileName.xls");//attachment新窗口打印inline本窗口打印
        $objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
        $tt = $objWriter->save('php://output');
        return $tt;
    }

}