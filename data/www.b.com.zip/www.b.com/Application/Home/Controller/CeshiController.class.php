<?php
namespace Home\Controller;
use Think\Controller;
class CeshiController extends Controller {
    //合约列表
    public function index(){
    	$ph=new \Org\dx\Photo;
        $mb_id=7;
        $mb=M('crm_dx_mb')->where("mb_id='$mb_id'")->find();
        $aa=$ph->number('测试中心','天天',13021066273,$mb['alid'],$mb['mb_type'],$time,'恭喜',112321);
        // $aa=$ph->number('测试中心','天天',13021066273,'SMS_71835100','生日提醒');
        // $aa=$ph->number('测试中心','天天',13021066273,'SMS_77025027 ','签约短信','尹天柱',123214,2314,40,'2018-12-09','2018-12-09');
        // $aa=$ph->number('测试中心','天天',13021066273,'SMS_71970289','签约短信','尹天柱','123214','2314','40','2018-12-09','2018-12-09');
        // $aa=$ph->number('测试中心','天天',13021066273,'SMS_72200061','上课短信通知','2018-12-09','尹天柱','外教课',1,12);
        // $aa=$ph->number('测试中心','天天',13021066273,'SMS_71955241','合约到期提醒',2,'2018-12-09');
        var_dump($aa);
    }
}