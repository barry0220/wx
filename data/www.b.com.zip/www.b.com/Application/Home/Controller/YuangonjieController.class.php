<?php
namespace Home\Controller;
use Think\Controller;
class YuangonjieController extends Controller {
	//在职员工列表接口
    public function yuan(){
      header("access-control-allow-origin:*"); 
    	$uid=I('post.uid');
    	if(isset($_POST['page'])){
         $page=$_POST['page'];
       }else{
         $page=1;
       }
    	$centre_id=M('xueyuan_baoming')->where("user_id='$uid'")->getField('centre_id');
    	$num=M("xueyuan_baoming")->where("(role=1 or role=0 or role=5 or role=7) and status=1 and centre_id='$centre_id'")->count();
       $pageone=10;//每页数据
       $pagetotal=ceil($num/$pageone);
       $pyl=($page-1)*$pageone;//偏移量
       $sql="SELECT * FROM xueyuan_baoming where (role=1 or role=0 or role=5 or role=7) and status=1 and centre_id='$centre_id' order by user_id desc limit $pyl,$pageone";
       $arr=M()->query($sql);
       foreach ($arr as $key => $value) {
       	 $arr[$key]['page']=$page;
       	 $arr[$key]['pagetotal']=$pagetotal;
       	 $arr[$key]['num']=$num;
       }
       $this->ajaxReturn($arr,'JSON');
    }
    //离职员工列表
    public function yuanl(){
      header("access-control-allow-origin:*"); 
    	$uid=I('post.uid');
    	if(isset($_POST['page'])){
         $page=$_POST['page'];
       }else{
         $page=1;
       }
    	$centre_id=M('xueyuan_baoming')->where("user_id='$uid'")->getField('centre_id');
    	$num=M("xueyuan_baoming")->where("(role=1 or role=0 or role=5 or role=7) and status=0 and centre_id='$centre_id'")->count();
       $pageone=10;//每页数据
       $pagetotal=ceil($num/$pageone);
       $pyl=($page-1)*$pageone;//偏移量
       $sql="SELECT * FROM xueyuan_baoming where (role=1 or role=0 or role=5 or role=7) and status=0 and centre_id='$centre_id' order by user_id desc limit $pyl,$pageone";
       $arr=M()->query($sql);
       foreach ($arr as $key => $value) {
       	 $arr[$key]['page']=$page;
       	 $arr[$key]['pagetotal']=$pagetotal;
       	 $arr[$key]['num']=$num;
       }
       $this->ajaxReturn($arr,'JSON');
    }
    //添加员工
    public function add(){
      header("access-control-allow-origin:*"); 
      $data['username']=I('post.username');
      $data['gangwei']=I('post.gangwei');
      $data['sex']=I('post.sex');
      $data['phone']=I('post.phone');
      $uid=I('post.uid');
      $centre_id=M('xueyuan_baoming')->where("user_id='$uid'")->getField('centre_id');
      $data['centre_id']=$centre_id;
      $data['role']=0;
      $nav_id=I('post.nav_id');
      $data['nav_id']=implode(",", $nav_id);
      if(M('xueyuan_baoming')->add($data)){
        $this->ajaxReturn(1,'JSON');
      }
    }
    //修改员工
    public function xiu(){
      header("access-control-allow-origin:*"); 
    	$id=I('post.id');
    	$arr=M('xueyuan_baoming')->where("user_id='$id'")->find();
        $arr['shu']=explode(",", $arr['nav_id']);
        $this->ajaxReturn($arr,'JSON');
    }
    //修改员工提交
    public function xiug(){
      header("access-control-allow-origin:*"); 
      $user_id=I('post.uuid');
      $phone=M('xueyuan_baoming')->where("user_id='$user_id'")->getField('phone');
      $data['username']=I('post.username');
      $data['gangwei']=I('post.gangwei');
      $data['phone']=I('post.phone');
      M('xueyuan_user')->where("phone='$phone'")->save($data);
      $da['jz_phone']=I('post.phone');
      $da['jz_name']=I('post.username');
      M('wx_user')->where("jz_phone='$phone'")->save($da);
      $nav_id=I('post.nav_id');
      $data['sex']=I('post.sex');
      $data['nav_id']=implode(",", $nav_id);
      if(M('xueyuan_baoming')->where("user_id='$user_id'")->save($data)){
        $this->redirect("index");
      }
    }
     //删除员工
    public function shanchu(){
      header("access-control-allow-origin:*"); 
      $xueyuan_baoming=M("xueyuan_baoming");
      $id=I('post.id');
      $data['status']=0;
      $rel=$xueyuan_baoming->where("user_id=".$id)->save($data);
      if($rel){
        echo 1;
      }
    }
    //员工模糊查询
    public function search(){
      header("access-control-allow-origin:*");
      $zhi=I('post.zhi');
      $uid=I('post.uid');
      $centre_id=M('xueyuan_baoming')->where("user_id='$uid'")->getField('centre_id');
      $sql="SELECT * FROM `xueyuan_baoming` where (role=1 or role=0 or role=5 or role=7) and centre_id='$centre_id' and (username like '%$zhi%' or phone like '%$zhi%') and gangwei!='中心总监' and status=1";
      $arr=M()->query($sql);
      $this->ajaxReturn($arr,'JSON');
    }
     //二维码生成
    public function erm(){
      header("access-control-allow-origin:*"); 
      $uid=I('post.uid');
      $centre_id=M('xueyuan_baoming')->where("user_id='$uid'")->getField('centre_id');
      $market=I('post.user_id');
      $p=I('get.p');
      Vendor('phpqrcode.phpqrcode');
        //生成二维码图片
        $object = new \QRcode();
        $url="http://wx.gymbaby.cn/xx/index.html?centre_id=$centre_id&market=$market";//网址或者是文本内容
        $level=3;
        $size=8;
        $filename ="Uploads/Erwm/centre$centre_id"."sc_id$market.png"; //图片输出路径和文件名
        $errorCorrectionLevel =intval($level) ;//容错级别
        $matrixPointSize = intval($size);//生成图片大小
        $object->png($url, $filename, $errorCorrectionLevel, $matrixPointSize, 2);
        $data['erwm']="http://".HTTP_HOST.$filename;
        M('xueyuan_baoming')->where("user_id='$market'")->save($data);
        $this->ajaxReturn(1,'JSON');
    }
    //查看二维码
    public function erlist(){
      header("access-control-allow-origin:*"); 
      $user_id=I('post.user_id');
      $arr=M('xueyuan_baoming')->where("user_id='$user_id'")->getField("erwm");
      $this->ajaxReturn($arr,'JSON');
    }
    //二维码下载
    public function xiazai(){
      header("access-control-allow-origin:*"); 
      $user_id = I('post.user_id');
      $erwm=M('xueyuan_baoming')->where("user_id='$user_id'")->field("erwm,username")->find();
      $erm=$erwm['erwm'];
      $username=$erwm['username'];
      header("Content-type: octet/stream");
      header("Content-disposition:attachment;filename=".$username.'.'.'png'.";");
      header("Content-Length:".filesize($erm));
      readfile($erm);
      exit;
    }
    //个人中心
    public function geren(){
      header("access-control-allow-origin:*"); 
      $id=I('post.uid');
      $arr=M('xueyuan_baoming')->where("user_id='$id'")->find();
      $this->ajaxReturn($arr,'JSON');
    }
    //证书
    public function zs(){
      header("access-control-allow-origin:*"); 
    	$id=I('post.uid');
    	$arr=M('crm_user_certificate')->where("user_id='$id'")->select();
    	$this->ajaxReturn($arr,'JSON');
    }
    //修改头像
    public function toux(){
      header("access-control-allow-origin:*"); 
      $upload = new \Think\Upload();        //实例化上传类
      $upload->maxSize   =     3145728 ;    // 设置附件上传大小
      $upload->exts      =     array('jpg', 'gif', 'png', 'jpeg');  // 设置附件上传类型
      $upload->savePath  =      './touxiang/';                       // 设置附件上传目录
      $info   =   $upload->upload();                           // 上传文件
      $a=date("Y-m-d");                                             //获取并格式化当天日期
      $b=$info['uploadPicture']['savename'];
      $id=$_POST['user_id'];
      $data['img']="http://".HTTP_HOST."Uploads/touxiang/$a/$b";
      // 保存上传的照片根据需要自行组装
      if(M('xueyuan_baoming')->where("user_id='$id'")->save($data)){
        $this->redirect("Yuangon/details?id=$id");  
      }
    }
    //修改简介
    public function jianj(){
      header("access-control-allow-origin:*"); 
      $data['content']=I('post.content');
      $user_id=I('post.user_id');
      if(M('xueyuan_baoming')->where("user_id='$user_id'")->save($data)){
        echo 1;
      }
    }
    //上传证书
    public function shangchuan(){
      $upload = new \Think\Upload();        //实例化上传类
      $upload->maxSize   =     3145728 ;    // 设置附件上传大小
      $upload->exts      =     array('jpg', 'gif', 'png', 'jpeg');  // 设置附件上传类型
      $upload->savePath  =      './zhengshu/';                       // 设置附件上传目录
      $info   =   $upload->upload();                           // 上传文件
      $a=date("Y-m-d");                                             //获取并格式化当天日期
      $b=$info['img']['savename'];
      $id=$_POST['user_id'];
      $data['img']="http://".HTTP_HOST."Uploads/zhengshu/$a/$b";
      $data['user_id']=$id;
      // 保存上传的照片根据需要自行组装
      if(M('crm_user_certificate')->add($data)){
        $this->redirect("Yuangon/details?id=$id");  
      }
    }

}