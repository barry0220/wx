<?php
namespace Home\Controller;

use Think\Controller;
//角色控制器
class RoleController extends Controller{
//显示角色列表
	function index(){
		header("access-control-allow-origin:*");
		$user_id=I('post.user_id');
        $centre_id=M('xueyuan_baoming')->where("user_id='$user_id'")->getField('centre_id');
        $centre_id=223;
        $arr=M('crm_role')->where("centre_id='$centre_id'")->select();
        $this->ajaxReturn($arr,'JSON');
	}
	//添加角色
	function addj(){
		header("access-control-allow-origin:*");
		$data['r_name']=I('post.r_name');
		$data['centre_id']=223;
		if(M('crm_role')->add($data)){
			echo 1;
		}
	}
	//权限分配
	function distribute(){
		header("access-control-allow-origin:*");
		$id=I('post.id');
		$arr['z']=M('crm_auth')->select();
		$arr['y']=M('crm_role')->where("r_id='$id'")->find();
		$arr['y']['ids']=explode(',', $arr['y']['role_auth_ids']);
		$this->ajaxReturn($arr,'JSON');
	}

	function add(){
		if(!empty($_POST)){
			//实例化角色表
			$mode=D('crm_role');
			$mode->create();
			$re=$mode->add();
			if($re){
				$this->redirect('index');
			}else{
				$this->redirect('index');
			}
		}
	}
	function del(){
		$Role = M ( 'crm_role' ); // 实例化角色表
		$id = I ( 'post.id' ); // 获得ID
		//删除角色前删除对应的管理员(非必要)
		
		$rel = $Role->delete ($id); // 执行删除操作
		if ($rel) {
			echo 1;
		}
	}
}
