<?php
namespace Home\Controller;
use Think\Controller;
class AaaController extends Controller {
    public function index(){
    	set_time_limit(0);//设置超时时间
    	$sql="SELECT crm_ce.*,a.sum FROM `crm_ce` LEFT JOIN (SELECT a.user_id,sum(xiaohao) as sum FROM `crm_user_skjl` as a where create_time>'2017-10-17' and status=2 group by user_id) a on crm_ce.zhi=a.user_id";
    	$arr=M()->query($sql);
    	foreach ($arr as $key => $value) {
    		$data['cha']=$value['content']-$value['sum'];
    		$data['centre_id']=M('crm_user_skjl')->where("user_id='$value[zhi]'")->getField('centre_id');
    		$a[]=M('crm_ce')->where("id='$value[id]'")->save($data);
    	}

    }
}