<?php
// 本类由系统自动生成，仅供测试用途
namespace Home\Controller;
use Think\Controller;
class QiandaojieController extends Controller {
//老师下拉列表接口
  public function teacher(){
    header("access-control-allow-origin:*");  
    $user_id=I('post.user_id');
    $centre_id=M('xueyuan_baoming')->where("user_id='$user_id'")->getField('centre_id');
    $arr=M("xueyuan_baoming")->where("centre_id='$centre_id' and gangwei='老师' and status=1")->field("user_id,username")->select();
    $this->ajaxReturn($arr,'JSON');
  }
//签到
    public function index(){
      header("access-control-allow-origin:*");
      $uid=I('post.user_id');
      $centre_id=M('xueyuan_baoming')->where("user_id='$uid'")->getField('centre_id');
      $centre_id=223;
      $week = date(N,time());
      $time=date("Y-m-d");
      // $dii=date("H:i");
      // $dian=$dii+2;
      // $diandain=$dian.":".date("i");
      // $kecheng=M('crm_kecheng')
      // ->join("crm_ke on crm_kecheng.kc_id=crm_ke.kc_id")
      // ->where("crm_kecheng.centre_id='$centre_id' and crm_kecheng.week='$week'")
      // ->select();
      $skjl="select teacher,pk_id,count(distinct pk_id) from crm_user_skjl where centre_id='$centre_id' and create_time='$time' group by pk_id";
      $arr=M()->query($skjl);
      $sql="SELECT a.*,b.kc_name,b.yueling,b.yueling2,c.content,d.username,d.user_id uid FROM crm_kecheng as a LEFT JOIN crm_ke as b on a.kc_id=b.kc_id LEFT JOIN flexo as c on a.xuhao=c.id LEFT JOIN xueyuan_baoming as d on a.user_id=d.user_id WHERE a.status=1 AND a.centre_id='$centre_id' AND a.start_time<='$time' AND a.week=$week AND a.end_time>='$time' ORDER BY a.s_time";
      $kecheng=M()->query($sql);
      foreach ($kecheng as $key => $val) {
        $d=explode(",",$val['gd_id']);
        if($val['gd_id']!=null){
             $f=count($d);
        }else{
          $f=" ";
        }
        $kecheng[$key]['gdnu']=$f;
        $kecheng[$key]['gd_id']=$d;
        foreach ($arr as $ke => $value) {
          if($val['pk_id']==$value['pk_id']){
            $kecheng[$key]['teacher']=$value['teacher'];
            if($kecheng[$key]['teacher']!=null){
              unset($kecheng[$key]);
            }
          }
        }
       }
        $this->teacher=M("xueyuan_baoming")->where("centre_id='$centre_id' and gangwei='老师' and status=1")->field("user_id,username")->select();
        // $this->user=M('wx_user')->where("belong='$centre_id' and gd_id!=''")->field('baobao_name,user_id,gd_id,status')->select();
        foreach ($kecheng as $k => $val) {
          $where['user_id']=array("in",$val['gd_id']);
          $kecheng[$k]['user']=M("wx_user")->where($where)->field("baobao_name,user_id,qiandao")->select();
          $kecheng[$k]['yq']=M('crm_user_skjl')
          ->join("wx_user on crm_user_skjl.user_id=wx_user.user_id")
          ->where("crm_user_skjl.pk_id='$val[pk_id]' and crm_user_skjl.create_time='$time' and crm_user_skjl.status=1")
          ->field("crm_user_skjl.*,wx_user.baobao_name")
          ->select();
          foreach ($kecheng[$k]['user'] as $keyee => $value) {
            $kecheng[$k]['user'][$keyee]['qiandao']=unserialize($value['qiandao']);
            foreach ($kecheng[$k]['user'][$keyee]['qiandao'] as $keye => $valuee) {
              if($kecheng[$k]['user'][$keyee]['qiandao'][$keye]['pk_id']==$val['pk_id'] and $kecheng[$k]['user'][$keyee]['qiandao'][$keye]['create_time']==$time){
              $kecheng[$k]['user'][$keyee]['qiandao']=1;
            }
            }
            
          }
        }
        // foreach ($kecheng as $key => $value) {
        //   $arre[]=M('crm_user_skjl')
        //   ->join("wx_user on crm_user_skjl.user_id=wx_user.user_id")
        //   ->where("pk_id='$value[pk_id]' and create_time='$time'")
        //   ->field("crm_user_skjl.*,wx_user.baobao_name")
        //   ->find();
        // }
        // $sql1="SELECT wx_user.baobao_name,wx_user.user_id,wx_user.gd_id,crm_user_skjl.status,crm_user_skjl.teacher,crm_user_skjl.pk_id FROM `wx_user` LEFT JOIN crm_user_skjl on wx_user.user_id=crm_user_skjl.user_id LEFT JOIN crm_kecheng on crm_kecheng.pk_id=crm_user_skjl.pk_id where wx_user.belong='$centre_id' and wx_user.gd_id!='' and wx_user.status=1";
        // $user=M()->query($sql1);
        // foreach ($user as $key => $val) {
        //   $d=explode(",",$val['gd_id']);
        //   $user[$key]['gd_id']=$d;
        //   if($val['status']==null and $val['pk_id']==null){
        //     $user[$key]['status']=0;
        //     $user[$key]['pk_id']=0;
        //   }
        // }
        // $this->data=$kecheng;
        // $this->yqq=$arre;
       // echo "<pre>";
       // print_r($kecheng);die;
       //  $this->user=$user;
       //  $this->kecheng=M('crm_kecheng')
       //  ->join("crm_ke on crm_kecheng.kc_id=crm_ke.kc_id")
       //  ->where("crm_kecheng.status=1 AND crm_kecheng.centre_id='$centre_id' AND crm_kecheng.start_time<='$time' AND crm_kecheng.week=$week AND crm_kecheng.end_time>='$time' AND crm_kecheng. s_time>='09:00'")
       //  ->select();
        $this->ajaxReturn($kecheng,'JSON');die;
        // $this->display();
    }
    public function qiandao(){
       header("access-control-allow-origin:*");
       set_time_limit(0);//设置超时时间
       ini_set("memory_limit","-1");
       $uid=I('post.uid');
       $centre_id=M('xueyuan_baoming')->where("user_id='$uid'")->getField('centre_id');
       // $centre_id=session('centre_id');
       $user_id=I('post.user_id');
       $uere=M("wx_user")->where("user_id='$user_id'")->field("qiandao,jl_id")->find();
       $qiandao=$uere['qiandao'];
       $jl_id=$uere['jl_id'];
       $y_keshi=M('crm_kjilu')->where("jl_id='$jl_id'")->getField("y_keshi");
       if($y_keshi<1){
        $this->ajaxReturn(3,'JSON');die;
       }
       $pk_id=I('post.pk_id');
       $daa=M('wx_centre')->where("centre_id='$centre_id'")->getField('da');
       
       $time=date("Y-m-d");
       $teacher=M("crm_user_skjl")->where("pk_id='$pk_id' and create_time='$time'")->getField("teacher");
       if($teacher!=null){
        $data['teacher']=$teacher;
       }
       $arr=M('crm_user_skjl')->where("user_id='$user_id' and pk_id='$pk_id' and create_time='$time'")->field("sk_id,status")->find();
       $sk_id=$arr['sk_id'];
       $status=$arr['status'];
       $xiaoke=M("crm_kecheng")->where("pk_id='$pk_id'")->getField('xiaoke');
       $data['centre_id']=session('centre_id');
       $centre=M('wx_centre')->where("centre_id='$centre_id'")->field("c_phone,centre")->find();
      $are=M('crm_kecheng')
      ->join("crm_ke on crm_kecheng.kc_id=crm_ke.kc_id")
      ->join("xueyuan_baoming on crm_kecheng.user_id=xueyuan_baoming.user_id")
      ->where("crm_kecheng.pk_id='$pk_id'")
      ->field("crm_ke.kc_name,crm_kecheng.xiaoke,xueyuan_baoming.username")
      ->find();
       if($status==null){
        if($daa==1){
      $ar=M('wx_user')
      ->join("crm_kjilu on wx_user.jl_id=crm_kjilu.jl_id")
      ->join("crm_goods on crm_kjilu.s_id=crm_goods.s_id")
      ->where("wx_user.user_id='$user_id'")
      ->field("wx_user.phone1,wx_user.phone2,wx_user.phone3,wx_user.phone4,wx_user.phone5,wx_user.phone6,wx_user.baobao_name,crm_goods.k_shu,crm_kjilu.y_keshi,crm_kjilu.zeng_ke")
      ->find();
      if($ar['phone1']!=null){
        $a['phone']=$ar['phone1'];
      }else if($ar['phone2']!=null){
        $a['phone']=$ar['phone2'];
      }else if($ar['phone3']!=null){
        $a['phone']=$ar['phone3'];
      }else if($ar['phone4']!=null){
        $a['phone']=$ar['phone4'];
      }else if($ar['phone5']!=null){
        $a['phone']=$ar['phone5'];
      }else if($ar['phone6']!=null){
        $a['phone']=$ar['phone6'];
      }
      $a['username']=$ar['baobao_name'];
      $a['centre']=$centre['centre'];
      $a['z_number']=$ar['k_shu']+$ar['zeng_ke'];
      $a['y_keshi']=$ar['y_keshi']-1;
      $a['sk']=$a['z_number']-$a['y_keshi'];
      $a['kc_name']=$are['kc_name'];
      $a['xiaohao']=$are['xiaoke'];
      $a['teacher']=$are['username'];
      $a['time']=date("Y/m/d H:i:s");
      $a['c_phone']=$centre['c_phone'];
      $a['zzz']=1;
       }
        if($qiandao==null){
         $arra[]=array('pk_id' =>$pk_id,'create_time'=>$time);
         $dat['qiandao']=serialize($arra);
       }else{
         $arraa=unserialize($qiandao);
         foreach ($arraa as $key => $value) {
           $arra=array('pk_id' =>$pk_id,'create_time'=>$time);
           $arraa[]=$arra;
         }
         $dat['qiandao']=serialize($arraa);
       }
       M("wx_user")->where("user_id='$user_id'")->save($dat);
        $data['create_time']=date("Y-m-d");
        $data['user_id']=$user_id;
        $data['pk_id']=$pk_id;
        $data['xiaohao']=$xiaoke;
        $data['create_name']=session("user_id");
        $data['source']="PC";
        $data['kc_name']=$are['kc_name'];
        $data['sign_name']=session('user_id');
        $data['sign_time']=date('Y-m-d H:i:s');
        M('crm_user_skjl')->add($data);
        $a['status']=0;
        $this->ajaxReturn($a,'JSON');die;
       }else if($status==0){
        if($daa==1){
        $centre=M('wx_centre')->where("centre_id='$centre_id'")->field("c_phone,centre")->find();
      $are=M('crm_kecheng')
      ->join("crm_ke on crm_kecheng.kc_id=crm_ke.kc_id")
      ->join("xueyuan_baoming on crm_kecheng.user_id=xueyuan_baoming.user_id")
      ->join('flexo on crm_kecheng.xuhao=flexo.id')
      ->where("crm_kecheng.pk_id='$pk_id'")
      ->field("crm_ke.kc_name,crm_kecheng.xiaoke,xueyuan_baoming.username,crm_kecheng.s_time,crm_kecheng.x_time,flexo.content")
      ->find();
      $ar=M('wx_user')
      ->join("crm_kjilu on wx_user.jl_id=crm_kjilu.jl_id")
      ->join("crm_goods on crm_kjilu.s_id=crm_goods.s_id")
      ->where("wx_user.user_id='$user_id'")
      ->field("wx_user.phone1,wx_user.phone2,wx_user.phone3,wx_user.phone4,wx_user.phone5,wx_user.phone6,wx_user.baobao_name,crm_goods.k_shu,crm_kjilu.y_keshi,crm_kjilu.zeng_ke")
      ->find();
      if($ar['phone1']!=null){
        $a['phone']=$ar['phone1'];
      }else if($ar['phone2']!=null){
        $a['phone']=$ar['phone2'];
      }else if($ar['phone3']!=null){
        $a['phone']=$ar['phone3'];
      }else if($ar['phone4']!=null){
        $a['phone']=$ar['phone4'];
      }else if($ar['phone5']!=null){
        $a['phone']=$ar['phone5'];
      }else if($ar['phone6']!=null){
        $a['phone']=$ar['phone6'];
      }
      $a['username']=$ar['baobao_name'];
      $a['centre']=$centre['centre'];
      $a['z_number']=$ar['k_shu']+$ar['zeng_ke'];
      $a['y_keshi']=$ar['y_keshi']-1;
      $a['sk']=$a['z_number']-$a['y_keshi'];
      $a['kc_name']=$are['kc_name'];
      $a['xiaohao']=$are['xiaoke'];
      $a['teacher']=$are['username'];
      $a['time']=date("Y/m/d H:i:s");
      $a['c_phone']=$centre['c_phone'];
      $a['zzz']=1;
      $a['sktime']=$are['s_time'].'-'.$are['x_time'];
      $a['jiaoshi']=$are['content'];
       }
        $da['status']=1;
         $da['create_name']=session("user_id");
         M('crm_user_skjl')->where("sk_id='$sk_id'")->save($da);
        if($qiandao==null){
         $arra[]=array('pk_id' =>$pk_id,'create_time'=>$time);
         $dat['qiandao']=serialize($arra);
       }else{
         $arraa=unserialize($qiandao);
         foreach ($arraa as $key => $value) {
           $arra=array('pk_id' =>$pk_id,'create_time'=>$time);
           $arraa[]=$arra;
         }
         $dat['qiandao']=serialize($arraa);
       }
       M("wx_user")->where("user_id='$user_id'")->save($dat);
         $a['status']=0;
        $this->ajaxReturn($a,'JSON');die;
       }else if($status==1) {
         $arraa=unserialize($qiandao);
         foreach ($arraa as $key => $value) {
           if($value['pk_id']==$pk_id and $value['create_time']==$time){
            if(count($arraa)==1){
              unset($arraa);
            }else{
              unset($arraa[$key]);
            }
           }
       }
       $da['status']=0;
         $da['create_name']=session("user_id");
         M('crm_user_skjl')->where("sk_id='$sk_id'")->save($da);
       if($arraa==null){
        $dat['qiandao']=null;
       }else{
       $dat['qiandao']=serialize($arraa);
       }
       M("wx_user")->where("user_id='$user_id'")->save($dat);
         
         $a['status']=1;
        $this->ajaxReturn($a,'JSON');die;
       }
       
    }
    //搜索
    public function shou(){
      header("access-control-allow-origin:*");
      $uid=I('post.uid');
      $centre_id=M('xueyuan_baoming')->where("user_id='$uid'")->getField('centre_id');
      $zhi=I('post.zhi');
      $userid=I('post.user_id');
      $week = date(N,time());
      $time=date("Y-m-d");
      if(empty($zhi)){
        $arr=M('wx_user')->where("belong='$centre_id' and user_id='$userid'")->find();
      }else{
        $arr=M('wx_user')->where("belong='$centre_id' and (user_id='$zhi' or baobao_name='$zhi')")->find();
      }
      $shij=date("Y-m-d");
      $d=strtotime($shij)-strtotime($arr['baobao_birthday']);
        $e=$d/2592000;//一个月的时间，单位秒
        $f=round($e);//月龄取整
        $ar['yueling']=$f;
        $ar['baobao_name']=$arr['baobao_name'];
        $ar['name2']=$arr['name2'];
        $ar['user_id']=$arr['user_id'];
        $ar['phone2']=$arr['phone2'];
        $user_id=$ar['user_id'];
        $skjl="select teacher,pk_id,count(distinct pk_id) from crm_user_skjl where centre_id='$centre_id' and create_time='$time' group by pk_id";
        $arrqq=M()->query($skjl);
        $kecheng=M('crm_kecheng')
        ->join("crm_ke on crm_kecheng.kc_id=crm_ke.kc_id")
        ->where("crm_kecheng.status=1 AND crm_kecheng.centre_id='$centre_id' AND crm_kecheng.start_time<='$shij' AND crm_kecheng.week=$week AND crm_kecheng.end_time>='$shij' AND crm_kecheng.s_time>='08:00'")
        ->select();
        foreach ($kecheng as $key => $val) {
          $tai=M("crm_user_skjl")->where("user_id='$user_id' and pk_id='$val[pk_id]' and centre_id='$centre_id' and create_time='$time'")->getField("status");
          if($tai==1){
            $kecheng[$key]['tai']="http://".HTTP_HOST."/Public/img/qdxietu/over.png";
          }else{
            $kecheng[$key]['tai']="http://".HTTP_HOST."/Public/img/qdxietu/clock in.png";
          }
        //   foreach ($arrqq as $ke => $value) {
        //   if($val['pk_id']==$value['pk_id']){
        //     $kecheng[$key]['teacher']=$value['teacher'];
        //     if($kecheng[$key]['teacher']!=null){
        //       unset($kecheng[$key]);
        //     }
        //   }
        // }
        $kecheng[$key]['xx']=$ar;
        }
        $this->ajaxReturn($kecheng,'JSON');
    }
    //开课接口
    public function kaike(){
      header("access-control-allow-origin:*");
      $pk_id=I('post.pk_id');
      $teacher=I('post.teacher');
      $uid=I('post.uid');//登录人id
      $centre_id=M('xueyuan_baoming')->where("user_id='$uid'")->getField('centre_id');
      $bzr=M('crm_kecheng')->where("pk_id='$pk_id'")->getField('user_id');
      $time=date("Y-m-d");
      $data['create_time']=$time;
      $data['teacher']=$teacher;
      $data['bzr']=$bzr;
      $data['start_name']=$uid;
      $data['start_time']=date('Y-m-d H:i:s');
      $sk_id=M('crm_user_skjl')->where("pk_id='$pk_id' and create_time='$time'")->getField("sk_id");
      if(empty($sk_id)){
        $da['create_time']=$time;
        $da['teacher']=$teacher;
        $da['bzr']=$bzr;
        $da['source']='PC';
        $da['centre_id']=$centre_id;
        $da['status']=1;
        $da['xiaohao']=0;
        $da['pk_id']=$pk_id;
        $da['create_name']=$uid;
        $da['start_name']=$uid;
        $da['start_time']=date('Y-m-d H:i:s');
        M('crm_user_skjl')->add($da);
      }else{
      M('crm_user_skjl')->where("pk_id='$pk_id' and create_time='$time'")->save($data);
      }
      $this->redirect("Qiandao/index");
    }
    //签到onkeyup出会员
    public function mim(){
      header("access-control-allow-origin:*");
      $uid=I('post.uid');
      $centre_id=M('xueyuan_baoming')->where("user_id='$uid'")->getField('centre_id');
      $zhi=I('post.zhi');
      // $uid=I('post.uid');
      // $centre_id=223;
      $arr=M('wx_user')->where("baobao_name like '%$zhi%' and yon=2 and belong='$centre_id'")->select();
      foreach ($arr as $key => $value) {
        if($value['phone1']!=null){
        $arr[$key]['phone']=$value['phone1'];
      }else if($value['phone2']!=null){
        $arr[$key]['phone']=$value['phone2'];
      }else if($value['phone3']!=null){
        $arr[$key]['phone']=$value['phone3'];
      }else if($value['phone4']!=null){
        $arr[$key]['phone']=$value['phone4'];
      }else if($value['phone5']!=null){
        $arr[$key]['phone']=$value['phone5'];
      }else if($value['phone6']!=null){
        $arr[$key]['phone']=$value['phone6'];
      }
      if($value['name1']!=null){
        $arr[$key]['name']=$value['phone1'];
      }else if($value['name2']!=null){
        $arr[$key]['name']=$value['phone2'];
      }else if($value['name3']!=null){
        $arr[$key]['name']=$value['phone3'];
      }else if($value['name4']!=null){
        $arr[$key]['name']=$value['phone4'];
      }else if($value['name5']!=null){
        $arr[$key]['name']=$value['phone5'];
      }else if($value['name6']!=null){
        $arr[$key]['name']=$value['phone6'];
      }
      }
      $this->ajaxReturn($arr,'JSON');
    }

  }
