<?php
namespace Home\Controller;
use Think\Controller;
class kecszjieController extends Controller {
     public function index(){
      header("access-control-allow-origin:*"); 
     	if(isset($_POST['page'])){
         $page=$_POST['page'];
       }else{
         $page=1;
       }
       $uid=I('post.uid');
      $centre_id=M('xueyuan_baoming')->where("user_id='$uid'")->getField('centre_id');
       $num=M("crm_ke")->where("status=1 and (centre_id=0 or centre_id='$centre_id')")->count();
       $pageone=10;//每页数据
       $pagetotal=ceil($num/$pageone);
       $pyl=($page-1)*$pageone;//偏移量
       $sql="SELECT * FROM crm_ke where status=1 and (centre_id=0 or centre_id='$centre_id') order by kc_id desc limit $pyl,$pageone";
       $arr=M()->query($sql);
       foreach ($arr as $key => $value) {
         $arr[$key]['page']=$page;
         $arr[$key]['pagetotal']=$pagetotal;
         $arr[$key]['num']=$num;
       }
       $this->ajaxReturn($arr,'JSON');
     }
     //添加课程接口
     public function add(){
      header("access-control-allow-origin:*"); 
      $data['kc_name']=I('post.kc_name');
      $data['yueling']=I('post.yueling');
      $data['yueling2']=I('post.yueling2');
      $data['xiaohao']=I('post.xiaohao');
      $uid=I('post.uid');
      $centre_id=M('xueyuan_baoming')->where("user_id='$uid'")->getField('centre_id');
       $data['centre_id']=$centre_id;
       $data['create_name']=$uid;
      $data['source']="PC";
      if(M('crm_ke')->add($data)){
        $this->redirect("index");
      }
     }
     //删除课程接口
     public function shanchu(){
      header("access-control-allow-origin:*"); 
      $crm_ke=M("crm_ke");
      $id=I('post.id');
      $centre_id=M("crm_ke")->where("kc_id=".$id)->getField("centre_id");
      if($centre_id==0){
        echo 2;die;//如果是总部将不能删除
      }
      $data['status']=0;
      M('crm_kecheng')->where("kc_id='$kc_id'")->save($data);
      $rel=$crm_ke->where("kc_id=".$id)->save($data);
      if($rel){
        echo 1;
      }
    }
   }