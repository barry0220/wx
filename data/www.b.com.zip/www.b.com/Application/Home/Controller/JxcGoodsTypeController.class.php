<?php
namespace Home\Controller;
use Think\Controller;
/**
 *
 * 进销存模块 商品类别控制器
 *
 */
class JxcGoodsTypeController extends CommonController {
    //获取当前中心商品类别信息 需求参数 search 类别名称 page 当前页码 pageone 每页数量
    public function index(){
        ob_clean();
        $centre_id = session('centre_id');   //获取当前门店ID

        //判断是否存在条件查询
        $search = I('post.search');
        $page = I('post.page') ? I('post.page') : 1;
        $pageone=I('post.pageone') ? I('post.pageone') : 10;//每页数据
        $map['search'] = $search;  //条件返回
        $map['page'] = $page;
        $map['pageone'] = $pageone;
        //组装where条件
        $where = [
            'centre_id' => $centre_id,
            'status'=>1
        ];

        if($search){
            $where['type_name'] = [['like', "%{$search}%"]];
        }

        $Goods_type = M('jxc_goods_type');      //实例化

        $count = $Goods_type ->where($where)->count();   //获取数据总数
        $pagetotal=ceil($count/$pageone);   //总页数
        $map['pagetotal'] = $pagetotal; //返回参数 总页数
        $pyl=($page-1)*$pageone;//偏移量

        $res = $Goods_type  -> where($where)->order('id desc')->limit($pyl,$pageone) -> select();   //获取结果信息
        $data = ['map'=>$map,'data'=>$res];

        $this -> ajaxReturn($data,'JSON');
    }

    //执行添加商品类别 需求参数type_name 类别名称 消息返回1 错误信息 成功返回2 成功信息
    public function store()
    {
        ob_clean();
        //判断是否非法访问 非法方式返回错误
        if (!IS_POST) {
            $this -> ajaxReturn(['status'=>1,'msg'=>'请求方式不合法'],'JSON');
        }

        //创建验证规则
        $rules = [
            ['type_name','require','商品类别名称不能为空'],
        ];

        $Goods_type = D("jxc_goods_type"); // 实例化对象

        if (!$Goods_type->validate($rules) -> create()){     // 如果创建失败 表示验证没有通过  输出错误提示信息
            $this -> ajaxReturn(['status'=>1,'msg'=>"验证失败".$Goods_type->getError()],'JSON');
        }else{     // 验证通过 可以进行其他数据操作
            $centre_id = session('centre_id');   //获取当前门店ID  测试为1
            //获取当前时间与随机数 用于添加类别编号
            $type_num = $this -> getNum();
            //获取数据
            $fields['type_name'] = I('post.type_name');
            $fields['type_num'] = $type_num;
//            dd($type_num);
            $fields['centre_id'] = $centre_id;
            $user_id = session("user_id");  //获取当前登陆用户的user_id  总部后台管理系统获取mg_id  会员管理系统获取user_id
            $fields['user_id'] = $user_id;
            $fields['status'] = 1;
            //创建模型对象
            $Goods_type->create($fields);
            //执行添加
            $res = $Goods_type->add();

            if(false !== $res){
//                $this->success( U('JxcGoodsType/index'));
                $this -> ajaxReturn(['status'=>2,'msg'=>'添加成功'],'JSON');
            } else {
                $this -> ajaxReturn(['status'=>1,'msg'=>'添加失败'],'JSON');
            }
        }
    }



    //修改商品类别信息 需求参数id 修改的数据ID type_name 类别名称 消息返回1 错误信息 成功返回2 成功信息
    public function update()
    {
        ob_clean();
        //判断是否非法访问 非法方式返回错误
        if (!IS_POST) {
            $this -> ajaxReturn(['status'=>1,'msg'=>'请求方式不合法'],'JSON');
        }
        $type_id = I('post.id');    //获取要修改的ID
        //创建验证规则
        $rules = [
            ['type_name','require','商品类别名称不能为空'],
        ];

        $Goods_type = M('jxc_goods_type'); // 实例化对象

        if (!$Goods_type->validate($rules) -> create()){     // 如果创建失败 表示验证没有通过 输出错误提示信息
            $this -> ajaxReturn(['status'=>1,'msg'=>'验证失败'.$Goods_type->getError()],'JSON');

        }else{     // 验证通过 可以进行其他数据操作
            //获取数据
            $fields['type_name'] = I('post.type_name');

            //执行修改
            $res = $Goods_type->where('id='.$type_id)->save($fields);

            if(false !== $res){
                //写入LOG
                $content = "修改商品类别".$fields['type_name']."成功";
                setLog($content);
                $this -> ajaxReturn(['status'=>2,'msg'=>'修改成功'],'JSON');
            } else {
                $this -> ajaxReturn(['status'=>1,'msg'=>'修改失败'],'JSON');
            }
        }


    }

    //删除商品类别信息  安全删除  状态修改为0 需求参数id 修改的数据ID  消息返回1 错误信息 成功返回2 成功信息
    public function delete()
    {
        ob_clean();
        $type_id = I('post.id');

        $fields['status'] = 0;
        $res = M('jxc_goods_type')->where("id = '{$type_id}'")->save($fields);

        if($res){
            //写入LOG
            $type_name = M('jxc_goods_type')->where("id = $type_id")->find()['type_name'];
            $content = "删除商品类别".$type_name."成功";
            setLog($content);
//            $this->success('删除成功', U('JxcGoodsType/index'), 3);
            $this -> ajaxReturn(['status'=>2,'msg'=>'删除成功'],'JSON');
        } else {
            $this -> ajaxReturn(['status'=>1,'msg'=>'删除失败'],'JSON');
//            $this->success('删除失败', U('JxcGoodsType/index'), 3);
        }
    }
    //生成流水编号
    public function getNum()
    {
        //设置编号开头
        $first = 'TP';
        $centre_id = session('centre_id');  //获取当前中心ID
//        获取当天日期
        $date = date('Ymd');
        $where = [
            'centre_id'=>$centre_id,
            'create_time'=>[
                'gt',$date
            ]
        ];
        //获取当前数据库当天使用的最后一个流水号
        $lastNum = M('jxc_goods_type')->where($where)->order('id desc')->find()['type_num'];
        //如果存在  截取后四位 并且加1  如果不存在生成当天第一条
        if ($lastNum){
            $last = substr($lastNum,-4);    //获取最后4位
            $a = substr($lastNum,0,-4);     //获取前面N位
            $var=sprintf("%04d", $last+1);
            $num = $a.$var;
            return $num;
        }else{
            $date = substr($date,2);
            $num = $first.$date.$centre_id.'0001';
            return $num;
        }
    }
}