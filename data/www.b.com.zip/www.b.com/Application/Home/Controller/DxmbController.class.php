<?php
namespace Home\Controller;
use Think\Controller;
class DxmbController extends Controller {
  //模板记录
    public function index(){
       header("access-control-allow-origin:*");
       $arr=M('crm_dx_mb')->where("is_shoud=1")->select();
       $this->ajaxReturn($arr,'JSON');
    }
}