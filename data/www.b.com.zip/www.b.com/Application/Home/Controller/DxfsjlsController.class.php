<?php
namespace Home\Controller;
use Think\Controller;
class DxfsjlsController extends Controller {
  //短信发送记录通过日期筛选
    public function index(){
       header("access-control-allow-origin:*");
       $time1=I('post.time1');
       $time2=I('post.time2');
       $centre_id=session('centre_id');
        $arr=M('crm_dx')
       ->join("wx_user on crm_dx.user_id=wx_user.user_id")
       ->join("crm_dx_mb on crm_dx.mb_id=crm_dx_mb.mb_id")
       ->where("crm_dx.centre_id='$centre_id' and crm_dx.create_time>='$time1' and crm_dx.create_time<='$time2'")
       ->field("crm_dx.dx_id,wx_user.baobao_name,crm_dx.phone,crm_dx.create_time,crm_dx_mb.mb_type,crm_dx.type,crm_dx.status")
       ->select();
      foreach ($arr as $key => $value) {
      	$arr[$key]['uu']=$key+1;
      	if($value['status']==1){
      		$arr[$key]['status']='成功';
      	}else{
      		$arr[$key]['status']='失败';
      	}
      }
       $this->ajaxReturn($arr,'JSON');
    }
}