<?php
namespace Home\Controller;
use Think\Controller;
/**
 *
 * 进销存模块 供应商控制器
 *
*/
class JxcSupplierController extends CommonController {
    //获取当前中心供应商信息
    public function index(){
        ob_clean();
        $centre_id = session('centre_id');   //获取当前门店ID  测试为1

        //判断是否存在条件查询
        $search = I('post.search');
        $page = I('post.page') ? I('post.page') : 1;
        $pageone=I('post.pageone') ? I('post.pageone') : 10;//每页数据
        $map['search'] = $search;  //条件返回
        $map['page'] = $page;
        $map['pageone'] = $pageone;
        //组装where条件
        $where = [
            'centre_id' => $centre_id,
            'status'=>1
        ];

        if($search){
            $where['supplier_name'] = [['like', "%{$search}%"]];
        }

        $Suppliers = M('jxc_supplier');      //实例化

        $count = $Suppliers ->where($where)->count();   //获取数据总数
        $pagetotal=ceil($count/$pageone);   //总页数
        $map['pagetotal'] = $pagetotal; //返回参数 总页数
        $pyl=($page-1)*$pageone;//偏移量

        $res = $Suppliers  -> where($where)->order('id desc')->limit($pyl,$pageone) -> select();   //获取结果信息
        $data = ['map'=>$map,'data'=>$res];

        $this -> ajaxReturn($data,'JSON');
    }

    //显示添加页面
    public function add()
    {
//        $this -> display();
    }


    //执行添加供货商
    public function store()
    {
        ob_clean();
        //判断是否非法访问 非法方式返回错误
        if (!IS_POST) {
            $this -> ajaxReturn(['status'=>1,'msg'=>'请求方式不合法'],'JSON');
        }

        //创建验证规则
        $rules = [
            ['supplier_name','require','供应商名称不能为空'],
        ];

        $Supplier = D("jxc_supplier"); // 实例化对象
        $post_data = I('post.data');    //获取提交的数据
        if (!$Supplier->validate($rules) -> create($post_data)){     // 如果创建失败 表示验证没有通过 输出错误提示信息
            $this -> ajaxReturn(['status'=>1,'msg'=>"验证失败".$Supplier->getError()],'JSON');
        }else{     // 验证通过 可以进行其他数据操作
            //获取数据
            $centre_id = session('centre_id');   //获取当前门店ID

            $posts['supplier_name'] = $post_data['supplier_name'];  //供应商名称
            $posts['tel'] = $post_data['tel'];  //供应商电话 座机
            $posts['linkman'] = $post_data['linkman'];  //联系人姓名
            $posts['phone'] = $post_data['phone'];  //联系人手机
            $posts['email'] = $post_data['email'];  //联系人email
            $posts['accountname'] = $post_data['accountname'];  //开户名称
            $posts['bankname'] = $post_data['bankname'];       //开户行
            $posts['enterpriseaccount'] = $post_data['enterpriseaccount'];  //银行帐号
            $posts['address'] = $post_data['address'];  //供货商地址
            $posts['zipcode'] = $post_data['zipcode'];  //供货商邮编
            $posts['notes'] = $post_data['notes'];  //备注
            $supplier_num = $this -> getNum();    ////获取当前时间与随机数 用于添加供货商编号
            $posts['supplier_num'] = $supplier_num;  //商家编号
            $posts['centre_id'] = $centre_id;
            $user_id = session("user_id");  //获取当前登陆用户的user_id  总部后台管理系统获取mg_id  会员管理系统获取user_id
            $posts['user_id'] = $user_id;
            $posts['status'] = 1;
            //创建模型对象
            $Supplier->create($posts);
            //执行添加
            $res = $Supplier->add();

            if($res){
                $this -> ajaxReturn(['status'=>2,'msg'=>'添加成功'],'JSON');
            } else {
                $this -> ajaxReturn(['status'=>1,'msg'=>'添加失败'],'JSON');
            }
        }
    }


    //获取单条供货商信息
    public function edit()
    {
        ob_clean();
        $supplier_id = I('post.id');    //获取要查询的供货商的ID

        $Supplier= M('jxc_supplier');

        $res = $Supplier -> where("id='$supplier_id'") -> find();

        $data = ['data'=>$res];
        $this -> ajaxReturn($data,'JSON');
    }


    //修改供货商信息
    public function update()
    {
        ob_clean();
        //判断是否非法访问 非法方式返回错误
        if (!IS_POST) {
            $this -> ajaxReturn(['status'=>1,'msg'=>'请求方式不合法'],'JSON');
        }
        //创建验证规则
        $rules = [
            ['supplier_name','require','供应商名称不能为空'],
        ];

        $Supplier = M("jxc_supplier"); // 实例化对象
        $post_data = I('post.data');
        if (!$Supplier->validate($rules) -> create($post_data)){     // 如果创建失败 表示验证没有通过 输出错误提示信息
            $this -> ajaxReturn(['status'=>1,'msg'=>'验证失败'.$Supplier->getError()],'JSON');

        }else{     // 验证通过 可以进行其他数据操作

            $supplier_id = $post_data['id'];
            //获取数据
            $fields['supplier_name'] = $post_data['supplier_name'];
            $fields['tel'] = $post_data['tel'];  //供应商电话 座机
            $fields['linkman'] = $post_data['linkman'];  //联系人姓名
            $fields['phone'] = $post_data['phone'];  //联系人手机
            $fields['email'] = $post_data['email'];  //联系人email
            $fields['accountname'] = $post_data['accountname'];  //开户名称
            $fields['bankname'] = $post_data['bankname'];       //开户行
            $fields['enterpriseaccount'] = $post_data['enterpriseaccount'];  //银行帐号
            $fields['address'] = $post_data['address'];  //供货商地址
            $fields['zipcode'] = $post_data['zipcode'];  //供货商邮编
            $fields['notes'] = $post_data['notes'];  //备注


            //执行修改
            $res = $Supplier->where('id='.$supplier_id)->save($fields);

            if($res){
                //写入LOG
                $content = "修改供应商".$fields['supplier_name']."成功";
                setLog($content);
                $this -> ajaxReturn(['status'=>2,'msg'=>'修改成功'],'JSON');
            } else {
                $this -> ajaxReturn(['status'=>1,'msg'=>'修改失败'],'JSON');
            }
        }


    }

    //删除供货商信息  安全删除  状态修改为0
    public function delete()
    {
        ob_clean();
        $supplier_id = I('post.id');

        $fields['status'] = 0;
        $res = M('jxc_supplier')->where("id = '{$supplier_id}'")->save($fields);
        if($res){
            //写入LOG
            $supplier_name = M('jxc_supplier')->where("id = $supplier_id")->find()['supplier_name'];
            $content = "删除供应商".$supplier_name."成功";
            setLog($content);
            $this -> ajaxReturn(['status'=>2,'msg'=>'删除成功'],'JSON');
        } else {
            $this -> ajaxReturn(['status'=>1,'msg'=>'删除失败'],'JSON');
        }
    }

    //生成流水编号
    public function getNum()
    {
        //设置编号开头
        $first = 'GY';
        $centre_id = session('centre_id');  //获取当前中心ID
//        获取当天日期
        $date = date('Ymd');
        $where = [
            'centre_id'=>$centre_id,
            'create_time'=>[
                'gt',$date
            ]
        ];
        //获取当前数据库当天使用的最后一个流水号
        $lastNum = M('jxc_supplier')->where($where)->order('id desc')->find()['supplier_num'];
        //如果存在  截取后四位 并且加1  如果不存在生成当天第一条
        if ($lastNum){
            $last = substr($lastNum,-4);    //获取最后4位
            $a = substr($lastNum,0,-4);     //获取前面9位
            $var=sprintf("%04d", $last+1);
            $num = $a.$var;
            return $num;
        }else{
            $date = substr($date,2);
            $num = $first.$date.$centre_id.'0001';
            return $num;
        }

    }

    //全部日志查看
    public function findLog()
    {
        ob_clean();
        $centre_id = session('centre_id');   //获取当前门店ID  测试为1
        //组装where条件
        $where = [
            'centre_id' => $centre_id,
        ];
        //判断是否存在条件查询
        $post_data = I('post.map');
        $search = $post_data['search'];
        $time_s = $post_data['time_s'];
        $time_e = $post_data['time_e'];
        $page = $post_data['page'] ? $post_data['page'] : 1;
        $pageone=$post_data['pageone'] ? $post_data['pageone'] : 10;//每页数据

        //条件返回
        $map['search'] = $post_data['search'];
        $map['time_s'] = $post_data['time_s'];
        $map['time_e'] = $post_data['time_e'];
        $map['page'] = $post_data['page'];
        $map['pageone'] = $post_data['pageone'];

        $string = '';   // 拼接查询条件
        if ($search) {
            $where['content']=['like', "%{$search}%"];
        }
        if ($time_s) {
            $string .= "and jxc_syslog.create_time>='{$time_s}'";
        }
        if ($time_e) {
            $string .= "and jxc_syslog.create_time<='{$time_e}'";
        }
        //判断是否存在查询条件
        if($string){
            $where['_string'] = substr($string,4);
        }


        $Log = M('jxc_syslog');      //实例化

        $count = $Log ->where($where)->count();   //获取数据总数
        $pagetotal=ceil($count/$pageone);   //总页数
        $map['pagetotal'] = $pagetotal; //返回参数 总页数
        $pyl=($page-1)*$pageone;//偏移量

        $res = $Log  -> where($where)->order('id desc')->limit($pyl,$pageone) -> select();   //获取结果信息
        $data = ['map'=>$map,'data'=>$res];

        $this -> ajaxReturn($data,'JSON');

    }

}