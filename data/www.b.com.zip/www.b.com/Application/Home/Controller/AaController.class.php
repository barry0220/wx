<?php
namespace Home\Controller;
use Think\Controller;
class AaController extends Controller {
    public function index(){
    	// set_time_limit(0);//设置超时时间
$jssdk = new \Think\JSSDK("wx437115d1dddee775", "04052e7135e34a276e78d6866a379168");
$appid = "wx437115d1dddee775";  
$secret = "04052e7135e34a276e78d6866a379168";  
$token = $jssdk->getAccessToken();
      //根据openid和access_token查询用户信息  
      $openid = 'oWprtwKhrTeUJYR7bkn_lcCgTLnI';
      setcookie("access_token",$token,time()+7200);
      setcookie("opid",$openid,time()+7200);
    $data['touser']=$openid;
    $data['template_id']='KfHN6RMR-p2o1weXiLYTvEYoDJ7ykCvu2qXVpw2yKQY';
    $data['url']='http://bbxzs.bjydbb.cn/bb/index.php';
    $data['data']['keyword1']=array("value"=>"运动课程","color"=>"#173177");
    $data['data']['keyword2']=array("value"=>"李白","color"=>"#173177");
    $data['data']['keyword3']=array("value"=>"3","color"=>"#173177");
    $data['data']['keyword4']=array("value"=>"10","color"=>"#173177");
    $data['data']['keyword5']=array("value"=>'手机签到',"color"=>"#173177");
    $data['data']['remark']=array("value"=>'运动宝贝温馨提示',"color"=>"#173177");
    $data_string=json_encode($data);
    $url='https://api.weixin.qq.com/cgi-bin/message/template/send?access_token='.$token;
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
    curl_setopt($ch, CURLOPT_POSTFIELDS,$data_string);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
    'Content-Type: application/json',
    'Content-Length: ' . strlen($data_string))
    );
    curl_setopt($ch, CURLOPT_RETURNTRANSFER,true);
    $result = curl_exec($ch);
    $error=json_decode($result,true);
    if($error['errcode']!=0){
      $get_token_url='https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid='.$appid.'&secret='.$secret;
      $ch = curl_init();  
      curl_setopt($ch,CURLOPT_URL,$get_token_url);  
      curl_setopt($ch,CURLOPT_HEADER,0);  
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1 );  
      curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);  
      $res = curl_exec($ch);  
      curl_close($ch);  
      $json_obj = json_decode($res,true);  
      //根据openid和access_token查询用户信息  
      $token = $json_obj['access_token'];
      setcookie("access_token",$token,time()+7200);
      $url='https://api.weixin.qq.com/cgi-bin/message/template/send?access_token='.$token;
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
    curl_setopt($ch, CURLOPT_POSTFIELDS,$data_string);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
    'Content-Type: application/json',
    'Content-Length: ' . strlen($data_string))
    );
    curl_setopt($ch, CURLOPT_RETURNTRANSFER,true);
    $result = curl_exec($ch);
    }
    var_dump($result);
    }
}