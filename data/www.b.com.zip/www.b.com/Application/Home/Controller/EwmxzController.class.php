<?php
namespace Home\Controller;
use Think\Controller;
class EwmxzController extends Controller {
    //二维码下载
     public function index(){
     	$centre_id = $_GET['centre_id'];
      $erwm=M('wx_centre')->where("centre_id='$centre_id'")->field("ewm,centre")->find();
      $erm='http://www.yundongbaobei.cn'.$erwm['ewm'];
      $username=$erwm['centre'];
      header("Content-type: octet/stream");
      header("Content-disposition:attachment;filename=".$username.'.'.'png'.";");
      header("Content-Length:".filesize($erm));
      readfile($erm);
      exit;
     }
 }