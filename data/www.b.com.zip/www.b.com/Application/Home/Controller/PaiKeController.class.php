<?php
// 本类由系统自动生成，仅供测试用途
namespace Home\Controller;
use Think\Controller;
class PaiKeController extends CommonController {
    //快速排课
    public function index(){
        $centre_id 	=session("centre_id");		//中心ID
        //查询该中心拥有的所有排课的开始时间 生成课程查看按钮
        $kaishi = M('crm_kecheng')->where("status=1 and centre_id=$centre_id")->order('start_time')->field('start_time,end_time') ->select();
        foreach ($kaishi as $key => $value) {
            $start[]=$value['start_time'];
        }
        $arr=array_flip(array_flip($start));		//去掉重复的课程开始时间
        foreach ($arr as $kkk => $vvv){
            foreach ($kaishi as $k3=>$v3){
                if($v3['start_time'] == $vvv){
                    $se_time[$kkk] = $v3;
                    continue;
                }
            }
        }
        $se_time = array_slice($se_time,-3,3);  //截取最新的5次排课
        $this->assign('anjian',$se_time);		//把日期按钮传入页面，并且把开始日期，和结束日期拼入get传值中

        //查询该中心拥有的教室(排课基本信息)
        $c = M('wx_centre')->where("centre_id=".$centre_id)->field("jiaoshi,centre_id,centre")->find(); //查询中心拥有的教室id
        $jiao = M('flexo')->where("id in({$c['jiaoshi']})")->field('id,content')->select();				//通过教室ID 查询出教室名称
        $this->assign('jiao',$jiao);
        //查询出该中心所有的老师(排课基本信息)
        $t = M('xueyuan_baoming')->where('centre_id='.$centre_id." and gangwei='老师' and status=1")->field('user_id,username,centre_id')->select();
        $this->assign('t',$t);
        //查询出所有的公共课程和该中心自建的课程(排课基本信息)
        $k = M('crm_ke')->where("centre_id in(0,{$centre_id}) and status=1")->field('kc_id,kc_name,xiaohao')->select();
        $this->assign('k',$k);
        //查询该中心的排课修改记录(未审核的修改记录)
        $xiugai = M('crm_kecheng_r')->where("centre_id='{$centre_id}' and s_status=0")->field('y_start_time')->select();
        foreach ($xiugai as $k10=>$v10){
            $xiugai2[] = $v10['y_start_time'];
        }
        $this->assign('xiugai2',$xiugai2);
//        k($xiugai2);die;
        //查询及修改某次排课记录   id=中心ID  &n=中心名称  &ss=开始时间  &zz=周几 &jj=周几
        $a = I('get.');
        if($a['jj']){
            $j3 = strtotime($a['jj']);
            $s3 = strtotime($a['ss']);
            $a['zhou2'] = round(($j3-$s3)/604800,0);
        }
        //判断一键排课日期是否重复 1=不重复 9=重复 重复弹提示窗 判断没有使用一键排课 存入2
        if(!$a['cheng']){
            $a['cheng'] = 2;
        }
        $this->assign('cheng',$a['cheng']);

//        $a['zhou2'] = ($a['jj']-$a['ss']);
        $a['id'] = $centre_id;
        $this->assign('ar',$a);
//        k($t3);die;
        if($a['ss']){
            $start_time = $a['ss'];	//开始日期
            $b['biao1'] = "crm_kecheng as a";
            $b['biao2'] = "crm_ke as b on a.kc_id=b.kc_id";
            $b['biao3'] = "flexo as c on a.xuhao=c.id";
            $b['biao4'] = "xueyuan_baoming as d on a.user_id=d.user_id";
            $b['field'] = "a.*,b.kc_name,b.yueling,b.yueling2,c.content,d.username";
            $b['where'][] =	"a.status=1";
            $b['where'][] = "a.centre_id={$centre_id}";
            $b['where'][] = "a.start_time='{$start_time}'";
            $b['where'][] = "a.week='{$a['zz']}'";
            $b['order'] = "a.s_time";

            $w = D('HuiUser')->get_all($b);		//带条件查询管理费记录表
//            k($w);die;
            foreach ($w as $k=>$v){
                $ske[] = $v['s_time'];
            }
            $ske = array_unique($ske);			//去除数组中重复的值
            $ske = array_merge($ske);			//数组下标重写排序
            foreach ($w as $k=>$v){
                foreach ($ske as $kk=>$vv){
                    if($v['s_time'] == $vv){
                        $zu[$kk]['t'][0]=$v['s_time'];
                        $zu[$kk]['t'][1]=$v['x_time'];
                        $zu[$kk][$v['xuhao']] = $v;
                    }
                }
            }
            $this->assign('w',$zu);
        }

        $hanshu['len'] = count($jiao);          //获取教室数量
        $hanshu['shijian'] = count($zu);        //获取上课时间数量
        $this->assign('hanshu',$hanshu);
        
        $this->display();
    }
    //排课添加，修改 ajax（接口）
    public function addpk(){
        header("access-control-allow-origin:*");
        $a = I('post.');

//        $a['centre_id'] = 223;
//        $a['xuhao'] = 26;
//        $a['week'] = 2;
//        $a['kc_id'] = 18;
////        $a['pk_id'] = ;
//        $a['user_id'] = 3024;
//        $a['s_time'] = '09:00';
//        $a['x_time'] = '10:00';
//        $a['start_time'] = '2017-11-01';
//        $a['end_time'] = '2017-11-27';
//        $a['xiaoke'] = 1;


//        $this->ajaxReturn($a,'JSON');die;
        $pk = M('crm_kecheng');
        //判断排课ID是否存在，存在修改，不存在添加
        if($a['pk_id'] == ""){
            //添加新数据
            $a['create_name'] = session('user_id');
            $f = $pk->add($a);
            if($f){
                $w['as'] = 4;
                $w['k'] = $f;
            }else{
                $w['as'] = 0;
            }
        }else{

            //判断收到的数据，课程ID是否为0，课程ID为0 说明取消该次排课。
            if(!$a['kc_id']){
                $q1['status'] = 0;
                $ff = $pk->where("pk_id={$a['pk_id']}")->save($q1);
            }else{
                //已存在，修改老数据
                $mixinqing = $pk->field('gd_id,user_id')->find($a['pk_id']);
//                $this->ajaxReturn($a,'JSON');die;
                if($mixinqing['gd_id'] != '' && $mixinqing['user_id'] == $a['user_id']){
                    $f = 5;
                }else{
                    $f = $pk->save($a);
                }
            }
            if($ff){
                $w['as'] = 3;
                $w['k'] = '';
            }else if($f == 1){
                $w['as'] = 1;
                $w['k'] = $a['pk_id'];
            }else if($f == 5){
                $w['as'] = 5;
                $w['k'] = $a['pk_id'];
            }else{
                $w['as'] = 2;
                $w['k'] = $a['pk_id'];
            }
        }
        $this->ajaxReturn($w,'JSON');
    }
    //批量修改上下课时间（接口）
    public function shijian(){
        header("access-control-allow-origin:*");
        $t = I('post.');

//        $a['centre_id'] = 223;          //中心ID
//        $a['week'] = 1;                 //周几
//        $a['y_s_time'] = '09:00';       //原上课时间
//        $a['y_x_time'] = '10:00';       //原下课时间
//        $a['s_time'] = '14:00';         //新上课时间
//        $a['x_time'] = '15:00';         //新下课时间
//        $a['start_time'] = '2017-11-01';//开始日期
//        $a['end_time'] = '2017-11-27';  //结束日期

        $ff = M('crm_kecheng')->where("centre_id='{$t['centre_id']}' and start_time = '{$t['start_time']}' and end_time = '{$t['end_time']}' and s_time = '{$t['y_s_time']}' and x_time = '{$t['y_x_time']}' and week = '{$t['week']}' ")->save($t);
        $this->ajaxReturn($ff,'JSON');
    }
    //批量修改排课开始日期和结束日期
    public function riqi(){
        $t = I('post.');
//        k($t);die;
        $t['centre_id']	=session("centre_id");		//中心ID
        $t['t_time']	=date("Y-m-d H:m:s");		        //排课修改日期
        $t['t_user_id']	=session('user_id');		//排课修改人

        $kaishi = M('crm_kecheng')->where("status=1 and centre_id='{$t['centre_id']}' and start_time!='{$t['y_start_time']}'")->order('start_time desc')->field('start_time,end_time')->group('start_time')->select();
//        k($kaishi);die;
        $cheng = 1;
        if($t['x_start_time'] == $t['y_start_time'] and $t['x_end_time'] == $t['y_end_time']){
            $cheng = 9;
        }
        foreach ($kaishi as $k2=>$v2){
            if(!($t['x_end_time'] <= $v2['start_time'] || $v2['end_time'] <= $t['x_start_time'])){
                $cheng = 9;
            }
        }

        if($cheng == 1){
            M('crm_kecheng_r')->add($t);
        }

        $this->redirect("index?cheng={$cheng}");

    }
    //一键排课
    public function yijian(){
        $t = I('post.');                        //获取新的排课日期
//        k($t);
        $centre_id 	=session("centre_id");		//中心ID
        $user_id = session('user_id');          //当前登录人ID

        //查询该中心拥有的所有排课的开始时间 生成课程查看按钮
        $kaishi = M('crm_kecheng')->where("status=1 and centre_id='{$centre_id}'")->order('start_time desc')->field('start_time,end_time')->group('start_time')->select();
//        k($kaishi);die;
        $cheng = 1;
        foreach ($kaishi as $k2=>$v2){
            if(!($t['t_end_time'] <= $v2['start_time'] || $v2['end_time'] <= $t['t_start_time'])){
                $cheng = 9;
            }
        }
//        k($kaishi);die;
        if($cheng != 9){
            $ke = M("crm_kecheng")->where("status=1 and centre_id='{$centre_id}' and start_time='{$kaishi[0]['start_time']}' and end_time='{$kaishi[0]['end_time']}'")->select();
            foreach ($ke as $k=>$v){
                $xin['start_time'] = $t['t_start_time'];
                $xin['end_time'] = $t['t_end_time'];
                $xin['s_time'] = $v['s_time'];
                $xin['x_time'] = $v['x_time'];
                $xin['week'] = $v['week'];
                $xin['kc_id'] = $v['kc_id'];
                $xin['user_id'] = $v['user_id'];
                $xin['xuhao'] = $v['xuhao'];
                $xin['centre_id'] = $v['centre_id'];
                $xin['xiaoke'] = $v['xiaoke'];
                $xin['create_name'] = $user_id;
                $xin['source'] = "一键排课";
                M('crm_kecheng')->add($xin);
                $cheng = 1;
            }
        }
        $this->redirect("index?cheng={$cheng}");
    }


    //选课
    public function xuan(){
        $centre_id 	=session("centre_id");		//中心ID
        $a = I('get.');                 //获取页面参数

        //用户是否添加固定班
        if($a['pk_id']){
            //把会员ID加入排课表固定班字段
            $pk = M('crm_kecheng')->field('pk_id,gd_id')->find($a['pk_id']);

            //判断已选固定班学生不超过13个
            $w4 = count(explode(",",$pk['gd_id']));
            if($w4 >= 14){
                $this->assign('tan1',2);//把数据传入页面
                unset($a['pk_id']);
            }else{
                if(!$pk['gd_id']){
                    $pk['gd_id'] = $a['id'];
                }else{
                    $pk['gd_id'] = $pk['gd_id'].",".$a['id'];
                }
                $pp2 = M('crm_kecheng')->save($pk);

                if($pp2){
                    //把排课ID加入会员表固定班字段
                    $pk2 = M('wx_user')->field('user_id,gd_id')->find($a['id']);
                    if(!$pk2['gd_id']){
                        $pk2['gd_id'] = $a['pk_id'];
                    }else{
                        $pk2['gd_id'] = $pk2['gd_id'].",".$a['pk_id'];
                    }
                    $pp = M('wx_user')->save($pk2);

                    //判断添加固定班成功，回传一个成功标示，同时删除排课ID
                    if($pp){
                        $this->assign('tan1',1);//把数据传入页面
                        unset($a['pk_id']);
                    }
                }
            }
        }

        //用户是否取消固定班
        if($a['q_id']){
            //把排课表固定班字段中的会员ID删除
            $pk = M('crm_kecheng')->field('pk_id,gd_id')->find($a['q_id']);  //查询排课表  用户ID
            $u = explode(",",$pk['gd_id']);     //字符串转成数组
            foreach ($u as $k=>$v){
                if($v != $a['id']){
                    $user[] = $v;               //循环排除该用户
                }
            }
            $pk['gd_id'] = implode(",",$user);  //数组转成字符串
            M('crm_kecheng')->save($pk);

            //把会员表固定班字段的排课ID删除
            $pk2 = M('wx_user')->field('user_id,gd_id')->find($a['id']);    //查询用户表  排课ID
            $u2 = explode(",",$pk2['gd_id']);   //字符串转成数组

            foreach ($u2 as $k=>$v){
                if($v != $a['q_id']){
                    $kecheng[] = $v;               //循环排除该课程
                }
            }
            $pk2['gd_id'] = implode(",",$kecheng);
            $pp2 = M('wx_user')->save($pk2);
            //判断添加固定班成功，回传一个成功标示，同时删除排课ID
            if($pp2){
                $this->assign('tan2',1);//把数据传入页面
                unset($a['q_id']);
            }
        }

        //判断用户是否搜索
        if($a['name']){
            //通过宝宝信息查出符合条件的宝宝
            $re=M('wx_user as a')   ->join("crm_kjilu as b on a.jl_id=b.jl_id")
                ->field('a.*,b.y_keshi')
                ->where("a.belong={$centre_id} and a.vip = 1 and a.status = 1 and b.y_keshi >= 1 and (a.baobao_name like '%{$a['name']}%' || a.baobao_name2 like '%{$a['name']}%')")
                ->select();
//            $sql="SELECT * FROM wx_user where (baobao_name like '%{$a['name']}%' || baobao_name2 like '%{$a['name']}%') and belong={$centre_id}";
//            $re=M()->query($sql);
//            k($re);die;
            if($re){
                //判断查到信息后 通过宝宝生日 计算 宝宝月龄 并拼接到数据里
                foreach ($re as $k => $v){
                    $d=time()-strtotime($v['baobao_birthday']);
                    $e=$d/2592000;      //一个月的时间，单位秒
                    $f=round($e);       //月龄取整
                    $re[$k]['yueling'] = $f;
                    if($v['user_id'] == $a['id']){
                        $bao = $re[$k];
                    }
                }

                if(!$re[1]){
                    $bao = $re[0];
                }
                $this->assign('data',$re);//把宝宝信息传入页面
                //判断如果查询结果只有是一个宝宝或者宝宝ID存在 直接查出宝宝排课记录，
                if($bao){
                    $data = date("Y-m-d");
                    $b['biao1'] = "crm_kecheng as a";                                       //主表排课记录表
                    $b['biao2'] = "crm_ke as b on a.kc_id=b.kc_id";                         //课表 查询课程名称
                    $b['biao3'] = "flexo as c on a.xuhao=c.id";                             //多功能表 查询教室名称
                    $b['biao4'] = "xueyuan_baoming as d on a.user_id=d.user_id";            //报名表 查询老师名称
                    $b['field'] = "a.*,b.kc_name,b.yueling,b.yueling2,c.content,d.username";//需要查询的字段
                    $b['where'][] =	"a.status=1";                                           //状态正常的排课记录 未删除的
                    $b['where'][] = "a.centre_id={$centre_id}";                             //该中心的
                    $b['where'][] = "a.end_time>='{$data}'";                                //没有结束的
                    $b['where'][] = "b.yueling <= {$bao['yueling']}";       //符合月龄的（课程开始月龄小于等于宝宝月龄）
                    $b['where'][] = "b.yueling2 >= {$bao['yueling']}";      //符合月龄的（课程结束月龄大于等于宝宝月龄）
                    $b['order'] = "a.s_time";                               //排序（课程开始时间）
                    $w = D('HuiUser')->get_all($b);		                    //带条件排课记录表
//                    k($w);
                    $you = explode(",",$bao['gd_id']);                      //把宝宝的固定班转成数组

                    //把已选固定班和未选的分别导入页面
                    foreach ($w as $k=>$v){
                        $v['bao_id'] = $bao['user_id'];
                        if(in_array($v['pk_id'],$you)){
                            $yi[] = $v;
                        }else{
                            $ke[] = $v;
                        }
                    }
//                                    k($ke);die;
                    $this->assign('wei',$ke);//把宝宝信息传入页面
                    $this->assign('yi',$yi);//把宝宝信息传入页面
                }
            }else{
                $this->assign('wu',2);      //页面参数回传
            }
        }
//        k($a);die;
        $this->assign('ar',$a);      //页面参数回传
        $this->display();
    }
    //查看选课（自己版）
    public function cha(){
        $centre_id 	=session("centre_id");		//中心ID
        //查询该中心拥有的所有排课的开始时间 生成课程查看按钮
        $kaishi = M('crm_kecheng')->where("status=1 and centre_id=$centre_id")->order('start_time')->field('start_time,end_time')->select();
        foreach ($kaishi as $key => $value) {
            $start[]=$value['start_time'];
        }
        $arr=array_flip(array_flip($start));		//去掉重复的课程开始时间
        foreach ($arr as $kkk => $vvv){
            foreach ($kaishi as $k3=>$v3){
                if($v3['start_time'] == $vvv){
                    $se_time[$kkk] = $v3;
                    continue;
                }
            }
        }
        $se_time = array_slice($se_time,-3,3);  //截取最新的5次排课
        $this->assign('anjian',$se_time);		//把日期按钮传入页面，并且把开始日期，和结束日期拼入get传值中

        //查询该中心拥有的教室(排课基本信息)
        $c = M('wx_centre')->where("centre_id=".$centre_id)->field("jiaoshi,centre_id,centre")->find(); //查询中心拥有的教室id
        $jiao = M('flexo')->where("id in({$c['jiaoshi']})")->field('id,content')->select();				//通过教室ID 查询出教室名称
        $this->assign('jiao',$jiao);
        //查询出该中心所有的老师(排课基本信息)
        $t = M('xueyuan_baoming')->where('centre_id='.$centre_id." and gangwei='老师' and status=1")->field('user_id,username,centre_id')->select();
        $this->assign('t',$t);
        //查询出所有的公共课程和该中心自建的课程(排课基本信息)
        $k = M('crm_ke')->where("centre_id in(0,{$centre_id}) and status=1")->field('kc_id,kc_name,xiaohao')->select();
        $this->assign('k',$k);
        //查询该中心的排课修改记录(未审核的修改记录)
        $xiugai = M('crm_kecheng_r')->where("centre_id='{$centre_id}' and s_status=0")->field('y_start_time')->select();
        foreach ($xiugai as $k10=>$v10){
            $xiugai2[] = $v10['y_start_time'];
        }
        $this->assign('xiugai2',$xiugai2);
//        k($xiugai2);die;
        //查询及修改某次排课记录   id=中心ID  &n=中心名称  &ss=开始时间  &zz=周几 &jj=周几
        $a = I('get.');
        if($a['jj']){
            $j3 = strtotime($a['jj']);
            $s3 = strtotime($a['ss']);
            $a['zhou2'] = round(($j3-$s3)/604800,0);
        }
        //判断一键排课日期是否重复 1=不重复 9=重复 重复弹提示窗 判断没有使用一键排课 存入2
        if(!$a['cheng']){
            $a['cheng'] = 2;
        }
        $this->assign('cheng',$a['cheng']);

//        $a['zhou2'] = ($a['jj']-$a['ss']);
        $a['id'] = $centre_id;
        $this->assign('ar',$a);
//        k($t3);die;
        if($a['ss']){
            $start_time = $a['ss'];	//开始日期
            $b['biao1'] = "crm_kecheng as a";
            $b['biao2'] = "crm_ke as b on a.kc_id=b.kc_id";
            $b['biao3'] = "flexo as c on a.xuhao=c.id";
            $b['biao4'] = "xueyuan_baoming as d on a.user_id=d.user_id";
            $b['field'] = "a.*,b.kc_name,b.yueling,b.yueling2,c.content,d.username,length(a.gd_id)-length(REPLACE(a.gd_id,',','')) as gu";
            $b['where'][] =	"a.status=1";
            $b['where'][] = "a.centre_id={$centre_id}";
            $b['where'][] = "a.start_time='{$start_time}'";
            $b['where'][] = "a.week='{$a['zz']}'";
            $b['order'] = "a.s_time";

            $w = D('HuiUser')->get_all($b);		//带条件查询管理费记录表


            foreach ($w as $k=>$v){
                $ske[] = $v['s_time'];
                if($v['gu'] === '0' || $v['gu'] > 0){
                    $w[$k]['guding'] = $v['gu']+1;
                }else{
                    $w[$k]['guding'] = 0;
                }
            }
            $ske = array_unique($ske);			//去除数组中重复的值
            $ske = array_merge($ske);			//数组下标重写排序
            foreach ($w as $k=>$v){
                foreach ($ske as $kk=>$vv){
                    if($v['s_time'] == $vv){
                        $zu[$kk]['t'][0]=$v['s_time'];
                        $zu[$kk]['t'][1]=$v['x_time'];
                        $zu[$kk][$v['xuhao']] = $v;
                    }
                }
            }
            $this->assign('w',$zu);
        }
//        k($zu);die;

        $hanshu['len'] = count($jiao);          //获取教室数量
        $hanshu['shijian'] = count($zu);        //获取上课时间数量
        $this->assign('hanshu',$hanshu);

        $this->display();
    }
    //查看选课（领导版）
    public function kan(){
        $centre_id 	=session("centre_id");		//中心ID

        //查询该中心拥有的所有排课的开始时间 生成课程查看按钮
        $kaishi = M('crm_kecheng')->where("status=1 and centre_id=$centre_id")->order('start_time')->field('start_time,end_time') ->select();
        foreach ($kaishi as $key => $value) {
            $start[]=$value['start_time'];
        }
        $arr=array_flip(array_flip($start));		//去掉重复的课程开始时间
        foreach ($arr as $kkk => $vvv){
            foreach ($kaishi as $k3=>$v3){
                if($v3['start_time'] == $vvv){
                    $se_time[$kkk] = $v3;
                    continue;
                }
            }
        }
        $se_time = array_slice($se_time,-3,3);  //截取最新的5次排课
        $this->assign('anjian',$se_time);		//把日期按钮传入页面，并且把开始日期，和结束日期拼入get传值中

        //查询该中心拥有的教室(排课基本信息)
        $c = M('wx_centre')->where("centre_id=".$centre_id)->field("jiaoshi,centre_id,centre")->find(); //查询中心拥有的教室id
        $jiao = M('flexo')->where("id in({$c['jiaoshi']})")->field('id,content')->select();				//通过教室ID 查询出教室名称
        $this->assign('jiao',$jiao);

        //查询该中心的排课修改记录(未审核的修改记录)
        $xiugai = M('crm_kecheng_r')->where("centre_id='{$centre_id}' and s_status=0")->field('y_start_time')->select();
        foreach ($xiugai as $k10=>$v10){
            $xiugai2[] = $v10['y_start_time'];
        }
        $this->assign('xiugai2',$xiugai2);

        $a = I('get.');
//        k($a);die;

        $this->display();
    }
    //根据课程周期查询上课时间
    public function shang(){
        $t = I('post.');
        $centre_id 	=session("centre_id");		//中心ID
        //查询该中心拥有的所有排课的开始时间 生成课程查看按钮
        $kaishi = M('crm_kecheng')->where("status=1 and centre_id='{$centre_id}' and start_time='{$t['start_time']}' and end_time='{$t['end_time']}' and week='{$t['week']}'")->order('s_time')->field('s_time,x_time')->group('s_time,x_time')->select();

        $this->ajaxReturn($kaishi,'JSON');
    }
    //单课详情（接口）
    public function dan(){
        header("access-control-allow-origin:*");
        $t = I('post.pk_id');
//        $t = "6882";

        $w =  M('crm_kecheng as a') ->join("left join crm_ke as b on a.kc_id=b.kc_id")
                                    ->join("left join flexo as c on a.xuhao=c.id")
                                    ->join("left join xueyuan_baoming as d on a.user_id=d.user_id")
                                    ->field("a.pk_id,a.gd_id,b.kc_name,concat(a.start_time,' 到 ',a.end_time) as zhouqi,concat(a.xiaoke,'节') as xiaoke,b.kc_name,concat(b.yueling,' - ',b.yueling2,'个月') as yuelingz,c.content,d.username,length(a.gd_id)-length(REPLACE(a.gd_id,',','')) as gu")
                                    ->getByPkId($t);

        if($w['gd_id'] != null){
            $w['guding'] = $w['gu']+1;
            $w2 = M('wx_user')->where("user_id in({$w['gd_id']})")->field("user_id,baobao_name,baobao_name2")->select();
        }else{
            $w['guding'] = 0;
        }

        $www['ge'] = $w;
        $www['ren'] = $w2;
//        k($www);die;
        $this->ajaxReturn($www,'JSON');
    }
    //打印签到表（接口）
    public function dayinq(){
        header("access-control-allow-origin:*");
        $t = I('post.pk_id');
//        $t = "7271,7270,7269";
//        $t = "7086,6882";
//        $t = "7266";
        $w =  M('crm_kecheng as a') ->join("left join crm_ke as b on a.kc_id=b.kc_id")
            ->join("left join flexo as c on a.xuhao=c.id")
            ->join("left join xueyuan_baoming as d on a.user_id=d.user_id")
            ->field("a.pk_id,a.end_time,a.start_time,a.week,a.s_time,a.gd_id,b.kc_name,concat(a.start_time,' 到 ',a.end_time) as zhouqi,concat(a.xiaoke,'节') as xiaoke,b.kc_name,concat(b.yueling,' - ',b.yueling2,'个月') as yuelingz,c.content,d.username,length(a.gd_id)-length(REPLACE(a.gd_id,',','')) as gu")
            ->where("pk_id in($t)")
            ->select();
        $a = array();
        foreach ($w as $k=>$v){
            if($v['week'] == 1){
                $z = "周一";
            }elseif($v['week'] == 2){
                $z = "周二";
            }elseif($v['week'] == 3){
                $z = "周三";
            }elseif($v['week'] == 4){
                $z = "周四";
            }elseif($v['week'] == 5){
                $z = "周五";
            }elseif($v['week'] == 6){
                $z = "周六";
            }elseif($v['week'] == 7){
                $z = "周日";
            }
            $a[$k]['biao'] = $v['kc_name']."（".$v['yuelingz']."）".$z." ".$v['s_time']." ".$v['content']." ".$v['username'];
            $w2 = M('wx_user')->where("user_id in({$v['gd_id']})")->field("baobao_name,baobao_name2,name1,name2,name3,name4,name5,name6,phone1,phone2,phone3,phone4,phone5,phone6")->select();
            foreach ($w2 as $k2=>$v2 ){
                for ($i=1;$i<7;$i++){
                    if($v2['phone'.$i] != ""){
                        $w2[$k2]['namez'] = $v2['name'.$i];
                        $w2[$k2]['phonez']= $v2['phone'.$i];
                        break;
                    }
                }
            }


            $t1 = $v['start_time'];
            $m1 = date("m月d日",strtotime($t1));
            for ($j=1;$j<17;$j++){
                $tx[] = $m1;
                $t1 = date("Y-m-d",strtotime("+1 week",strtotime($t1)));
                if($t1 > $v['end_time']){
                    break;
                }
                $m1 = $t1;
                $m1 = date("m月d日",strtotime($m1));
            }
            $a[$k]['ri'] = $tx;
            for ($ks=0;$ks<16;$ks++){
                $w3[$ks]['xu'] = $ks+1;
                if($w2[$ks]['baobao_name'] and $w2[$ks]['baobao_name2']){
                    $w3[$ks]['baobao_name'] = $w2[$ks]['baobao_name']." -- ".$w2[$ks]['baobao_name2'];
                }elseif($w2[$ks]['baobao_name']){
                    $w3[$ks]['baobao_name'] = $w2[$ks]['baobao_name'];
                }else{
                    $w3[$ks]['baobao_name'] = "";
                }

//                $w3[$ks]['baobao_name2'] = ;
                if($w2[$ks]['namez']){
                    $w3[$ks]['namez'] = $w2[$ks]['namez'];
                }else{
                    $w3[$ks]['namez'] = "";
                }
                if($w2[$ks]['phonez']){
                    $w3[$ks]['phonez'] = $w2[$ks]['phonez'];
                }else{
                    $w3[$ks]['phonez'] = "";
                }
            }
            $a[$k]['ren'] = $w3;

            unset($tx);
            unset($w2);
        }

        $zu=0;
        foreach ($a as $kk=>$vv){
            if(count($vv['ri'])>6){
               $yu = array_chunk($vv['ri'],6);
            }
            if(count($yu)>1){
                foreach ($yu as $kw=>$vw){
                    $aaa[$zu]['biao'] = $vv['biao'];
                    $aaa[$zu]['ri'] = $vw;
                    $aaa[$zu]['ren'] = $vv['ren'];
                    $zu++;
                }
            }else{
                $aaa[$zu]['biao'] = $vv['biao'];
                $aaa[$zu]['ri'] = $vv['ri'];
                $aaa[$zu]['ren'] = $vv['ren'];
                $zu++;
            }

        }
//        k($aaa);
        $this->ajaxReturn($aaa,'JSON');
    }
    //取消固定班（接口）
    public function gdq(){
        header("access-control-allow-origin:*");
        $t = I('post.');

//        $t['pk_id'] = "6882";
//        $t['user_id'] = "3740";

        $a = M('crm_kecheng')->field("pk_id,gd_id")->find($t['pk_id']);

        $u = explode(",",$a['gd_id']);     //字符串转成数组
        foreach ($u as $k=>$v){
            if($v != $t['user_id']){
                $user[] = $v;               //循环排除该用户
            }
        }
        $a['gd_id'] = implode(",",$user);  //数组转成字符串
        $st = M('crm_kecheng')->save($a);  //修改排课表里固定班ID

        $pk2 = M('wx_user')->field('user_id,gd_id')->find($t['user_id']);    //查询用户表  排课ID
        $u2 = explode(",",$pk2['gd_id']);   //字符串转成数组

        foreach ($u2 as $k=>$v){
            if($v != $t['pk_id']){
                $kecheng[] = $v;               //循环排除该课程
            }
        }
        $pk2['gd_id'] = implode(",",$kecheng);
        $pp2 = M('wx_user')->save($pk2);

        $ww = $st && $pp2?1:2;
        echo $ww;
    }


    //选课(接口1)
    public function xuan2(){
        header("access-control-allow-origin:*");
        $t = I('post.');				//获取查询条件

//        $t['id'] = "2268";              //测试职员ID
//        $t['name'] = '豆豆';              //测试职员ID

        //返回 某个职员的 姓名 ID 中心ID 角色 岗位 电话
        $user_all = $this->ChaUser($t['id']);
//        k($user_all);die;

        $centre_id = $user_all['centre_id'];		//中心ID
//        $a = I('get.');                 //获取页面参数

        //通过宝宝姓名模糊查询 宝宝信息：大名 小名 月龄 家长姓名
        $re=M('wx_user as a')   ->join("crm_kjilu as b on a.jl_id=b.jl_id")
                                ->field('a.user_id,a.gd_id,b.centre_id,a.baobao_name,a.baobao_name2,a.name1,a.name2,a.name3,a.name4,a.name5,a.name6,b.y_keshi,floor((unix_timestamp(now())-unix_timestamp(a.baobao_birthday))/2592000) as yue')
                                ->where("a.belong={$centre_id} and a.vip = 1 and a.status = 1 and b.y_keshi >= 1 and (a.baobao_name like '%{$t['name']}%' || a.baobao_name2 like '%{$t['name']}%')")
                                ->select();
        //判断宝宝是否存在 不存在返回
        if($re){
            $fan['status'] = 1;   //查询结果正常
            //判断查到信息后判断 哪个家长姓名是存在的
            foreach ($re as $k => $v){
                if($v['name1']){
                    $re[$k]['jz_name'] = $v['name1'];
                }elseif($v['name2']){
                    $re[$k]['jz_name'] = $v['name2'];
                }elseif($v['name3']){
                    $re[$k]['jz_name'] = $v['name3'];
                }elseif($v['name4']){
                    $re[$k]['jz_name'] = $v['name4'];
                }elseif($v['name5']){
                    $re[$k]['jz_name'] = $v['name5'];
                }elseif($v['name6']){
                    $re[$k]['jz_name'] = $v['name6'];
                }
            }

            //判断查询结果是几个宝宝
            if(!$re[1]){
                $bao = $re[0];
            }
            $fan['bao'] = $re;      //把查到的宝宝信息拼入数组
            //判断如果查询结果只有是一个宝宝或者宝宝ID存在 直接查出宝宝排课记录，
            if($bao){
                $data = date("Y-m-d");
                $b['biao1'] = "crm_kecheng as a";                                       //主表排课记录表
                $b['biao2'] = "crm_ke as b on a.kc_id=b.kc_id";                         //课表 查询课程名称
                $b['biao3'] = "flexo as c on a.xuhao=c.id";                             //多功能表 查询教室名称
                $b['biao4'] = "xueyuan_baoming as d on a.user_id=d.user_id";            //报名表 查询老师名称
                $b['field'] = "a.*,b.kc_name,b.yueling,b.yueling2,c.content,d.username,b.gdb";//需要查询的字段
                $b['where'][] =	"a.status=1";                                           //状态正常的排课记录 未删除的
                $b['where'][] = "a.centre_id={$centre_id}";                             //该中心的
                $b['where'][] = "a.end_time>='{$data}'";                                //没有结束的
                $b['where'][] = "b.yueling <= {$bao['yue']}";       //符合月龄的（课程开始月龄小于等于宝宝月龄）
                $b['where'][] = "b.yueling2 >= {$bao['yue']}";      //符合月龄的（课程结束月龄大于等于宝宝月龄）
                $b['order'] = "a.s_time";                               //排序（课程开始时间）
                $w = D('HuiUser')->get_all($b);		                    //带条件排课记录表
//                    k($w);
                $you = explode(",",$bao['gd_id']);                      //把宝宝的固定班转成数组

                //把已选固定班和未选的分别导入页面
                foreach ($w as $k=>$v){
                    //计算教室已有固定班学生数量
                    $yiXuan = explode(",",$v['gd_id']);
                    $yiShu = count($yiXuan);
                    //判断固定班是否已满 已有固定班人数和课程固定班人数
                    if($v['gdb'] >= $yiShu){
                        $v['man'] = 1;          //未满
                    }else{
                        $v['man'] = 2;          //已满
                    }

                    //循环替换周几的数字
                    if($v['week'] == 1){
                        $v['week'] = "星期一";
                    }elseif($v['week'] == 2){
                        $v['week'] = "星期二";
                    }elseif($v['week'] == 3){
                        $v['week'] = "星期三";
                    }elseif($v['week'] == 4){
                        $v['week'] = "星期四";
                    }elseif($v['week'] == 5){
                        $v['week'] = "星期五";
                    }elseif($v['week'] == 6){
                        $v['week'] = "星期六";
                    }elseif($v['week'] == 7){
                        $v['week'] = "星期天";
                    }

                    $v['bao_id'] = $bao['user_id'];
                    if(in_array($v['pk_id'],$you)){
                        $yi[] = $v;
                    }else{
                        $ke[] = $v;
                    }
                }
                $fan['wei'] = $ke;
                $fan['yi'] = $yi;
            }
        }else{
            $fan['status'] = 2;   //查无此人
        }
//        k($fan);die;
        $this->ajaxReturn($fan,'JSON');
    }
    //选课（接口2 多个宝宝 点选宝宝）
    public function xuan3(){
        header("access-control-allow-origin:*");
        $t = I('post.');				    //获取查询条件
        $centre_id = $t['centre_id'];       //中心ID

//        $centre_id = '223';
//        $t['user_id'] = '10427';            //宝宝ID

        $bao=M('wx_user')->field('user_id,gd_id,belong as centre_id,baobao_name,baobao_name2,name1,name2,name3,name4,name5,name6,floor((unix_timestamp(now())-unix_timestamp(baobao_birthday))/2592000) as yue')
                         ->find($t['user_id']);

//        k($bao);die;
        if($bao){
            $data = date("Y-m-d");
            $b['biao1'] = "crm_kecheng as a";                                       //主表排课记录表
            $b['biao2'] = "crm_ke as b on a.kc_id=b.kc_id";                         //课表 查询课程名称
            $b['biao3'] = "flexo as c on a.xuhao=c.id";                             //多功能表 查询教室名称
            $b['biao4'] = "xueyuan_baoming as d on a.user_id=d.user_id";            //报名表 查询老师名称
            $b['field'] = "a.*,b.kc_name,b.yueling,b.yueling2,c.content,d.username,b.gdb";//需要查询的字段
            $b['where'][] =	"a.status=1";                                           //状态正常的排课记录 未删除的
            $b['where'][] = "a.centre_id={$centre_id}";                             //该中心的
            $b['where'][] = "a.end_time>='{$data}'";                                //没有结束的
            $b['where'][] = "b.yueling <= {$bao['yue']}";       //符合月龄的（课程开始月龄小于等于宝宝月龄）
            $b['where'][] = "b.yueling2 >= {$bao['yue']}";      //符合月龄的（课程结束月龄大于等于宝宝月龄）
            $b['order'] = "a.s_time";                               //排序（课程开始时间）
            $w = D('HuiUser')->get_all($b);		                    //带条件排课记录表
//                    k($w);die;
            $you = explode(",",$bao['gd_id']);                      //把宝宝的固定班转成数组

            //把已选固定班和未选的分别导入页面
            foreach ($w as $k=>$v){
                //计算教室已有固定班学生数量
                $yiXuan = explode(",",$v['gd_id']);
                $yiShu = count($yiXuan);
                //判断固定班是否已满 已有固定班人数和课程固定班人数
                if($v['gdb'] >= $yiShu){
                    $v['man'] = 1;          //未满
                }else{
                    $v['man'] = 2;          //已满
                }

                //循环替换周几的数字
                if($v['week'] == 1){
                    $v['week'] = "星期一";
                }elseif($v['week'] == 2){
                    $v['week'] = "星期二";
                }elseif($v['week'] == 3){
                    $v['week'] = "星期三";
                }elseif($v['week'] == 4){
                    $v['week'] = "星期四";
                }elseif($v['week'] == 5){
                    $v['week'] = "星期五";
                }elseif($v['week'] == 6){
                    $v['week'] = "星期六";
                }elseif($v['week'] == 7){
                    $v['week'] = "星期天";
                }

                $v['bao_id'] = $bao['user_id'];
                if(in_array($v['pk_id'],$you)){
                    $yi[] = $v;
                }else{
                    $ke[] = $v;
                }
            }
            $fan['status'] = 1;
            $fan['wei'] = $ke;
            $fan['yi'] = $yi;
        }else{
            $fan['status'] = 2;         //暂无课程
        }
//        k($fan);die;
        $this->ajaxReturn($fan,'JSON');
    }
    //宝宝添加固定班（接口3）
    public function addgd(){
        header("access-control-allow-origin:*");
        $t = I('post.');				//获取查询条件

//        $t['pk_id'] = '6882';           //排课ID
//        $t['id']    = '3841';          //宝宝ID
        //把会员ID加入排课表固定班字段
        $pkx = M('crm_kecheng as a') ->join("left join crm_ke as b on a.kc_id=b.kc_id")
                                    ->field('a.pk_id,a.gd_id,b.gdb')
                                    ->where("a.pk_id = '{$t['pk_id']}'")
                                    ->find();
        $pk = $pkx;
//        k($pk);die;
        //判断已选固定班学生不超过13个
        $gu = explode(",",$pk['gd_id']);
        $w4 = count($gu);
        if($w4 >= $pk['gdb']){
            $this->ajaxReturn(3,'JSON');die;        //固定班已满
        }else{
            //判断之前是否有固定班记录
            if(!$pk['gd_id']){
                $pk['gd_id'] = $t['id'];
            }else{
                //循环过滤重复ID （增加一层过滤，预防重复调用添加重复的固定班ID）
                foreach ($gu as $k9=>$v9){
                    if($v9 != $t['id']){
                        $vr[] = $v9;
                    }
                }
                $vr[] = $t['id'];
                $vt = implode(",",$vr);
                $pk['gd_id'] = $vt;
            }
            $pp2 = M('crm_kecheng')->save($pk);

//            if($pp2){
                //把排课ID加入会员表固定班字段
                $pk2 = M('wx_user')->field('user_id,gd_id')->find($t['id']);
                if(!$pk2['gd_id']){
                    $pk2['gd_id'] = $t['pk_id'];
                }else{
                    //循环过滤重复ID
                    foreach ($pk2 as $k91=>$v91){
                        if($v91 != $t['pk_id']){
                            $vr2[] = $v91;
                        }
                    }
                    $vr2[] = $t['pk_id'];
                    $vt2 = implode(",",$vr2);
                    $pk2['gd_id'] = $vt2;
                }
                $pp = M('wx_user')->save($pk2);

                //判断添加固定班成功，回传一个成功标示，同时删除排课ID
//                if($pp){
                    $this->ajaxReturn(1,'JSON');die;          //固定班添加成功
//                }else{
                        //判断同步修改二表失败，回退一表已修改数据，保证两表数据相同
//                        M('crm_kecheng')->save($pkx);
//                }
//            }
//            $this->ajaxReturn(2,'JSON');die;         //固定班添加失败
        }
    }
    //宝宝取消固定班
    public function updgd(){
        header("access-control-allow-origin:*");
        $t = I('post.');				//获取查询条件

//        $t['pk_id'] = '6882';           //排课ID
//        $t['id']    = '10427';          //宝宝ID

        //把排课表固定班字段中的会员ID删除
        $pk = M('crm_kecheng')->field('pk_id,gd_id')->find($t['pk_id']);  //查询排课表  用户ID
        $u = explode(",",$pk['gd_id']);     //字符串转成数组
        foreach ($u as $k=>$v){
            if($v != $t['id']){
                $user[] = $v;               //循环排除该用户
            }
        }
        $pk['gd_id'] = implode(",",$user);  //数组转成字符串
        M('crm_kecheng')->save($pk);

        //把会员表固定班字段的排课ID删除
        $pk2 = M('wx_user')->field('user_id,gd_id')->find($t['id']);    //查询用户表  排课ID
        $u2 = explode(",",$pk2['gd_id']);   //字符串转成数组

        foreach ($u2 as $k=>$v){
            if($v != $t['pk_id']){
                $kecheng[] = $v;               //循环排除该课程
            }
        }
        $pk2['gd_id'] = implode(",",$kecheng);
        $pp2 = M('wx_user')->save($pk2);
        //判断添加固定班成功，回传一个成功标示，同时删除排课ID
//        if($pp2){
            $this->ajaxReturn(1,'JSON');die;          //固定班添加成功
//        }
    }

    //查看选课（接口）
    public function cha2(){
        header("access-control-allow-origin:*");
        $t = I('post.');						    //获取查询条件

//        $t['id'] = "2268";        //测试职员ID

        //返回 某个职员的 姓名 ID 中心ID 角色 岗位 电话
        $user_all = $this->ChaUser($t['id']);
        //判断登录人是否有中心ID
        if(!$user_all['centre_id']){
            $fan['status'] = 8;
            $this->ajaxReturn($fan,'JSON');die;
        }

        $centre_id 	=$user_all['centre_id'];		//中心ID

        //查询该中心拥有的所有排课的开始时间 生成课程查看按钮
        $an = M('crm_kecheng')->where("status=1 and centre_id=$centre_id")->order('start_time desc')->field('start_time,end_time')->group("start_time,end_time")->limit(3)->select();

        //查询该中心拥有的教室(排课基本信息)
        $c = M('wx_centre')->where("centre_id=".$centre_id)->field("jiaoshi,centre_id,centre")->find(); //查询中心拥有的教室id
        $jiao = M('flexo')->where("id in({$c['jiaoshi']})")->field('id,content')->select();				//通过教室ID 查询出教室名称

        //查询该中心的排课修改记录(未审核的修改记录)
        $xiugai = M('crm_kecheng_r')->where("centre_id='{$centre_id}' and s_status=0")->field('y_start_time')->select();
        foreach ($xiugai as $k10=>$v10){
            $xiugai2[] = $v10['y_start_time'];
        }

        foreach ($an as $k=>$v){
            if(in_array($v['start_time'],$xiugai2)){
                $a['status'] = '（未审核）';     //未审核
            }else{
                $a['status'] = '';     //正常
            }
            $an[$k]['time'] = $v['start_time'].' 到 '.$v['end_time'].$a['status'];
        }
        $fan['an'] = $an;
        $fan['jiao'] = $jiao;
//        k($fan);die;
        $this->ajaxReturn($fan,'JSON');die;
    }
    //点击选择排课日期 显示该日期排课记录（接口）
    public function kebiao(){
        header("access-control-allow-origin:*");
        $t = I('post.');						//获取查询条件

//        $t['id'] = "2268";                      //测试职员ID
//        $t['start_time'] = "2018-03-28";        //测试职员ID
//        $t['end_time'] = "2018-07-10";          //测试职员ID
//        $t['week'] = 1;                         //周几

        //返回 某个职员的 姓名 ID 中心ID 角色 岗位 电话
        $user_all = $this->ChaUser($t['id']);
        //判断登录人是否有中心ID
        if(!$user_all['centre_id']){
            $fan['status'] = 8;
            $this->ajaxReturn($fan,'JSON');die;
        }
        $centre_id 	=$user_all['centre_id'];	//中心ID
        //基本查询条件
        $where = "a.status=1 and a.centre_id={$centre_id} and a.start_time='{$t['start_time']}' and a.end_time='{$t['end_time']}' and a.week='{$t['week']}'";

        //查询所有上下课时间
        $SXtime = M('crm_kecheng as a')->field('a.s_time,a.x_time')->where($where)->group("a.s_time,a.x_time")->select();

        //查询该中心拥有的教室
        $c = M('wx_centre')->where("centre_id=".$centre_id)->field("jiaoshi,centre_id,centre")->find(); //查询中心拥有的教室id
        $jiao = M('flexo')->where("id in({$c['jiaoshi']})")->field('id,content')->select();				//通过教室ID 查询出教室名称
        $SX[0][0] = null;

        foreach ($SXtime as $k=>$v){
            $SX[$k+1][] = $v;
            foreach ($jiao as $k1=>$v1){
                $where1 = $where." and a.s_time='{$v['s_time']}' and a.x_time='{$v['x_time']}' and a.xuhao='{$v1['id']}'";
                $q = M('crm_kecheng as a')->join('left join crm_ke as b on a.kc_id=b.kc_id')
                    ->join('left join flexo as c on a.xuhao=c.id')
                    ->join('left join xueyuan_baoming as d on a.user_id=d.user_id')
                    ->field("a.*,b.kc_name,b.yueling,b.yueling2,c.content,d.username,length(a.gd_id)-length(REPLACE(a.gd_id,',','')) as gu")
                    ->where($where1)
                    ->select();
                $q2 = $q[0];
                if($q2['gu'] === '0' || $q2['gu'] > 0){
                    $q2['guding'] = $q2['gu']+1;
                }else{
                    $q2['guding'] = 0;
                }

                $SX[$k+1][] = $q2;
                $SX[0][$k1+1] = $v1['content'];
            }
        }
        $this->ajaxReturn($SX,'JSON');die;          //固定班添加成功
//        k($SX);die;
    }

    //月龄分布（接口）
    public function yueling(){
        header("access-control-allow-origin:*");
        //循环生成月龄范围数组
        $yue = array(
            array(2,5),
            array(6,9)
        );
        $l = 2;
        $j = 0;
        for ($i=10;$i<61;$i++){
            if($i<37){
                if($j == 2){
                    $yue[$l][1] = $i;
                    $l++;
                    $j = 1;
                }else{
                    $yue[$l][0] = $i++;
                    $j = 2;
                }
            }else{
                if($j == 2){
                    $yue[$l][1] = $i;
                    if($i == 60){
                        $yue[$l][1] = 600;
                        break;
                    }
                    $l++;
                    $j = 1;

                }else{
                    $yue[$l][0] = $i;
                    $j = 2;
                    $i=$i+4;
                }
            }
        }

        $t = I('post.');			//获取查询条件

//        $t['id'] = "2268";        //测试职员ID

        //返回 某个职员的 姓名 ID 中心ID 角色 岗位 电话
//        $user_all = $this->ChaUser($t['id']);
//        //判断登录人是否有中心ID
//        if(!$user_all['centre_id']){
//            $fan['status'] = 8;
//            $this->ajaxReturn($fan,'JSON');die;
//        }
//
//        $centre_id 	=$user_all['centre_id'];		//中心ID
        $centre_id 	= session("centre_id");		//中心ID
        foreach ($yue as $k=>$v){
            if($v[0] > 36){
                if($v[0] == 37){
                    $re[$k]['yue'] = "3岁-3岁半";
                }elseif($v[0] == 43){
                    $re[$k]['yue'] = "3岁半-4岁";
                }elseif($v[0] == 49){
                    $re[$k]['yue'] = "4岁-4岁半";
                }elseif($v[0] == 55){
                    $re[$k]['yue'] = "4岁半以上";
                }
            }else{
                $re[$k]['yue'] = $v[0].'-'.$v[1].' 个月';
            }

            $w=M('wx_user as a')->join("crm_kjilu as b on a.jl_id=b.jl_id")
                ->field('a.user_id,b.y_keshi,floor((unix_timestamp(now())-unix_timestamp(a.baobao_birthday))/2592000) as yue')
                ->where("a.belong={$centre_id} and a.vip = 1 and a.status = 1 and b.y_keshi >= 1")
                ->having("{$v[0]}<=yue and yue <= {$v[1]}")
                ->select();
            $re[$k]['shu'] = count($w);
        }
        $this->ajaxReturn($re,'JSON');die;
    }
    //一周课程统计（接口）
    public function zhouke(){
        header("access-control-allow-origin:*");
        $t = I('post.');						    //获取查询条件

//        $t['id'] = "2268";        //测试职员ID

        //返回 某个职员的 姓名 ID 中心ID 角色 岗位 电话
//        $user_all = $this->ChaUser($t['id']);
//        //判断登录人是否有中心ID
//        if(!$user_all['centre_id']){
//            $fan['status'] = 8;
//            $this->ajaxReturn($fan,'JSON');die;
//        }
//
//        $centre_id 	=$user_all['centre_id'];		//中心ID
//        $centre_id 	= 223;		//中心ID
        $centre_id 	= session("centre_id");		//中心ID
        //查询该中心拥有的所有排课的开始时间 生成课程查看按钮
        $an = M('crm_kecheng')->where("status=1 and centre_id=$centre_id")->order('start_time desc')->field('start_time,end_time')->group("start_time,end_time")->limit(3)->select();
//        k($an);
        $an = array_reverse($an);

        if($an){
            $fan['status'] = 1;
            $fan['an'] = $an;
            foreach ($an as $k=>$v){
                $w = M('crm_kecheng as a')->join("left join xueyuan_baoming as b on a.user_id=b.user_id")
                    ->field("a.user_id,b.username,count(*) as shu")
                    ->where("a.centre_id = '{$centre_id}' and a.status=1 and a.start_time='{$v['start_time']}' and a.end_time='{$v['end_time']}' and a.user_id!=0")
                    ->group('a.user_id')
                    ->select();
//                $fan['data'][$k] = $v['start_time'];
                $fan['data'][$k] = $w;
            }
        }else{
            $fan['status'] = 2;
        }
//         k($fan);die;
        $this->ajaxReturn($fan,'JSON');die;
    }

    //排课
    public function index2(){
        header("access-control-allow-origin:*");
        $t = I('post.');						    //获取查询条件

        $t['id'] = "2268";        //测试职员ID

        //返回 某个职员的 姓名 ID 中心ID 角色 岗位 电话
        $user_all = $this->ChaUser($t['id']);
        //判断登录人是否有中心ID
        if(!$user_all['centre_id']){
            $fan['status'] = 8;
            $this->ajaxReturn($fan,'JSON');die;
        }
        $centre_id 	=$user_all['centre_id'];		//中心ID

        //查询该中心拥有的所有排课的开始时间 生成课程查看按钮
        $an = M('crm_kecheng')->where("status=1 and centre_id=$centre_id")->order('start_time desc')->field('start_time,end_time')->group("start_time,end_time")->limit(3)->select();

        //查询该中心拥有的教室(排课基本信息)
        $c = M('wx_centre')->where("centre_id=".$centre_id)->field("jiaoshi,centre_id,centre")->find(); //查询中心拥有的教室id
        $jiao = M('flexo')->where("id in({$c['jiaoshi']})")->field('id,content')->select();				//通过教室ID 查询出教室名称

        $fan['an'] = $an;
        $fan['jiao'] = $jiao;
        $this->ajaxReturn($fan,'JSON');die;
    }
    //排课点击日期之后
    public function index3(){
        header("access-control-allow-origin:*");
        $t = I('post.');						//获取查询条件

        $t['id'] = "2268";                      //测试职员ID
        $t['start_time'] = "2018-03-28";        //测试职员ID
        $t['end_time'] = "2018-07-10";          //测试职员ID
        $t['week'] = 1;                         //周几

        //返回 某个职员的 姓名 ID 中心ID 角色 岗位 电话
        $user_all = $this->ChaUser($t['id']);
        //判断登录人是否有中心ID
        if(!$user_all['centre_id']){
            $fan['status'] = 8;
            $this->ajaxReturn($fan,'JSON');die;
        }
        $centre_id 	=$user_all['centre_id'];	//中心ID
        //基本查询条件
        $where = "a.status=1 and a.centre_id={$centre_id} and a.start_time='{$t['start_time']}' and a.end_time='{$t['end_time']}' and a.week='{$t['week']}'";

        //查询所有上下课时间
        $SXtime = M('crm_kecheng as a')->field('a.s_time,a.x_time')->where($where)->group("a.s_time,a.x_time")->select();

        //查询该中心拥有的教室
        $c = M('wx_centre')->where("centre_id=".$centre_id)->field("jiaoshi,centre_id,centre")->find(); //查询中心拥有的教室id
        $jiao = M('flexo')->where("id in({$c['jiaoshi']})")->field('id,content')->select();				//通过教室ID 查询出教室名称
        $SX[0][0] = null;

        foreach ($SXtime as $k=>$v){
            $SX[$k+1][] = $v;
            foreach ($jiao as $k1=>$v1){
                $where1 = $where." and a.s_time='{$v['s_time']}' and a.x_time='{$v['x_time']}' and a.xuhao='{$v1['id']}'";
                $q = M('crm_kecheng as a')->join('left join crm_ke as b on a.kc_id=b.kc_id')
                    ->join('left join flexo as c on a.xuhao=c.id')
                    ->join('left join xueyuan_baoming as d on a.user_id=d.user_id')
                    ->field("a.*,b.kc_name,b.yueling,b.yueling2,c.content,d.username,length(a.gd_id)-length(REPLACE(a.gd_id,',','')) as gu")
                    ->where($where1)
                    ->select();
                $q2 = $q[0];
                if($q2['gu'] === '0' || $q2['gu'] > 0){
                    $q2['guding'] = $q2['gu']+1;
                }else{
                    $q2['guding'] = 0;
                }

                $SX[$k+1][] = $q2;
                $SX[0][$k1+1] = $v1['content'];
            }
        }

        //查询出该中心所有的老师
        $t = M('xueyuan_baoming')->where('centre_id='.$centre_id." and gangwei='老师' and status=1")->field('user_id,username,centre_id')->select();

        //查询出所有的公共课程和该中心自建的课程(排课基本信息)
        $k = M('crm_ke')->where("centre_id in(0,{$centre_id}) and status=1")->field('kc_id,kc_name,xiaohao')->select();

        $fan['lao'] = $t;
        $fan['ke'] = $k;
        $fan['data'] = $SX;
//        k($fan);die;
        $this->ajaxReturn($fan,'JSON');die;          //固定班添加成功
    }
    //批量修改排课开始日期和结束日期
    public function riqi2(){
        header("access-control-allow-origin:*");
        $t = I('post.');						    //获取查询条件

        $t['id'] = "2268";                  //测试职员ID
        $t['y_start_time'] = "2018-03-28";
        $t['y_end_time'] = "2018-07-10";
        $t['x_start_time'] = "2018-03-28";
        $t['x_end_time'] = "2018-07-16";

        //返回 某个职员的 姓名 ID 中心ID 角色 岗位 电话
        $user_all = $this->ChaUser($t['id']);
        //判断登录人是否有中心ID
        if(!$user_all['centre_id']){
            $fan['status'] = 8;
            $this->ajaxReturn($fan,'JSON');die;
        }

        $centre_id 	=$user_all['centre_id'];		//中心ID
        
//        k($t);die;
        $t['centre_id']	= $centre_id;		//中心ID
        $t['t_time']	= date("Y-m-d H:m:s");		        //排课修改日期
        $t['t_user_id']	= $t['id'];		//排课修改人

        $kaishi = M('crm_kecheng')->where("status=1 and centre_id='{$t['centre_id']}' and start_time!='{$t['y_start_time']}'")->order('start_time desc')->field('start_time,end_time')->group('start_time')->select();
//        k($kaishi);die;
        $cheng = 1;
        if($t['x_start_time'] == $t['y_start_time'] and $t['x_end_time'] == $t['y_end_time']){
            $cheng = 9;
        }
        foreach ($kaishi as $k2=>$v2){
            if(!($t['x_end_time'] <= $v2['start_time'] || $v2['end_time'] <= $t['x_start_time'])){
                $cheng = 9;
            }
        }

        if($cheng == 1){
            M('crm_kecheng_r')->add($t);
        }
        //1=不重复 9=重复
        $this->ajaxReturn($cheng,'JSON');die;
    }
    //一键排课
    public function yijian2(){
        header("access-control-allow-origin:*");
        $t = I('post.');						    //获取查询条件

//        $t['id'] = "2268";                    //测试职员ID
//        $t['t_start_time'] = "2018-10-10";    //新排课开始日期
//        $t['t_end_time'] = "2018-10-16";      //新排课结束日期

        //返回 某个职员的 姓名 ID 中心ID 角色 岗位 电话
        $user_all = $this->ChaUser($t['id']);
        //判断登录人是否有中心ID
        if(!$user_all['centre_id']){
            $fan['status'] = 8;
            $this->ajaxReturn($fan,'JSON');die;
        }

        $centre_id 	=$user_all['centre_id'];		//中心ID
        $user_id = $t['id'];                        //当前登录人ID

        //查询该中心拥有的所有排课的开始时间 生成课程查看按钮
        $kaishi = M('crm_kecheng')->where("status=1 and centre_id='{$centre_id}'")->order('start_time desc')->field('start_time,end_time')->group('start_time')->select();

        $cheng = 1;
        foreach ($kaishi as $k2=>$v2){
            if(!($t['t_end_time'] <= $v2['start_time'] || $v2['end_time'] <= $t['t_start_time'])){
                $cheng = 9;
            }
        }

        if($cheng != 9){
            $ke = M("crm_kecheng")->where("status=1 and centre_id='{$centre_id}' and start_time='{$kaishi[0]['start_time']}' and end_time='{$kaishi[0]['end_time']}'")->select();
            foreach ($ke as $k=>$v){
                $xin['start_time'] = $t['t_start_time'];
                $xin['end_time'] = $t['t_end_time'];
                $xin['s_time'] = $v['s_time'];
                $xin['x_time'] = $v['x_time'];
                $xin['week'] = $v['week'];
                $xin['kc_id'] = $v['kc_id'];
                $xin['user_id'] = $v['user_id'];
                $xin['xuhao'] = $v['xuhao'];
                $xin['centre_id'] = $v['centre_id'];
                $xin['xiaoke'] = $v['xiaoke'];
                $xin['create_name'] = $user_id;
                $xin['source'] = "一键排课";
                M('crm_kecheng')->add($xin);
                $cheng = 1;
            }
        }
        $this->ajaxReturn($cheng,'JSON');die;
    }
}