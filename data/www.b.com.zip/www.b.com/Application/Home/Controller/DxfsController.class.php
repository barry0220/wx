<?php
namespace Home\Controller;
use Think\Controller;
class DxczjlsController extends Controller {
  //短信发送
    public function index(){
       header("access-control-allow-origin:*");
       
   }
}