<?php
namespace Home\Controller;
use Think\Controller;
class CommonController extends Controller {
	//继承父类构造方法，并设置自己的构造方法
	function _initialize(){
//		判断用户是否已经登录
		$user_id=session("user_id");
		$centre_id=session("centre_id");
		$arr=M('crm_login')->where("user_id='$user_id' and centre_id='$centre_id'")->order('id desc')->field('session_id,status')->find();
		if($arr['status']==1){
			$this->redirect("Login/yindaoye");
			exit();
		}
		if(session("centre_id") && session("user_id") && $arr['session_id']==session_id()){

		}else{
			if(session("user_id") && $arr['session_id']!=session_id()){
				$this->redirect("Login/index?zz=1");
			    exit();
			}else{
				$this->redirect("Login/index");
			    exit();
			}
			
		}
	}
}
