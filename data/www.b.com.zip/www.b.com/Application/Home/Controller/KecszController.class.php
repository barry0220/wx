<?php
namespace Home\Controller;
use Think\Controller;
class kecszController extends CommonController {
     public function index(){
     	if(isset($_GET['p'])){
         $page=$_GET['p'];
       }else{
         $page=1;
       }
       $centre_id=session("centre_id");
       $num=M("crm_ke")->where("status=1 and (centre_id=0 or centre_id='$centre_id')")->count();
       $pageone=10;//每页数据
       $pagetotal=ceil($num/$pageone);
       $pyl=($page-1)*$pageone;//偏移量
       $this->page=$page;
       $this->pagetotal=$pagetotal;
       $this->num=$num;
       $sql="SELECT * FROM crm_ke where status=1 and (centre_id=0 or centre_id='$centre_id') order by kc_id desc limit $pyl,$pageone";
       $this->data=M()->query($sql);
       $this->display();
     }
     public function add(){
     	$data['kc_name']=I('post.kc_name');
     	$data['yueling']=I('post.yueling');
     	$data['yueling2']=I('post.yueling2');
      $data['xiaohao']=I('post.xiaohao');
     	$data['centre_id']=session('centre_id');
     	$data['create_name']=session("user_id");
     	$data['source']="PC";
     	if(M('crm_ke')->add($data)){
     		$this->redirect("index");
     	}
     }
     public function shanchu(){
      $crm_ke=M("crm_ke");
      $id=I('post.id');
      $centre_id=M("crm_ke")->where("kc_id=".$id)->getField("centre_id");
      if($centre_id==0){
        echo 2;die;//如果是总部将不能删除
      }
      $data['status']=0;
      $rel=$crm_ke->where("kc_id=".$id)->save($data);
      if($rel){
        echo 1;
      }
    }
    public function xiugai(){
      $kc_id=I('post.kc_id');
      $arr=M('crm_ke')->where("kc_id='$kc_id'")->find();
      $this->ajaxReturn($arr,'JSON');
    }
    //修改课程
    public function xiu(){
      $data['kc_name']=I('post.kc_name');
      $data['yueling']=I('post.yueling');
      $data['yueling2']=I('post.yueling2');
      $data['xiaohao']=I('post.xiaohao');
      $kc_id=I('post.kc_id');
      if(M('crm_ke')->where("kc_id='$kc_id'")->save($data)){
        $this->redirect("index");
      }
    }
}