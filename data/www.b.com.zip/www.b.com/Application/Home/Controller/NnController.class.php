<?php
namespace Home\Controller;

use Think\Controller;

class NnController extends Controller
{
    /*
    * 接口名：跟进记录（index）
    *
    * 接口地址（post）：192.168.1.138/Nn/index
    *
    * 参数：（可选）
     *
     * 当前页数： page
    *
    * 合同号：hetong
    *
    * 会员姓名：name
    *
    * 家长姓名：pname
    *
    * 家长电话：pphone
    *
    * 状态：type
    *
    * 销售人：salesperson
     *
     *
    *
    * 返回值：
    *
    * 
     * hetong：合同编号
     * 
     * gj_type：状态
     * 
     * baobao_name（baobao_name2）：宝宝姓名
     * 
     * receivable:合同金额
     * 
     * receipt_type:收款方式
     * 
     * shishou:实收金额
     * 
     * create_time:收款日期
     * 
     * guwen:销售人
     * 
     * create_name:录入人
     * 
     * user_id:用户id
     * 
     * username：用户姓名
    * */
    public function index()
    {
//        根据回传条件判断拼接查询条件
        header("access-control-allow-origin:*");
        $condition = I('post.');
        $centerid = session('centre_id');
//        $centerid = session('centre_id');
        $where = "a.belong={$centerid} and a.status=1 and a.vip=1";

        if ($condition['hetong']) {
            $where .= " and b.hetong={$condition['hetong']} ";
        }

        if ($condition['name']){
            $where .= "  and (a.baobao_name like '%{$condition['name']}%' or a.baobao_name2 like '%{$condition['name']}%') ";
        }

        if ($condition['pname']) {
            $where .= " and (a.name1 like '%{$condition['pname']}%' or a.name2 like '%{$condition['pname']}%' or a.name3 like '%{$condition['pname']}%' or a.name4 like '%{$condition['pname']}%' or a.name5 like '%{$condition['pname']}%' or a.name6 like '%{$condition['pname']}%') ";
        }

        if ($condition['pphone']) {
            $where .= " and (a.phone1 like '%{$condition['pphone']}%' or a.phone2 like '%{$condition['pphone']}%' or a.phone3 like '%{$condition['pphone']}%' or a.phone4 like '%{$condition['pphone']}%' or a.phone5 like '%{$condition['pphone']}%' or a.phone6 like '%{$condition['pphone']}%') ";
        }

        if ($condition['type']) {
            $where .= " and a.gj_type='{$condition['type']}'";
        }

        if ($condition['salesperson']) {
            $where .= " and a.gw_id={$condition['salesperson']} ";
        }

//        链表联查
        if (!empty($condition['page'])) {
            $page = $condition['page'];
        } else {
            $page = 1;
        }

        $count = M('wx_user as a')
            ->join("left join crm_kjilu as b on a.jl_id=b.jl_id")
            ->join("left join xueyuan_baoming as c on a.gw_id=c.user_id")
            ->field("b.hetong,a.gj_type,a.baobao_name,a.baobao_name2,a.baobao_birthday,a.baobao_name2,b.receivable,b.receipt_type,b.shishou,b.create_time,b.guwen,b.create_name,b.bz,c.user_id,c.username")
            ->where($where)
            ->count();
        $pageone = 10;//每页数据
        $pagetotal = ceil($count / $pageone);
        $pyl = ($page - 1) * $pageone;//偏移量
        $da = M('wx_user as a')
            ->join("left join crm_kjilu as b on a.jl_id=b.jl_id")
            ->join("left join xueyuan_baoming as c on a.gw_id=c.user_id")
            ->field("a.baobao_birthday,a.baobao_name2,b.hetong,a.gj_type,a.baobao_name,a.baobao_name2,b.receivable,b.receipt_type,b.shishou,b.create_time,b.guwen,b.create_name,b.bz,c.user_id,c.username,a.user_id")
            ->limit($pyl, $pageone)
            ->where($where)
            ->select();
//        
//        $a = M()->getLastsql();
//        var_dump($a);die;

//        if ($da == false){
//            json('10002',"查询失败");
//        }
        if ($da == null) {
            json('10003', "没有检索到数据");
        }
        foreach ($da as $key => $value) {
            $da[$key]['page'] = $page;
            $da[$key]['pagetotal'] = $pagetotal;
            $da[$key]['num'] = $count;
        }
        json('10001', $da);

    }


    /*
     * 
     * 接口名：营销人员下拉选项（sales）
     * 
     * 地址：Nn/sales
     * 
     * 参数：无
     *
     * 状态码说明：10001 成功
     *
     * 10002： 未检索到数据
     *
     * 10003： 查询失败
     *
     * 10004： 不是中心总监
     *
     * 返回值：
     * 
     * status:10004
     * 
     * msg:不是中心总监
     * 
     * 或者
     * 
     * status：10001
     * 
     * user_id：用户id
     * 
     * username：用户名
     * 
     * */
    public function sales()

    {
        header("access-control-allow-origin:*");
        $user_id = session('user_id');
        // $user_id = session('user_id');
        $centre_id = session('centre_id');
//        $centre_id = session('centre_id');
//        判断当前userid是不是中心总监
        $Director = M('xueyuan_baoming')->where("user_id={$user_id}")->find();
        if ($Director == false) {
            json('10003', "查询失败");
        }
        if ($Director == null) {
            json('10002', "未检索到数据");
        }
        if ($Director['gangwei'] !== "中心总监") {
            json('10004', "您不是中心总监");
        } else {
            $Marketing = M('xueyuan_baoming')->where("centre_id={$centre_id} and gangwei='营销' and status=1")->field('user_id,username')->select();
            if ($Marketing == false) {
                json('10003', "查询失败");
            }
            if ($Marketing == null) {
                json('10002', "未检索到数据");
            }
            json('10001', $Marketing);
        }

    }


    /*
     *
     *
     * 接口名：客户详细信息
     *
     * 地址：Nn/Details
     *
     * 参数：
     *
     * userid:列表中用户id
     *
     * 状态码说明：
     *
     * 10001:成功
     *
     * 10002：没有查到数据
     *
     * 10003：查询失败
     *
     * 10004: 参数错误
     *
     * 返回值：
     *
     * {
  "status": "10001",
  "result": {
    "lastgjtime": null,   下次跟进时间
    "bao_age": 31,  月龄
    "p_name": "", 家长姓名
    "p_phone": "",  家长手机号
    "gwname": null,  负责销售人
    "gj_type": "",  跟进状态
    "img": "http://wx.qlogo.cn/mmopen/PiajxSqBRaELbIpMsCLdjV4OxCOXmlNLk1PU4WALMjOYzts6icC0BdjRok0y10ZLFDf0PJwbrdfst1d6PG6poR0g/0",  头像
    "baobao_name": null,  宝宝姓名
    "baobao_sex": null,  宝宝性别
    "site": null 家庭地址
  }
     *
     *
     *
     * */
    public function Details()
    {
        header("access-control-allow-origin:*");
        $userid = I("post.userid");
        if (empty($userid)) {
            json('10004', "参数错误");
        }
        $data = M('wx_user as a')
            ->join("left join crm_gj as b on a.user_id=b.bao_id")
            ->join("left join xueyuan_baoming as c on a.gw_id=c.user_id")
            ->field("a.*,b.gw_id,c.username as gwname")
            ->where("a.user_id={$userid}")
            ->find();
        if ($data == false) {
            json('10003', "查询失败");
        }
        if ($data == null) {
            json('10002', "未检索到数据");
        }
        $arr = [];
//        最后跟进时间
        $lastgjtime = M('crm_gj')->where("bao_id={$userid}")->order("create_time desc")->field('create_time,lasttime')->find();
        //  $a = M()->getLastsql();
        // var_dump($a);die;
        //  if ($lastgjtime == false){
        //      json('10003',"查询失败");
        //  }
        //  if ($lastgjtime == null){
        //      json('10002',"未检索到数据");
        //  }
        $arr['lastgjtime'] = $lastgjtime['create_time'];
//        月龄处理
        $shij = date("Y-m-d");
        $d = strtotime($shij) - strtotime($data['baobao_birthday']);
        $e = $d / 2592000;//一个月的时间，单位秒
        $f = round($e);//月龄取整
        $arr['bao_age'] = $f;
//        家长姓名，手机显示问题判断
        if (!empty($data['name1'])) {
            $arr['p_name'] = $data['name1'];
            $arr['guanxi'] = '爸爸';
        } else if (!empty($data['name2'])) {
            $arr['p_name'] = $data['name2'];
            $arr['guanxi'] = '妈妈';
        } else if (!empty($data['name3'])) {
            $arr['p_name'] = $data['name3'];
            $arr['guanxi'] = '爷爷';
        } else if (!empty($data['name4'])) {
            $arr['p_name'] = $data['name4'];
            $arr['guanxi'] = '奶奶';
        } else if (!empty($data['name5'])) {
            $arr['p_name'] = $data['name5'];
            $arr['guanxi'] = '姥爷';
        } else if (!empty($data['name6'])) {
            $arr['p_name'] = $data['name6'];
            $arr['guanxi'] = '姥姥';
        } else {
            $arr['p_name'] = "";
        }
//        手机
        if (!empty($data['phone1'])) {
            $arr['p_phone'] = $data['phone1'];
        } else if (!empty($data['phone2'])) {
            $arr['p_phone'] = $data['phone2'];
        } else if (!empty($data['phone3'])) {
            $arr['p_phone'] = $data['phone3'];
        } else if (!empty($data['phone4'])) {
            $arr['p_phone'] = $data['phone4'];
        } else if (!empty($data['phone5'])) {
            $arr['p_phone'] = $data['phone5'];
        } else if (!empty($data['phone6'])) {
            $arr['p_phone'] = $data['phone6'];
        } else {
            $arr['p_phone'] = "";
        }
//        处理数组（整合有用元素合并成新数组）
        /*
         *
         * 新增昵称和生日
         * */
        $arr['gwname'] = $data['gwname'];
        $arr['gj_type'] = $data['gj_type'];
        $arr['img'] = $data['img'];
        $arr['baobao_name'] = $data['baobao_name'];
        $arr['baobao_sex'] = $data['baobao_sex'];
        $arr['site'] = $data['site'];
        $arr['lasttime'] = $lastgjtime['lasttime'];
        $arr['baobao_name2'] = $data['baobao_name2'];
        $arr['baobao_birthday'] = $data['baobao_birthday'];
        json('10001', $arr);

    }


    /*
     *
     * 接口名：客户到访记录  Visiting_records
     *
     * 接口地址：Nn/Visiting_records
     *
     * 参数：userid
     *
     * 状态码说明：
     *
     * 10001: 成功
     *
     * 10002： 参数错误
     *
     * 10003： 查询失败
     *
     * 10004：没有预约计划
     *
     * 返回值：
     *
     * {
  "status": "10001",
  "result": [
    {
      "id": "1",
      "user_id": "196", （当前userid）
      "user_name": "测试", （宝宝姓名）
      "plantime": "2017-12-16 16:50:22", （预约到访时间）
      "visittype": "0", （到访状态 0未到访  1到访）
      "content": "签字"，  （到访内容）
      "visittime": null   （到访时间到访状态为1时才不为空）
    }
  ]
}
     *
     *
     *
     * */
    public function Visiting_records()
    {
        header("access-control-allow-origin:*");
        $userid = I("post.userid");
        if (empty($userid) || !isset($userid)) {
            json('10002', "参数错误");
        }
        $data = M('crm_visit')->where("user_id=$userid")->select();
        if ($data == false) {
            json('10003', "查询失败");
        }
        if ($data == null) {
            json('10004', "暂时没有预约到访计划");
        }
        foreach ($data as $key => $value) {
            if ($value['visittype'] == 0) {
                $data[$key]['visittype'] = '未到访';
            } else {
                $data[$key]['visittype'] = '到访';
            }
        }
        json('10001', $data);
    }


    /*
     * 接口名：更改到访状态（Visit_type）
     *
     * 地址：Nn/Visit_type
     *
     * 参数：id(到访记录id)
     *
     * 状态码说明：
     *
     * 10001: 成功
     *
     * 10002：参数错误
     *
     * 10003：修改状态失败
     *
     * 返回值：
     *
     * "status": "10001",
  "result": “已到访”
     *
     * */
    public function Visit_type()
    {
        header("access-control-allow-origin:*");
        $id = I("post.id");
        if (empty($id) || !isset($id)) {
            json('10002', "参数错误");
        }
        $data['visittype'] = 1;
//        当前时间获取
        $data['visittime'] = date("Y-m-d H:i:s");
        $results = M('crm_visit')->where("id={$id}")->save($data);
        if (false !== $results || 0 !== $results) {
            json('10001', "已到访");
        } else {
            json('10003', "修改状态失败");
        }
    }


    /*
     *
     * 接口名：添加到访计划(Add_vplan)
     *
     * 地址：Nn/Add_vplan
     *
     * 参数：
     *
     * user_id: 宝宝id
     *
     * plantime：  计划到访时间
     *
     * content： 到访内容
     *
     * 状态码说明：
     *
     * 10001:  添加成功
     *
     * 10002： 参数错误
     *
     * 10003：添加失败
     *
     * 返回值：
     *
     * "status": "10001",
  "result": “添加成功”
     *
     *
     *
     * */

    public function Add_vplan()
    {
        header("access-control-allow-origin:*");
        $user_id = I("post.user_id");
        $data['username'] = I('post.username');
        if (empty($user_id) || !isset($user_id)) {
            json('10002', "参数错误");
        }

        $user_name = M('wx_user')->where("user_id={$user_id}")->getField("baobao_name");
        if (empty($user_name)) {
            json('10002', "参数错误");
        }
        $plantime = I("post.plantime");
        if (empty($plantime) || !isset($plantime)) {
            json('10002', "参数错误");
        }
        $create_id = session('user_id');
        if (empty($create_id)) {
            json('10002', "参数错误");
        }
        $content = I("post.content");
        if (empty($content) || !isset($content)) {
            json('10002', "参数错误");
        }
        $data['create_id'] = $create_id;
        $data['user_id'] = $user_id;
        $data['user_name'] = $user_name;
        $data['plantime'] = $plantime;
        $data['visittype'] = 0;
        $data['content'] = $content;
        $data['visittime'] = "";
        $da['gj_type'] = '未到访';
        M("wx_user")->where("user_id={$user_id}")->save($da);
        $results = M('crm_visit')->add($data);
        if ($results) {
            json('10001', "添加成功");
        } else {
            json('10003', "添加失败");
        }
    }


    /*
     *
     * 接口名：跟进记录查看（Follow）
     *
     * 地址：Nn/Follow
     *
     * 参数：
     *
     * user_id： 宝宝id
     *
     * page: 当前页
     *
     * 状态码说明：
     *
     * 10001：成功
     *
     * 10002：参数错误
     *
     * 10003：查询失败
     *
     * 10004：未检索到数据
     *
     * 返回值：
     *
     * {
  "status": "10001",
  "result": [
    {
      "create_time": "2017-04-21 17:41:18", （创建时间）
      "fangshi": "短信", （跟进方式）
      "g_pname": "",  （跟进父母）
      "neirong": "测试", （跟进内容）
      "username": null, （跟进人姓名）
      "page": 1, （当前页数）
      "pagetotal": 1, （总页数）
      "num": "4"  （总条数）
    },
    {
      "create_time": "2017-05-05 17:41:56",
      "fangshi": "到店",
      "g_pname": "",
      "neirong": "",
      "username": null,
      "page": 1,
      "pagetotal": 1,
      "num": "4"
    },
    {
      "create_time": "2017-05-05 17:44:16",
      "fangshi": "",
      "g_pname": "",
      "neirong": "",
      "username": null,
      "page": 1,
      "pagetotal": 1,
      "num": "4"
    },
    {

      "create_time": "2017-05-05 17:44:20",
      "fangshi": "",
      "g_pname": "",
      "neirong": "",
      "username": null,
      "page": 1,
      "pagetotal": 1,
      "num": "4"
    }
  ]
}
     *
     * */
    public function Follow()
    {
        header("access-control-allow-origin:*");
        $user_id = I("post.user_id");
        if (empty($user_id) || !isset($user_id)) {
            json('10002', "参数错误");
        }
        $count = M('crm_gj as a')
            ->join("left join xueyuan_baoming as b on a.gw_id=b.user_id")
            ->where("a.bao_id={$user_id}")
            ->field("a.create_time,a.fangshi,a.g_pname,a.neirong,b.username")
            ->count();
        if (empty($_POST['page']) || isset($_POST['page'])) {
            $page = $_POST['page'];
        } else {
            $page = 1;
        }
        $pageone = 10;//每页数据
        $pagetotal = ceil($count / $pageone);
        $pyl = ($page - 1) * $pageone;
        $result = M('crm_gj as a')
            ->join("left join xueyuan_baoming as b on a.gw_id=b.user_id")
            ->join("left join wx_user as c on a.bao_id=c.user_id")
            ->where("a.bao_id={$user_id}")
            ->field("a.create_time,a.fangshi,a.gj_id,a.g_pname,a.neirong,c.baobao_name as username,a.st_time,a.dao")
            ->order("a.create_time desc")
            ->select();

        if ($result == false) {
            json('10003', "查询失败");
        }
        if ($result == null) {
            json('10004', "未检索到数据");
        }
        foreach ($result as $key => $value) {
            if($value['dao']==1){
                $result[$key]['visittype']='已到访';
            }else{
                $result[$key]['visittype']='未到访';
            }
            
        }
//        foreach ($result as $key=>$value){
//            $result[$key]['page']=$page;
//            $result[$key]['pagetotal']=$pagetotal;
//            $result[$key]['num']=$count;
//        }
        json('10001', $result);

    }


    /*
    * 接口名：家长姓名（P_name）
    *
    * 地址：Nn/P_name
    *
    * 参数：bao_id(宝宝id)
    *
    * 状态码说明：
     *
     * 10001：成功
     *
     * 10002：参数错误
     *
     * 10003：查询失败
     *
     * 10004：未检索到数据
    *
    * 返回值：
    *
     * {
  "status": "10001",
  "result": {
    "name1": "张旭",
    "name2": null,
    "name3": null,
    "name4": null,
    "name5": null,
    "name6": null,
    "user_id": "2385"(宝宝id)
  }
}
    *
    * */
    public function nameaa()
    {
        header("access-control-allow-origin:*");
        $user_id = I("post.user_id");
        $user_name = M('wx_user')->where("user_id={$user_id}")->getField("baobao_name");
        json('10001', $user_name);
    }

    public function P_name()
    {
        header("access-control-allow-origin:*");
        // $bao_id = 2385;
        $bao_id = I("post.bao_id");
        if (empty($bao_id) || !isset($bao_id)) {
            json('10002', "参数错误");
        }
        $pname = M('wx_user')->where("user_id={$bao_id}")->field("name1,name2,name3,name4,name5,name6,user_id")->find();
        if ($pname == false) {
            json('10003', "查询失败");
        }
        if ($pname == null) {
            json('10004', "未检索到数据");
        }
        if (!empty($pname['name1'])) {
            $arr[0]['name'] = $pname['name1'];
        }
        if (!empty($pname['name2'])) {
            $arr[1]['name'] = $pname['name2'];
        }
        if (!empty($pname['name3'])) {
            $arr[2]['name'] = $pname['name3'];
        }
        if (!empty($pname['name4'])) {
            $arr[3]['name'] = $pname['name4'];
        }
        if (!empty($pname['name5'])) {
            $arr[4]['name'] = $pname['name5'];
        }
        if (!empty($pname['name6'])) {
            $arr[5]['name'] = $pname['name6'];
        }

        json('10001', $arr);
    }


    /*
     * 接口名：添加跟进信息（Addfollow）
     *
     * 地址：Nn/Addfollow
     *
     * 参数：
     *
     * bao_id：宝宝id
     *
     * neirong： 跟进内容
     *
     * g_pname： 跟进家长
     *
     * fangshi:  跟进方式
     *
     * vip：     客户类型
     *
     * lasttime：下次跟进时间
     *
     * 状态码说明：
     *
     * 10001:  添加成功
     *
     * 10002： 参数错误
     *
     * 10003： 添加失败
     *
     * 返回值：
     *
     * "status": "10001",
  "result": “添加成功”
     * */

    public function Addfollow()
    {
        header("access-control-allow-origin:*");
        $add = I('post.');
//        根据接
        $add['centre_id'] = session('centre_id');
        $add['vip'] = M('wx_user')->where("user_id='$add[bao_id]'")->getField('vip');
        if (empty($add['bao_id'])) {
            json('10002', "参数错误1");
        }

        if (empty($add['neirong'])) {
            json('10002', "参数错误2");
        }

        // if (empty($add['g_pname'])) {
        //     json('10002', "参数错误3");
        // }

        if (empty($add['fangshi'])) {
            json('10002', "参数错误4");
        }
        $bid = M('crm_gj')->where("bao_id='$add[bao_id]'")->getField('bao_id');
        $gj_type=M('wx_user')->where("user_id='$add[bao_id]'")->getField('gj_type');
        $zhuangtai=$add['zhuangtai'];
        if(empty($zhuangtai)){
         if (!empty($bid)) {
            $data['gj_type'] = '持续跟进';
        } else {
            $data['gj_type'] = '已跟进';
        }
        if (!empty($add['pk_id']) and $add['fangshi'] = '到店') {
            $data['gj_type'] = '预约未到访';
        }
        if($gj_type=='预约未到访' or $gj_type=='已到访'){
            $data['gj_type'] = $gj_type;
        }   
    }else{
        $data['gj_type'] = $zhuangtai;
    }
        
        $add['gw_id'] = session('user_id');
        $results = M('crm_gj')->add($add);

        M("wx_user")->where("user_id='$add[bao_id]'")->save($data);
        //  $a = M()->getLastsql();
        // var_dump($a);die;
        if ($results) {
            json('10001', "添加成功");
        } else {
            json('10003', "添加失败");
        }

    }


    /*
   * 接口名：跟进记录编辑显示（Edit）
   *
   * 地址：Nn/Edit
   *
   * 参数：
     *
     * gj_id : 跟进id
   *
   * 状态码说明：
     *
     * 10001：成功
     *
     * 10002：参数错误
     *
     * 10003：查询失败
     *
     * 10004：未检索到数据
   *
   * 返回值：
     *
     * {
  "status": "10001",
  "result": {
    "gj_id": "1000",  (跟进id)
    "g_pname": "",   （跟进家长）
    "fangshi": "电话",  （ 跟进方式）
    "neirong": "在红黄蓝报的1年的  等课上的差不多在过来  1岁\r\n8月份",  （跟进内容）
    "baobao_name": "10641960458 1岁",  （宝宝姓名）
    "username": "刘柳"  （跟进人）
  }
}
   *
   *
   * */
    public function Edit()
    {
        header("access-control-allow-origin:*");
//        $gj_id = 1000;
        $gj_id = I('post.gj_id');
        if (empty($gj_id) || !isset($gj_id)) {
            json('10002', "参数错误");
        }
        $results = M('crm_gj as a')
            ->join("left join wx_user as b on a.bao_id=b.user_id")
            ->join("left join xueyuan_baoming as c on a.gw_id=c.user_id")
            ->where("gj_id={$gj_id}")
            ->field("a.gj_id,a.g_pname,a.fangshi,a.neirong,b.baobao_name,c.username")
            ->find();
        if ($results == false) {
            json('10003', "查询失败");
        }
        if ($results == null) {
            json('10004', "未检索到数据");
        }
        json('10001', $results);
    }


    /*
   * 接口名：Editfollow
   *
   * 地址：Nn/Editfollow
   *
   * 参数：
     *
     * gj_id: 跟进id
     *
     * fangshi: 跟进方式
     *
     * neirong：   跟进内容
   *
   * 状态码说明：
   *
   * 返回值：
   *
     * "status": "10001",
  "result": “修改成功”
   *
   * */


    public function Editfollow()
    {
        header("access-control-allow-origin:*");
        $save = I('post.');
        if (empty($save['fangshi']) || !isset($save['fangshi'])) {
            json('10002', "参数错误");
        }
        if (empty($save['neirong']) || !isset($save['neirong'])) {
            json('10002', "参数错误");
        }
        if (empty($save['gj_id']) || !isset($save['gj_id'])) {
            json('10002', "参数错误");
        }
        $results = M('crm_gj')->where("gj_id={$save['gj_id']}")->save($save);
        if (false !== $results || 0 !== $results) {
            json('10001', "修改成功");
        } else {
            json('10003', "修改状态失败");
        }

    }

    //删除跟进记录
    public function del()
    {
        header("access-control-allow-origin:*");
        $gj_id = I('post.gj_id');
        if (M('crm_gj')->where("gj_id='$gj_id'")->delete()) {
            json('10001', "删除成功成功");
        }
    }

    /*
* 接口名：当月跟进记录（Follow_mounth）
*
* 地址：Nn/Follow_mounth
*
* 参数：无
*
* 状态码：
*
* 返回值：
   *
   *gj_id :跟进id
   *
   * fangshi：跟进方式
   *
   * create_time：跟进时间
   *
   * gj：意向度
   *
   * dao：试听是否到访
   *
   * ty_type：体验类型
   *
   * g_pname：跟进家长
   *
   * vip：客户状态
   *
   * baobao_name：宝宝名字
   *
   * username：跟进人姓名
   *
   *
   *
   *
*
*
* */

    public function Follow_mounth()
    {
        header("access-control-allow-origin:*");
        $mstar = date("Y-m-d H:i:s", mktime(0, 0, 0, date("m"), 1, date("Y")));
//        月末时间
        $mend = date("Y-m-d H:i:s", mktime(23, 59, 59, date("m"), date("t"), date("Y")));


//        获取当前登录id判断是否为总监
        $user_id = session('user_id');
        $centre_id = session('centre_id');
        $zongjian = M('xueyuan_baoming')->where("user_id={$user_id}")->find();
        if ($zongjian['gangwei'] == "中心总监") {
            $where = "a.create_time>='$mstar' and a.create_time<='$mend' and a.centre_id='$centre_id'";
        } else {
            $where = "a.create_time>='$mstar' and a.create_time<='$mend' and a.gw_id={$zongjian['user_id']} and a.centre_id='$centre_id'";
        }
        if ($zongjian == false) {
            json('10003', "查询失败");
        }
        if ($zongjian == null) {
            json('10004', "未检索到数据");
        }
        $condition = I('post.');
        if ($condition['name']){
            $where .= "  and (b.baobao_name like '%{$condition['name']}%' or b.baobao_name2 like '%{$condition['name']}%') ";
        }

        if ($condition['pname']) {
            $where .= " and (b.name1 like '%{$condition['pname']}%' or b.name2 like '%{$condition['pname']}%' or b.name3 like '%{$condition['pname']}%' or b.name4 like '%{$condition['pname']}%' or b.name5 like '%{$condition['pname']}%' or b.name6 like '%{$condition['pname']}%') ";
        }

        if ($condition['pphone']) {
            $where .= " and (b.phone1 like '%{$condition['pphone']}%' or b.phone2 like '%{$condition['pphone']}%' or b.phone3 like '%{$condition['pphone']}%' or b.phone4 like '%{$condition['pphone']}%' or b.phone5 like '%{$condition['pphone']}%' or b.phone6 like '%{$condition['pphone']}%') ";
        }

        if ($condition['type']) {
            $where .= " and a.gj_type='{$condition['type']}'";
        }

        if ($condition['salesperson']) {
            $where .= " and a.gw_id={$condition['salesperson']} ";
        }
        if (!empty($condition['page'])) {
            $page = $condition['page'];
        } else {
            $page = 1;
        }
//            中心总监时查出当前中心的营销人员跟进记录
        $saleid = M("xueyuan_baoming")->where("centre_id={$zongjian['centre_id']} and gangwei='营销'")->field("user_id")->select();
        $sid = [];
        foreach ($saleid as $key => $value) {
            $sid[] = $value['user_id'];
        }
        $sid = implode(',', $sid);
//            0为潜客，1为会员'

        $count = M('crm_gj as a')
            ->join("left join wx_user as b on a.bao_id=b.user_id")
            ->join("left join xueyuan_baoming as c on a.gw_id=c.user_id")
            ->field("a.gj_id,a.fangshi,a.create_time,a.gj,a.dao,a.ty_type,a.g_pname,a.vip,b.baobao_name,c.username,b.user_id,a.neirong")
            ->where($where)
            ->count();
        $pageone = 10;//每页数据
        $pagetotal = ceil($count / $pageone);
        $pyl = ($page - 1) * $pageone;//偏移量
        $results = M('crm_gj as a')
            ->join("left join wx_user as b on a.bao_id=b.user_id")
            ->join("left join xueyuan_baoming as c on a.gw_id=c.user_id")
            ->field("a.gj_id,a.fangshi,a.create_time,a.gj,a.dao,a.ty_type,a.g_pname,a.vip,b.baobao_name,c.username,b.user_id,a.neirong")
            ->where($where)
            ->limit($pyl, $pageone)
            ->select();
        foreach ($results as $key => $value) {
            $results[$key]['page'] = $page;
            $results[$key]['pagetotal'] = $pagetotal;
            $results[$key]['num'] = $count;
            if ($value['vip'] == 0) {
                $results[$key]['vip'] = "潜客";
            }
            if ($value['vip'] == 1) {
                $results[$key]['vip'] = "会员";
            }
            if ($value['dao'] == 1) {
                $results[$key]['dao'] = "到访";
            } else {
                $results[$key]['dao'] = "未到访";
            }

        }
        json('10001', $results);
    }

    /*
    * 接口名：今日会员跟进名单（Vip_follow）
    * */
    public function Vip_follow()
    {
        header("access-control-allow-origin:*");
        $today = I('post.nianyue');
        if(empty($today)){
            $today = date("Y-m-d");
        }
        $user_id = session('user_id');
        $centre_id = session('centre_id');
        $zongjian = M('xueyuan_baoming')->where("user_id={$user_id}")->find();
        if ($zongjian == false) {
            json('10003', "查询失败");
        }
        if ($zongjian == null) {
            json('10004', "未检索到数据");
        }
        $condition = I('post.');
        if (!empty($condition['page'])) {
            $page = $condition['page'];
        } else {
            $page = 1;
        }
        if ($zongjian['gangwei'] == "中心总监") {
            $bao_id=M('crm_gj')->where("create_time like '%{$today}%' and vip=1 and centre_id='$centre_id'")->field('bao_id')->select();
        } else {
            $bao_id=M('crm_gj')->where("create_time like '%{$today}%' and vip=1 and centre_id='$centre_id' and gw_id='$user_id'")->field('bao_id')->select();
        }
        $ke=0;
        foreach ($bao_id as $key => $value) {
            $bao[$ke]=$value['bao_id'];
            $ke++;
        }
        $ae=array_flip(array_flip($bao));//去重
        $aaa=implode(",",$ae);
        $where = "b.belong={$centre_id} and b.status=1 and b.yon=2 and a.create_time like '%{$today}%' and b.user_id in({$aaa})";
        if ($condition['name']){
            $where .= "  and (b.baobao_name like '%{$condition['name']}%' or b.baobao_name2 like '%{$condition['name']}%') and a.create_time like '%{$today}%'";
        }

        if ($condition['pname']) {
            $where .= " and (b.name1 like '%{$condition['pname']}%' or b.name2 like '%{$condition['pname']}%' or b.name3 like '%{$condition['pname']}%' or b.name4 like '%{$condition['pname']}%' or b.name5 like '%{$condition['pname']}%' or b.name6 like '%{$condition['pname']}%') ";
        }

        if ($condition['pphone']) {
            $where .= " and (b.phone1 like '%{$condition['pphone']}%' or b.phone2 like '%{$condition['pphone']}%' or b.phone3 like '%{$condition['pphone']}%' or b.phone4 like '%{$condition['pphone']}%' or b.phone5 like '%{$condition['pphone']}%' or b.phone6 like '%{$condition['pphone']}%') ";
        }

        if ($condition['type']) {
            $where .= " and b.gj_type='{$condition['type']}'";
        }

        if ($condition['salesperson']) {
            $where .= " and b.gw_id={$condition['salesperson']} ";
        }

//            中心总监时查出当前中心的营销人员跟进记录
        $saleid = M("xueyuan_baoming")->where("centre_id={$zongjian['centre_id']} and gangwei='营销'")->field("user_id")->select();
        $sid = [];
        foreach ($saleid as $key => $value) {
            $sid[] = $value['user_id'];
        }
        $sid = implode(',', $sid);
//            0为潜客，1为会员'

        $count = M('wx_user as b')
            ->join("crm_gj as a on a.bao_id=b.user_id")
            ->join("left join crm_kjilu as d on b.jl_id=d.jl_id")
            ->join("left join xueyuan_baoming as c on a.gw_id=c.user_id")
            ->field('b.user_id,b.baobao_name,d.y_keshi,b.name1,b.name2,b.name3,b.name4,b.name5,b.name6,b.phone1,b.phone2,b.phone3,b.phone4,b.phone5,b.phone6,d.e_time,b.baobao_birthday,d.bz')
            ->where($where)
            ->count();
        $pageone = 10;//每页数据
        $pagetotal = ceil($count / $pageone);
        $pyl = ($page - 1) * $pageone;//偏移量
        $results = M('wx_user as b')
            ->join("crm_gj as a on b.user_id=a.bao_id")
            ->join("left join crm_kjilu as d on b.jl_id=d.jl_id")
            ->join("left join xueyuan_baoming as c on a.gw_id=c.user_id")
            ->field('b.user_id,b.baobao_name,d.y_keshi,b.name1,b.name2,b.name3,b.name4,b.name5,b.name6,b.phone1,b.phone2,b.phone3,b.phone4,b.phone5,b.phone6,d.e_time,b.baobao_birthday,d.bz')
            ->where($where)
            ->limit($pyl, $pageone)
            ->select();
       //      $a = M()->getLastsql();
       // var_dump($a);die;
        foreach ($results as $key => $value) {
            $results[$key]['page'] = $page;
            $results[$key]['pagetotal'] = $pagetotal;
            $results[$key]['num'] = $count;
            if (!empty($value['name1'])) {
                $results[$key]['p_name'] = $value['name1'];
            } else if (!empty($value['name2'])) {
                $results[$key]['p_name'] = $value['name2'];
            } else if (!empty($value['name3'])) {
                 $results[$key]['p_name'] = $value['name3'];
            } else if (!empty($value['name4'])) {
                 $results[$key]['p_name'] = $value['name4'];
            } else if (!empty($value['name5'])) {
                 $results[$key]['p_name'] = $value['name5'];
            } else if (!empty($value['name6'])) {
                 $results[$key]['p_name'] = $value['name6'];
            } else {
                 $results[$key]['p_name'] = "";
            }
//        手机
            if (!empty($value['phone1'])) {
                 $results[$key]['p_phone'] = $value['phone1'];
            } else if (!empty($value['phone2'])) {
                 $results[$key]['p_phone'] = $value['phone2'];
            } else if (!empty($value['phone3'])) {
                 $results[$key]['p_phone'] = $value['phone3'];
            } else if (!empty($value['phone4'])) {
                 $results[$key]['p_phone'] = $value['phone4'];
            } else if (!empty($value['phone5'])) {
                 $results[$key]['p_phone'] = $value['phone5'];
            } else if (!empty($value['phone6'])) {
                 $results[$key]['p_phone'] = $value['phone6'];
            } else {
                 $results[$key]['p_phone'] = "";
            }
            $last = M('crm_gj')->where("bao_id={$value['user_id']}")->order("create_time desc")->find();
            $results[$key]['last'] = $last['create_time'];
        }
        json('10001', $results);
    }


    /*
     * 接口名：今日潜客跟进名单（Normal_follow）
     * */
    public function Normal_follow()
    {
        header("access-control-allow-origin:*");
        $today = I('post.nianyue');
        if(empty($today)){
            $today = date("Y-m-d");
        }
        $user_id = session('user_id');
        $centre_id = session('centre_id');
        $zongjian = M('xueyuan_baoming')->where("user_id={$user_id}")->find();
        if ($zongjian == false) {
            json('10003', "查询失败");
        }
        if ($zongjian == null) {
            json('10004', "未检索到数据");
        }
        $condition = I('post.');
        if (!empty($condition['page'])) {
            $page = $condition['page'];
        } else {
            $page = 1;
        }
        if ($zongjian['gangwei'] == "中心总监") {
            $bao_id=M('crm_gj')->where("create_time like '%{$today}%' and vip=0 and centre_id='$centre_id'")->field('bao_id')->select();
        } else {
            $bao_id=M('crm_gj')->where("create_time like '%{$today}%' and vip=0 and centre_id='$centre_id' and gw_id='$user_id'")->field('bao_id')->select();
        }
        $ke=0;
        foreach ($bao_id as $key => $value) {
            $bao[$ke]=$value['bao_id'];
            $ke++;
        }
        $ae=array_flip(array_flip($bao));//去重
        $aaa=implode(",",$ae);
        $where = "a.belong={$centre_id} and a.status=1 and a.yon=2 and d.create_time like '%{$today}%' and a.user_id in({$aaa})";
        if ($condition['name']){
            $where .= "  and (a.baobao_name like '%{$condition['name']}%' or a.baobao_name2 like '%{$condition['name']}%') ";
        }

        if ($condition['pname']) {
            $where .= " and (a.name1 like '%{$condition['pname']}%' or a.name2 like '%{$condition['pname']}%' or a.name3 like '%{$condition['pname']}%' or a.name4 like '%{$condition['pname']}%' or a.name5 like '%{$condition['pname']}%' or a.name6 like '%{$condition['pname']}%') ";
        }

        if ($condition['pphone']) {
            $where .= " and (a.phone1 like '%{$condition['pphone']}%' or a.phone2 like '%{$condition['pphone']}%' or a.phone3 like '%{$condition['pphone']}%' or a.phone4 like '%{$condition['pphone']}%' or a.phone5 like '%{$condition['pphone']}%' or a.phone6 like '%{$condition['pphone']}%') ";
        }

        if ($condition['type']) {
            $where .= " and d.gj_type='{$condition['type']}'";
        }

        if ($condition['salesperson']) {
            $where .= " and a.gw_id={$condition['salesperson']} ";
        }

//            中心总监时查出当前中心的营销人员跟进记录
        $saleid = M("xueyuan_baoming")->where("centre_id={$zongjian['centre_id']} and gangwei='营销'")->field("user_id")->select();
        $sid = [];
        foreach ($saleid as $key => $value) {
            $sid[] = $value['user_id'];
        }
        $sid = implode(',', $sid);
//            0为潜客，1为会员'

        $count = M('wx_user as a')
            ->join("crm_gj as d on d.bao_id=a.user_id")
            ->join("left join xueyuan_baoming as b on a.gw_id=b.user_id")
            ->where($where)
            ->field("a.baobao_name,a.name1,a.name2,a.name3,a.name4,a.name5,a.name6,a.phone1,a.phone2,a.phone3,a.phone4,a.phone5,a.phone6,a.gj_type,a.gw_id,a.user_id,b.username,a.baobao_sex,a.baobao_birthday,a.laiyuan,a.beizhu")
            ->count();
            $pageone = 10;//每页数据
            $pagetotal = ceil($count / $pageone);
            $pyl = ($page - 1) * $pageone;//偏移量

        $results = M('wx_user as a')
            ->join("left join crm_gj as d on d.bao_id=a.user_id")
            ->join("left join xueyuan_baoming as b on a.gw_id=b.user_id")
            ->limit($pyl, $pageone)
            ->where($where)
            ->field("a.baobao_name,a.name1,a.name2,a.name3,a.name4,a.name5,a.name6,a.phone1,a.phone2,a.phone3,a.phone4,a.phone5,a.phone6,a.gj_type,a.gw_id,a.user_id,b.username,a.baobao_sex,a.baobao_birthday,a.laiyuan,a.beizhu")
            ->select();
        foreach ($results as $key => $value) {
            $results[$key]['page'] = $page;
            $results[$key]['pagetotal'] = $pagetotal;
            $results[$key]['num'] = $count;
//            关系判断
            if (!empty($value['name1'])) {
                $results[$key]['p_name'] = $value['name1'];
                $results[$key]['guanxi'] = '爸爸';
            } else if (!empty($value['name2'])) {
                $results[$key]['p_name'] = $value['name2'];
                $results[$key]['guanxi'] = '妈妈';
            } else if (!empty($value['name3'])) {
                 $results[$key]['p_name'] = $value['name3'];
                 $results[$key]['guanxi'] = '爷爷';
            } else if (!empty($value['name4'])) {
                 $results[$key]['p_name'] = $value['name4'];
                 $results[$key]['guanxi'] = '奶奶';
            } else if (!empty($value['name5'])) {
                 $results[$key]['p_name'] = $value['name5'];
                 $results[$key]['guanxi'] = '姥爷';
            } else if (!empty($value['name6'])) {
                 $results[$key]['p_name'] = $value['name6'];
                 $results[$key]['guanxi'] = '姥姥';
            } else {
                 $results[$key]['p_name'] = "";
            }
//        手机
            if (!empty($value['phone1'])) {
                 $results[$key]['p_phone'] = $value['phone1'];
            } else if (!empty($value['phone2'])) {
                 $results[$key]['p_phone'] = $value['phone2'];
            } else if (!empty($value['phone3'])) {
                 $results[$key]['p_phone'] = $value['phone3'];
            } else if (!empty($value['phone4'])) {
                 $results[$key]['p_phone'] = $value['phone4'];
            } else if (!empty($value['phone5'])) {
                 $results[$key]['p_phone'] = $value['phone5'];
            } else if (!empty($value['phone6'])) {
                 $results[$key]['p_phone'] = $value['phone6'];
            } else {
                 $results[$key]['p_phone'] = "";
            }
            $last = M('crm_gj')->where("bao_id={$value['user_id']}")->order("create_time desc")->find();
            $results[$key]['last'] = $last['create_time'];
//
        }
        json('10001',$results);
    }

    


}

?>