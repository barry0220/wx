<?php
namespace Home\Controller;
use Think\Controller;
class DxsurplusController extends Controller {
  //短信剩余
    public function index(){
      header("access-control-allow-origin:*");
       // $centre_id=I('post.centre_id');
    	$centre_id=session('centre_id');
       $arr['sy']=M('wx_centre')->where("centre_id='$centre_id'")->getField("dx_y");
       if($arr['sy']==null){
        $arr['sy']=0;
       }
        $sdefaultDate = date("Y-m-d"); 
       //$first =1 表示每周星期一为开始日期 0表示每周日为开始日期 
       $first=1; 
       //获取当前周的第几天 周日是 0 周一到周六是 1 - 6 
       $w=date('w',strtotime($sdefaultDate)); 
       //获取本周开始日期，如果$w是0，则表示周日，减去 6 天 
       $week_start=date('Y-m-d',strtotime("$sdefaultDate -".($w ? $w - $first : 6).'days')); 
       //本周结束日期 
       $week_end=date('Y-m-d',strtotime("$week_start +6days"));
       $arr['znum']=M('crm_dx')->where("centre_id='$centre_id' and create_time>='$week_start' and create_time<='$week_end' and status=1")->count();
       $time=date("Y-m");
       $time1=$time."-01";
       $time2=$time."-31";
       $arr['ynum']=M('crm_dx')->where("centre_id='$centre_id' and create_time>='$time1' and create_time<='$time2' and status=1")->count();
       $dx_shu=M('crm_dx_fei')->where("centre_id='$centre_id' and status='支付成功'")->field("dx_shu")->select();
       $number=0;
       foreach ($dx_shu as $key => $value) {
       	$number=$value['dx_shu']+$number;
       }
       $arr['number']=$number;
       $arr['yiyon']=$number-$arr['sy'];
       $this->ajaxReturn($arr,'JSON');
    }
}