<?php
namespace Home\Controller;
use Think\Controller;
class NewcenterController extends Controller {
    /*
     * 接口名：跟进记录（Follow）
     *
     * 接口地址（post）：Home/Newcenter/Follow
     *
     * 参数：
     *
     * 合同号：hetong
     *
     * 会员姓名：name
     *
     * 家长姓名：pname
     *
     * 家长电话：pphone
     *
     * 状态：type
     *
     * 销售人：salesperson
     *
     * 返回值：
     *
     *
     * */
    public function Follow()
    {
//        根据回传条件判断拼接查询条件
        $condition = I('post.');
        $where = " 1 ";
        if ($condition['hetong']){
            $where .= " and a.hetong={$condition['hetong']} ";
        }

        if ($condition['name']){
            $where .= "  and a.baobao_name like '%{$condition['name']}%' or a.baobaoname2 like '%{$condition['name']}% ";
        }

        if ($condition['pname']){
            $where .= " and (a.name1 like '%{$condition['pname']}%' or and a.name2 like '%{$condition['pname']}%' or and a.name3 like '%{$condition['pname']}%' or and a.name4 like '%{$condition['pname']}%' or and a.name5 like '%{$condition['pname']}%' or and a.name6 like '%{$condition['pname']}%') ";
        }

        if ($condition['pphone']){
            $where .= " and (a.phone1 like '%{$condition['pphone']}%' or and a.phone2 like '%{$condition['pphone']}%' or and a.phone3 like '%{$condition['pphone']}%' or and a.phone4 like '%{$condition['pphone']}%' or and a.phone5 like '%{$condition['pphone']}%' or and a.phone6 like '%{$condition['pphone']}%') ";
        }

        if ($condition['type']){
            $where .= " and a.gj_type={$condition['type']} ";
        }

        if ($condition['salesperson']){
            $where .= " and c.username={$condition['salesperson']} ";
        }

//        链表联查
        $data = M('wx_user as a')
            ->join("left join crm_kjilu as b on a.jl_id=b.jl_id")
            ->join("left join xueyuan_baoming as c on b.guwen=c.user_id")
            ->field("a.hetong,a.gj_type,a.baobao_name,a.baobao_name2,b.receivable,b.receipt_type,b.shishou,b.create_time,b.guwen,b.create_name,b.bz,c.user_id,c.username")
            ->where($where)
            ->order()
            ->select();
        $a = M()->getLastsql();
        var_dump($a);die;
        if ($data == false){
            json('10002',"查询失败");
        }
        if ($data == null){
            json('10003',"没有检索到数据");
        }
        json('10001',$data);

    }
}
?>