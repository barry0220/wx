<?php
namespace Home\Controller;
use Think\Controller;
class DxczjlsController extends Controller {
  //充值记录
    public function index(){
       header("access-control-allow-origin:*");
       $centre_id=session('centre_id');
       $time1=I('post.time1');
       $time2=I('post.time2');
       $arr=M('crm_dx_fei')->where("centre_id='$centre_id' and status='支付成功' and create_time>='$time1' and create_time<='$time2'")->select();
       $num=0;
       $money=0;
       foreach ($arr as $key => $value) {
       	 $num=$value['dx_shu']+$num;
       	 $money=$value['f_jine']+$money;
       	 $ar['zong']['num']=$num;
       	 $ar['zong']['money']=$money;
       	 $ar['fei'][]=$value;
       }
       $this->ajaxReturn($ar,'JSON');
   }
}