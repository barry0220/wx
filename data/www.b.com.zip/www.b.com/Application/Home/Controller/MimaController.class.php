<?php
namespace Home\Controller;
use Think\Controller;
class MimaController extends CommonController {
    //密码重置
    public function index(){
       $this->display();
    }
    public function yuanm(){
    	$ysmm=I('post.ysmm');
    	$pwd=md5(md5($ysmm));
    	$user_id=session('user_id');
    	$arr=M('xueyuan_baoming')->where("user_id='$user_id'")->getField("pad");
    	if($pwd==$arr){
    		$this->ajaxReturn(1,'JSON');
    	}else{
    		$this->ajaxReturn(2,'JSON');
    	}
    }
    public function xiugai(){
    	$pwds=I('post.pwd');
        $data['pad']=md5(md5($pwds));
        $user_id=session('user_id');
        if(M('xueyuan_baoming')->where("user_id='$user_id'")->save($data)){
        	$this->ajaxReturn(1,'JSON');
        }else{
        	$this->ajaxReturn(2,'JSON');
        }
    }
}