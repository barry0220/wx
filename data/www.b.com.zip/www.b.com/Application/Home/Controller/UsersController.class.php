<?php
namespace Home\Controller;
use Think\Controller;
class UsersController extends Controller {
    public function add(){
    	header("access-control-allow-origin:*");
    	$coun=I('post.coun');
       $sheng=I('post.sheng');
       $qu=I('post.qu');
       $site=I('post.site');
       $data['baobao_birthday']=I('post.baobao_birthday');
       $patten = "/^([1][7-9][0-9][0-9]|[2][0,1][0-9][0-9])(\-)([0][1-9]|[1][0-2])(\-)([0-2][0-9]|[3][0-1])$/";
      if (!preg_match($patten, $data['baobao_birthday'])) {
        $this->redirect("User/xinzenghui?zi=3");die;
      }
       $data['baobao_name']=I('post.baobao_name');
       $gw_id=I('post.gw_id');
       $gangwei=M('xueyuan_baoming')->where("user_id='$gw_id'")->getField('gangwei');
       if($gangwei=='营销'){
         $data['gw_id']=$gw_id;
       }else{
         $data['sc_id']=$gw_id;
       }

       $data['baobao_name2']=I('post.baobao_name2');
       $aa=M('region')->where("REGION_ID='$coun'")->getField("REGION_NAME");
       $bb=M('region')->where("REGION_ID='$sheng'")->getField("REGION_NAME");
       $cc=M('region')->where("REGION_ID='$qu'")->getField("REGION_NAME");
       $data['site']=$bb.' '.$aa.' '.$cc.' '.$site;
       $data['baobao_sex']=I('post.sex');
       $data['laiyuan']=I('post.laiyuan');
       $bz=I('post.bz');
       if($data['laiyuan']=='其他' and !empty($bz)){
         $data['laiyuan']=$bz;
       }
       $name=I('post.name');
       $phone=I('post.phone');
       $guanxi=I('post.guanxi');
       foreach ($guanxi as $key => $value) {
          switch ($value)
          {
          case '1':
            $data['name1']=$name[$key];
            $data['phone1']=$phone[$key];
            break;
          case '2':
            $data['name2']=$name[$key];
            $data['phone2']=$phone[$key];
            break;
          case '3':
            $data['name3']=$name[$key];
            $data['phone3']=$phone[$key];
            break;
          case '4':
            $data['name4']=$name[$key];
            $data['phone4']=$phone[$key];
            break;
          case '5':
            $data['name5']=$name[$key];
            $data['phone5']=$phone[$key];
            break;
          case '6':
            $data['name6']=$name[$key];
            $data['phone6']=$phone[$key];
            break;
        }
       }
       $data['yon']=2;
       $data['kahao']=I('post.kahao');
       $centre_id=session("centre_id");
       $data['belong']=$centre_id;
       if($uu=M("wx_user")->add($data)){
       	$this->redirect("User/xinzenghui?zi=1&uuid='$uu'");
       }
    }
    //地区
    public function dq(){
      header("access-control-allow-origin:*");
    	$arr=M("region")->where("PARENT_ID=1")->select();
    	$this->ajaxReturn($arr,'JSON');
    }
    //三级联动
    public function sel_coun(){
      header("access-control-allow-origin:*");
        $coun=$_POST['coun'];
        $region_info=M('region');
        $region_arr=$region_info->where("PARENT_id=".$coun)->select();
        echo json_encode($region_arr);
    }
    //搜索
    public function sou(){
      header("access-control-allow-origin:*");
    	$zhi=I('post.username');
      if($zhi==null){
        die;
      }
      $centre_id=session('centre_id');
    	$sql="SELECT user_id,baobao_name,baobao_name2 FROM wx_user where yon=2 and belong='$centre_id' and status=1 and (baobao_name like '%$zhi%' or baobao_name2 like '%$zhi%' or name2 like '%$zhi%')";
      $arr=M()->query($sql);
    	$this->ajaxReturn($arr,'JSON');
    }
    //会员签约详细信息
    public function xianx(){
      header("access-control-allow-origin:*");
    	$user_id=I('post.user_id');
    	$jl=M('wx_user')->where("user_id='$user_id'")->find();
      if($jl['name1']!=null){
        $jl['name']=$jl['name1'];
      }else if($jl['name2']!=null){
        $jl['name']=$jl['name2'];
      }else if($jl['name3']!=null){
        $jl['name']=$jl['name3'];
      }else if($jl['name4']!=null){
        $jl['name']=$jl['name4'];
      }else if($jl['name5']!=null){
        $jl['name']=$jl['name5'];
      }else if($jl['name6']!=null){
        $jl['name']=$jl['name6'];
      }
      if($jl['phone1']!=null){
        $jl['phone']=$jl['phone1'];
      }else if($jl['phone2']!=null){
        $jl['phone']=$jl['phone2'];
      }else if($jl['phone3']!=null){
        $jl['phone']=$jl['phone3'];
      }else if($jl['phone4']!=null){
        $jl['phone']=$jl['phone4'];
      }else if($jl['phone5']!=null){
        $jl['phone']=$jl['phone5'];
      }else if($jl['phone6']!=null){
        $jl['phone']=$jl['phone6'];
      }
    	$this->ajaxReturn($jl,'JSON');
    }
    //课时包
    public function kes(){
      header("access-control-allow-origin:*");
    	$centre_id=session('centre_id');
    	$arr=M("crm_goods")->where("l_id=10 and status=1 and (centre_id=0 or centre_id='$centre_id')")->order("k_shu")->select();
    	$this->ajaxReturn($arr,'JSON');
    }
    //优惠劵
    public function yhj(){
      header("access-control-allow-origin:*");
    	$centre_id=session('centre_id');
        $arr=M("crm_goods")->where("l_id=11 and status=1 and (centre_id=0 or centre_id='$centre_id')")->select();
    	$this->ajaxReturn($arr,'JSON');
    }
    //销售人
    public function xsr(){
      header("access-control-allow-origin:*");
    	$centre_id=session('centre_id');
    	$arr=M("xueyuan_baoming")->where("status=1 and centre_id='$centre_id'")->field("user_id,username")->select();
    	$this->ajaxReturn($arr,'JSON');
    }
    //课时包选的时候的价格变化
    public function jia(){
      header("access-control-allow-origin:*");
    	$s_id=I('post.s_id');
    	$arr=M('crm_goods')->where("s_id='$s_id'")->field('price,k_shu')->find();
    	$this->ajaxReturn($arr,'JSON');
    }
    //选择了优惠劵后应收金额的变化
    public function jine(){
      header("access-control-allow-origin:*");
      $money=I('post.money');
      $price=M('crm_goods')->where("s_id='$money'")->getField("price");
      $s_id=I('post.s_id');
      $str=M('crm_goods')->where("s_id='$s_id'")->getField("price");
      $ss=$price-$str;
      $this->ajaxReturn($ss,'JSON');
    }
    //添加合约
    public function addhy(){
      header("access-control-allow-origin:*");
      $user_id=I('post.user_id');
      $jl=M('wx_user')->where("user_id='$user_id'")->find();
      $jl_id=$jl['jl_id'];
      $y=M('crm_kjilu')->where("jl_id='$jl_id'")->field("y_keshi,user_id")->find();
      $y_keshi=$y['y_keshi'];
      $uuid=$y['user_id'];
      $xuy=explode(",", $uuid);
      $hetong=I('post.hetong');
      $da['hetong']=$hetong;
      $centre_id=session("centre_id");
      $da['centre_id']=$centre_id;
      $shuju=M("crm_kjilu")->where("hetong='$hetong' and centre_id='$centre_id'")->getField('jl_id');
        if(!empty($shuju)){
           $this->ajaxReturn(2,'JSON');die;
        }
      $da['dindan']=I('post.dindan');
      $da['s_id']=I('post.s_id');
      $you=I('post.you');
      $aaa=M("crm_goods")->where("s_id='$you'")->find();
      $da['youhui_name']=$aaa['s_name'];
      $da['create_time']=I('post.start_time');
      $patten = "/^([1][7-9][0-9][0-9]|[2][0,1][0-9][0-9])(\-)([0][1-9]|[1][0-2])(\-)([0-2][0-9]|[3][0-1])$/";
      if (!preg_match($patten, $da['create_time'])) {
        $this->ajaxReturn(3,'JSON');die;
      }
      $da['youhui_money']=$aaa['price'];
      $da['e_time']=I('post.end_time');
      if (!preg_match($patten, $da['e_time'])) {
        $this->ajaxReturn(3,'JSON');die;
      }
      $da['create_name']=session("user_id");
      $da['zeng_ke']=I('post.zeng_ke');
      $da['type']=I('post.type');
      $da['receivable']=I('post.yingshou');
      $da['shishou']=I('post.shishou');
      if($uuid==null){
        $da['user_id']=$user_id;
        $data['user_id']=$user_id;
      }else{
        $da['user_id']=$uuid;
        $data['user_id']=$uuid;
      }
      $da['shoudong_money']=$da['receivable']-$da['shishou'];
      $da['y_keshi']=I('post.y_keshi')+$da['zeng_ke']+$y_keshi;//课时包加上赠课加上上份合约剩余课时
      $da['guwen']=I('post.guwen');
      $da['bz']=I('post.bz');
      $id=M('crm_kjilu')->add($da);
      if($jl_id!=null){
        $data['status']=3;
        $data['y_keshi']=0;
        M('crm_kjilu')->where("jl_id='$jl_id'")->save($data);
      }
      $as['jl_id']=$id;
      foreach ($xuy as $key => $value) {
        if($user_id!=$value){
          M('wx_user')->where("user_id='$value'")->save($as);
        }
      }
      $dd['jl_id']=$id;//会员变成新合约数据
      $dd['vip']=1;
      $dd['gw_id']=$da['guwen'];
      $dd['kahao']=I('post.kahao');
      $dat['huilv']=M('wx_centre')->where("centre_id='$centre_id'")->getField('huilv');
      $dat['user_id']=$user_id;
      $dat['jl_id']=$id;
      $dat['shishou']=$da['shishou'];
      $dat['create_name']=session('user_id');
      $dat['jiao']=$da['shishou']*$dat['huilv'];
      $dat['centre_id']=$centre_id;
      M('crm_huilv')->add($dat);
      if(M('wx_user')->where("user_id='$user_id'")->save($dd)){
        $arr=M('wx_centre')->where("centre_id='$centre_id'")->find();
        $arr1=M('crm_kjilu')
        ->join("crm_goods on crm_kjilu.s_id=crm_goods.s_id")
        ->field('crm_kjilu.*,crm_goods.k_shu')
        ->where("crm_kjilu.jl_id='$id'")
        ->find();
        if($arr['dx_qianyue']!=0 and $arr['dx_y']>0){
             if($jl['name1']!=null){
               $name=$jl['name1'];
             }else if($jl['name2']!=null){
               $name=$jl['name2'];
             }else if($jl['name3']!=null){
               $name=$jl['name3'];
             }else if($jl['name4']!=null){
               $name=$jl['name4'];
             }else if($jl['name5']!=null){
               $name=$jl['name5'];
             }else if($jl['name6']!=null){
               $name=$jl['name6'];
             }
             if($jl['phone1']!=null){
               $phone=$jl['phone1'];
             }else if($jl['phone2']!=null){
               $phone=$jl['phone2'];
             }else if($jl['phone3']!=null){
               $phone=$jl['phone3'];
             }else if($jl['phone4']!=null){
               $phone=$jl['phone4'];
             }else if($jl['phone5']!=null){
               $phone=$jl['phone5'];
             }else if($jl['phone6']!=null){
               $phone=$jl['phone6'];
             }
             $keshi=$arr1['k_shu']+$arr1['zeng_ke'];
             $mb_id=$arr['dx_qianyue'];
             $mb=M('crm_dx_mb')->where("mb_id='$mb_id'")->find();
             $ph=new \Org\dx\Photo;
             $aa=$ph->number($arr['centre'],$jl['baobao_name'],$phone,$mb['alid'],$mb['mb_type'],$name,$arr1['hetong'],$arr1['shishou'],$keshi,$arr1['create_time'],$arr1['e_time']);
             $data['mb_id']=$arr['dx_qianyue'];
             $data['centre_id']=$centre_id;
             $data['create_id']=session('user_id');
             $data['phone']=$phone;
             $data['user_id']=$user_id;
             $data['nianyue']=date("Y-m");
             $data['type']='自动';
             $vv=$aa->result->success[0];
               if($vv==true){
                 $data['status']=1;
                 M('wx_centre')->where("centre_id='$centre_id'")->setDec('dx_y');
               }else{
                 $data['status']=0;
               }
               M('crm_dx')->add($data);
        }
        $jk=M('wx_user')->where("user_id='$user_id'")->field('baobao_name,baobao_name2')->find();
        $time=date('Y-m-d H:i:s');
        $username=M('xueyuan_baoming')->where("user_id='$da[guwen]'")->getField('username');
        $template_id='ArhPKld1CGeBpb4gbqZ5Ni0c_HUlUM7LfEOURsm1New';
        $open=M('xueyuan_user')->where("centre_id='$centre_id' and role=2")->field('openid,username')->select();
        foreach ($open as $key => $value) {
          $data['touser']=$value['openid'];
        $data['template_id']=$template_id;
        $data['data']['first']=array("value"=>"尊敬的$value[username]，您好：");
        $data['url']='http://wx.gymbaby.cn/quanxian/index.php?zzz=2';
        $data['data']['keyword1']=array("value"=>"$username","color"=>"#173177");
        $data['data']['keyword2']=array("value"=>"$time","color"=>"#173177");
        $data['data']['keyword3']=array("value"=>"$jk[baobao_name]","color"=>"#173177");
        $data['data']['keyword4']=array("value"=>"$jk[baobao_name2]","color"=>"#173177");
        $data['data']['remark']=array("value"=>'运动宝贝温馨提示',"color"=>"#173177");
          $a[]=wxts($data);
        }
        $this->ajaxReturn(1,'JSON');
      }
      
    }
    //会员列表
    public function user(){
      header("access-control-allow-origin:*");
      ob_end_clean();
      if(isset($_POST['p'])){
         $page=$_POST['p'];
       }else{
         $page=1;
       }
       $status=I('post.status');
       $centre_id=session('centre_id');
       $zhi=I('post.zhi');
       $shij=date("Y-m-d");
       if($zhi==null){
        $num=M('wx_user')->where("yon=2 and belong='$centre_id' and status=1 and vip='$status'")->count();
       $pageone=15;//每页数据
       $pagetotal=ceil($num/$pageone);
       $pyl=($page-1)*$pageone;//偏移量
       $sql="SELECT wx_user.vip,wx_user.baobao_birthday,wx_user.laiyuan,wx_user.user_id,wx_user.baobao_name,wx_user.baobao_name2,wx_user.baobao_sex,crm_kjilu.y_keshi,crm_kjilu.e_time,crm_kjilu.create_time,wx_user.phone2,wx_user.name2 FROM wx_user LEFT JOIN crm_kjilu on wx_user.jl_id=crm_kjilu.jl_id where wx_user.yon=2 and wx_user.belong='$centre_id' and wx_user.status=1 and wx_user.vip='$status' limit $pyl,$pageone";
       $hh=M()->query($sql);
      foreach ($hh as $key => $value) {
        $d=strtotime($shij)-strtotime($value['baobao_birthday']);
        $e=$d/2592000;//一个月的时间，单位秒
        $f=round($e);//月龄取整
        if($f==576){
          $hh[$key]['yueling']=0;
        }else{
          $hh[$key]['yueling']=$f;
        }
        $hh[$key]['page']=$page;
         $hh[$key]['pagetotal']=$pagetotal;
         $hh[$key]['num']=$num;
      }
      // echo "<pre>";
      // print_r($hh);die;
       $this->ajaxReturn($hh,'JSON');
     }else{
       $zh=explode("-", $zhi);
        if(count($zh)<2){
          $sql1="SELECT count(*) as num FROM wx_user LEFT JOIN crm_kjilu on wx_user.jl_id=crm_kjilu.jl_id where wx_user.yon=2 and wx_user.belong='$centre_id' and wx_user.status=1 and vip='$status' and (wx_user.baobao_name like '%$zhi%' or wx_user.baobao_name2 like '%$zhi%' or wx_user.name2 like '%$zhi%' or crm_kjilu.y_keshi='$zhi')";
          $numm=M()->query($sql1);
          $num=$numm[0]['num'];
          $pageone=15;//每页数据
          $pagetotal=ceil($num/$pageone);
          $pyl=($page-1)*$pageone;//偏移量
          $sql="SELECT wx_user.vip,wx_user.baobao_birthday,wx_user.laiyuan,wx_user.user_id,wx_user.baobao_name,wx_user.baobao_name2,wx_user.baobao_sex,crm_kjilu.y_keshi,crm_kjilu.create_time,crm_kjilu.e_time,wx_user.phone2,wx_user.name2 FROM wx_user LEFT JOIN crm_kjilu on wx_user.jl_id=crm_kjilu.jl_id where wx_user.yon=2 and wx_user.belong='$centre_id' and wx_user.status=1 and (wx_user.baobao_name like '%$zhi%' or wx_user.baobao_name2 like '%$zhi%' or wx_user.name2 like '%$zhi%' or crm_kjilu.y_keshi='$zhi') limit $pyl,$pageone";  
        }else{
           $sql="SELECT wx_user.vip,wx_user.baobao_birthday,wx_user.laiyuan,wx_user.user_id,wx_user.baobao_name,wx_user.baobao_name2,wx_user.baobao_sex,crm_kjilu.y_keshi,crm_kjilu.create_time,crm_kjilu.e_time,wx_user.phone2,wx_user.name2 FROM wx_user LEFT JOIN crm_kjilu on wx_user.jl_id=crm_kjilu.jl_id where wx_user.yon=2 and wx_user.belong='$centre_id' and wx_user.status=1";
        }
       $da=M()->query($sql);
       foreach ($da as $key => $value) {
        $d=strtotime($shij)-strtotime($value['baobao_birthday']);
        $e=$d/2592000;//一个月的时间，单位秒
        $f=round($e);//月龄取整
        if($f==576){
          $da[$key]['yueling']=0;
        }else{
          $da[$key]['yueling']=$f;
        }
        $da[$key]['page']=$page;
         $da[$key]['pagetotal']=$pagetotal;
         $da[$key]['num']=$num;
      }
      foreach ($da as $key => $value) {
        if(count($zh)>1){
        if($da[$key]['yueling']>=$zh[0] and $da[$key]['yueling']<=$zh[1]){
                  $da[$key] = $value;
              }else{
                  unset($da[$key]);
              }
      }
    }
      // echo "<pre>";
      // print_r($da);die;
       $this->ajaxReturn($da,'JSON');
     }
       
    }
    //头像上传
    public function tonx(){
      header("access-control-allow-origin:*"); 
       header('Content-type:text/html;charset=utf-8');
       $base64_image_content = $_POST['img'];
       $user_id=I('post.user_id');
       $time=date('Ymd');
       //匹配出图片的格式
       if (preg_match('/^(data:\s*image\/(\w+);base64,)/', $base64_image_content, $result)){
       $type = $result[2];
       $new_file = "Uploads/".date('Ymd',time())."/";
       if(!file_exists($new_file))
       {
       //检查是否有该文件夹，如果没有就创建，并给予最高权限
       mkdir($new_file, 0700);
       }
       $new_file = $new_file.time().".{$type}";
       if (file_put_contents($new_file, base64_decode(str_replace($result[1], '', $base64_image_content)))){
          $data['img']='/'.$new_file;
          if(M('wx_user')->where("user_id='$user_id'")->save($data)){
            echo 1;
          } 
       }else{
       echo '新文件保存失败';
       }
       }
    }
    //会员安全删除
    public function shanchu(){
      header("access-control-allow-origin:*"); 
      $user_id=I('post.user_id');
      $data['status']=0;
      if(M('wx_user')->where("user_id='$user_id'")->save($data)){
        echo 1;
      }
    }
    //会员详细信息
    public function huiyuanlieb(){
      header("access-control-allow-origin:*"); 
      $user_id=1887;
      $user=M('wx_user')->where("user_id='$user_id'")->find();
      $jl_id=$user['jl_id'];
      $centre_id=$user['belong'];
      $time=date("Y-m-d");
      $sql="select flexo.content,crm_goods.price,crm_kjilu.guwen,crm_goods.s_id,crm_goods.k_shu,crm_goods.s_name,xueyuan_baoming.username,crm_kjilu.* from crm_kjilu left join crm_goods on crm_kjilu.s_id=crm_goods.s_id left join xueyuan_baoming on crm_kjilu.guwen=xueyuan_baoming.user_id left join flexo on crm_kjilu.type=flexo.xuhao where crm_kjilu.jl_id='$jl_id' and crm_kjilu.status=1 and flexo.yon=17";
      $het=M()->query($sql);
      // if($het[0]['e_time']<$time){
      //   $sql1="select crm_goods.k_shu,crm_goods.s_name,xueyuan_baoming.username,crm_kjilu.* from crm_kjilu left join crm_goods on crm_kjilu.s_id=crm_goods.s_id left join xueyuan_baoming on crm_kjilu.user_id=xueyuan_baoming.user_id where crm_kjilu.jl_id='$jl_id' and crm_kjilu.e_time>='$time'";
      //   $guoq=M()->query($sql1);
      // }else{
        // $guoq=M("crm_kjilu")
        // ->join("crm_goods on crm_kjilu.s_id=crm_goods.s_id")
        // ->join("xueyuan_baoming on crm_kjilu.user_id=xueyuan_baoming.user_id")
        // ->where("crm_kjilu.user_id='$user_id' and crm_kjilu.status=3")
        // ->field("crm_goods.k_shu,crm_goods.s_name,xueyuan_baoming.username,crm_kjilu.*")
        // ->select();

        $sql2="select flexo.content,crm_goods.k_shu,crm_goods.s_name,xueyuan_baoming.username,crm_kjilu.* from crm_kjilu left join crm_goods on crm_kjilu.s_id=crm_goods.s_id left join xueyuan_baoming on crm_kjilu.guwen=xueyuan_baoming.user_id left join flexo on flexo.xuhao=crm_kjilu.type where crm_kjilu.centre_id='$centre_id' and crm_kjilu.status=3 and flexo.yon=17";
        $guo=M()->query($sql2);
        foreach ($guo as $key => $value) {
          $uu=explode(",", $value['user_id']);
          if(in_array($user_id, $uu)){
            $guoq[]=$value;
          }
        }
      // }
      $arr['user_id']=$user_id;
      $arr['baobao_name']=$user['baobao_name'];
      $arr['baobao_name2']=$user['baobao_name2'];
      $arr['baobao_birthday']=$user['baobao_birthday'];
      $arr['baobao_sex']=$user['baobao_sex'];
      $arr['kahao']=$user['kahao'];
      $arr['name1']=$user['name1'];
      $arr['name2']=$user['name2'];
      $arr['name3']=$user['name3'];
      $arr['name4']=$user['name4'];
      $arr['name5']=$user['name5'];
      $arr['name6']=$user['name6'];
      $arr['phone1']=$user['phone1'];
      $arr['phone2']=$user['phone2'];
      $arr['phone3']=$user['phone3'];
      $arr['phone4']=$user['phone4'];
      $arr['phone5']=$user['phone5'];
      $arr['phone6']=$user['phone6'];
      $arr['site']=$user['site'];
      $arr['hetong']=$het[0]['hetong'];
      $arr['dindan']=$het[0]['dindan'];
      $arr['k_shu']=$het[0]['k_shu'];
      $arr['jl_id']=$jl_id;
      $arr['zeng_ke']=$het[0]['zeng_ke'];
      $arr['shishou']=$het[0]['shishou'];
      $arr['s_name']=$het[0]['s_name'];
      $arr['username']=$het[0]['username'];
      $arr['youhui_money']=$het[0]['youhui_money'];
      $arr['create_time']=$het[0]['create_time'];
      $arr['e_time']=$het[0]['e_time'];
      $arr['img']=$user['img'];
      $arr['receivable']=$het[0]['receivable'];
      $arr['price']=$het[0]['price'];
      $arr['bz']=$het[0]['bz'];
      $arr['s_id']=$het[0]['s_id'];
      $arr['uuid']=$het[0]['guwen'];
      $arr['content']=$het[0]['content'];
      $arrrr=explode(' ',$het[0]['create_time']);
      $start_time2=$arrrr[0];
      $arr['start_time5']=$start_time2;
      $arr['end_time5']=$het[0]['e_time'];
      $sql5="select crm_goods.k_shu,crm_goods.s_name,xueyuan_baoming.username,crm_kjilu.* from crm_kjilu left join crm_goods on crm_kjilu.s_id=crm_goods.s_id left join xueyuan_baoming on crm_kjilu.guwen=xueyuan_baoming.user_id where crm_kjilu.centre_id='$centre_id'";
        $guo13=M()->query($sql5);
        foreach ($guo13 as $key => $value) {
          $uuq=explode(",", $value['user_id']);
          if(in_array($user_id, $uuq)){
            $guoqx[]=$value;
          }
        }
      $zs=$het[0]['k_shu']+$het[0]['zeng_ke'];
      foreach ($guoq as $key => $value) {
        $zs=$value['k_shu']+$value['zeng_ke']+$zs;
      }
      // $uuu=explode(',', $guoq[0]['user_id']);
      $aax='';
      foreach ($guoqx as $key => $value) {
        $aax=$value['user_id'].','.$aax;
      }
      $aae=$aax.','.$user_id;
      $uuu=explode(',', $aae);
      foreach ($uuu as $k => $val) {
        if($val!=null){
          $sd[]=$val;
        }
      }
      $aaz=array_flip(array_flip($sd));
      $kks=0;
      $wjk=0;
      foreach ($aaz as $key => $value) {
        $kkss=M('crm_user_skjl')->where("user_id='$value' and status=2")->sum('xiaohao');
        $kks=$kks+$kkss;
        $wjks=M('crm_user_skjl')->where("user_id='$value' and status=1")->sum('xiaohao');
        $wjk=$wjk+$wjks;
      }
      $arr['kks']=$kks;
      $arr['wjk']=$wjk;
      $arr['zks']=$zs;
      $arr['syks']=$het[0]['y_keshi'];
      // k($arr);die;
      // echo $zs;die;
      // $zhu['jilu']=$jilu;
      // $zhu['xxx']=$arr;
      // $zhu['guoq']=$guoq;
      $this->ajaxReturn($arr,'JSON');
      // $this->display();
    }
    //过期
    public function guq(){
      header("access-control-allow-origin:*"); 
       $user_id=I('post.user_id');
       $centre_id=M('wx_user')->where("user_id='$user_id'")->getField('belong');
       $sql2="select flexo.content,crm_goods.k_shu,crm_goods.s_name,xueyuan_baoming.username,crm_kjilu.* from crm_kjilu left join crm_goods on crm_kjilu.s_id=crm_goods.s_id left join xueyuan_baoming on crm_kjilu.guwen=xueyuan_baoming.user_id left join flexo on flexo.xuhao=crm_kjilu.type where crm_kjilu.centre_id='$centre_id' and crm_kjilu.status=3 and flexo.yon=17";
        $guo=M()->query($sql2);
        foreach ($guo as $key => $value) {
          $uu=explode(",", $value['user_id']);
          if(in_array($user_id, $uu)){
            $guoq[]=$value;
          }
        }
        $this->ajaxReturn($guoq,'JSON');
    }
    //课程列表接口
    public function kc(){
      header("access-control-allow-origin:*"); 
      $user_id=I('post.user_id');
      if(isset($_POST['page'])){
         $page=$_POST['page'];
       }else{
         $page=1;
       }
       $pageone=2;//每页数据
       $pagetotal=ceil($num/$pageone);
       $pyl=($page-1)*$pageone;//偏移量
       $jilu=M('crm_user_skjl')
      ->join("crm_kecheng on crm_user_skjl.pk_id=crm_kecheng.pk_id")
      ->join("crm_ke on crm_kecheng.kc_id=crm_ke.kc_id")
      ->where("crm_user_skjl.user_id='$user_id' and (crm_user_skjl.status=1 or crm_user_skjl.status=2)")
      ->field("crm_user_skjl.create_time,crm_ke.kc_name,crm_kecheng.s_time,crm_kecheng.x_time,crm_user_skjl.status")
      ->limit($pyl,$pageone)
      ->select();
       foreach ($jilu as $key => $value) {
         $jilu[$key]['page']=$page;
         $jilu[$key]['pagetotal']=$pagetotal;
         $jilu[$key]['num']=$num;
       }
       $this->ajaxReturn($jilu,'JSON');
    }
    public function site(){
      header("access-control-allow-origin:*");
      $centre_id=session('centre_id');
      $site=M('wx_centre')->where("centre_id='$centre_id'")->getField('site');
      $arr=explode(" ", $site);
      $parent['sheng']=M('region')->where("REGION_NAME='$arr[0]'")->getField('REGION_ID');
      $parent['shi']=M('region')->where("REGION_NAME='$arr[1]'")->getField('REGION_ID');
      $parent['qu']=M('region')->where("REGION_NAME='$arr[2]'")->getField('REGION_ID');
      // var_dump($arr);die;
      $this->ajaxReturn($parent,'JSON');
    }
    public function sitee(){
      header("access-control-allow-origin:*");
      $centre_id=session('centre_id');
      $site=M('wx_centre')->where("centre_id='$centre_id'")->getField('site');
      $arr=explode(" ", $site);
      $parent_id=M('region')->where("REGION_NAME='$arr[0]'")->getField('REGION_ID');
      $ar=M('region')->where("PARENT_ID='$parent_id'")->select();
      $this->ajaxReturn($ar,'JSON');
    }
    public function siteee(){
      header("access-control-allow-origin:*");
      $centre_id=session('centre_id');
      $site=M('wx_centre')->where("centre_id='$centre_id'")->getField('site');
      $arr=explode(" ", $site);
      $parent_id=M('region')->where("REGION_NAME='$arr[1]'")->getField('REGION_ID');
      $ar=M('region')->where("PARENT_ID='$parent_id'")->select();
      $this->ajaxReturn($ar,'JSON');
    }



}