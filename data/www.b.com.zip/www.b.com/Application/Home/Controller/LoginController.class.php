<?php
// 本类由系统自动生成，仅供测试用途
namespace Home\Controller;
use Think\Controller;
class LoginController extends Controller {
    //登录
    public function index(){
        $zz=I('get.zz');
        if($zz==null){
            $zz=0;
        }
        $this->zz=$zz;
        //判断登录表单是否提交
        if($a = I('post.')){
            //判断协议是否勾选
            if(!$a['xie']){
                $this->assign('ar',3);      //手机号不存在，返回2，页面提示密码错误
                $this->display();
                die;
            }
            $p = md5(md5($a['pad']));           //对收到的用户密码进行加密
            $m=M('xueyuan_baoming')->where("phone='{$a['phone']}' and status=1")->find();    //查询用户手机号是否存在
            //判断用户是否存在
            if(!$m){
                $this->assign('ar',1);          //手机号不存在，返回1，页面提示手机号错误
                $this->display();
            }else{
                //判断密码是否正确
                if ( $m['pad'] != $p ) {
                    $this->assign('ar',2);      //密码不正确，返回2，页面提示密码错误
                    $this->display();
                }elseif($m['pad'] == "a9e9a81003adc4f8ce4d15a027347ff5"){
                    session('user_id',$m['user_id']);           //用户ID 存入session
                    $this->redirect('chong');
                }else{
                    $jyzt = M('wx_centre')->getByCentreId($m['centre_id']);
                    if($jyzt['nature'] == 1 || $jyzt['jyzt'] == 1 || $jyzt['jyzt'] == 12 || $jyzt['jyzt'] == 8 || $jyzt['jyzt'] == 10){
                        $zz = M('wx_centre_z')->getByCentreId($m['centre_id']);
                        $r = date("Y-m-d");							//获取当前时间（年月日）格式
                        //计算出管理费到期日期前30天的日期
                        $guan1 = strtotime($zz['gl_time'])-2592000;
                        $guan1 = date("Y-m-d",$guan1);
                        //计算出管理费到期日期后30天的日期
                        $guan2 = strtotime($zz['gl_time'])+2592000;
                        $guan2 = date("Y-m-d",$guan2);
                        //当管理费到期前30天 返回1
                        if($r < $zz['gl_time'] && $r > $guan1){
                           $cui['cui']=1;
                        }
                        //当管理费到期前30天 返回2
                        if($r > $zz['gl_time'] && $r < $guan2){
                            $cui['cui']=2;
                        }
                        //当管理费延时缴费中
                        if($jyzt['jyzt'] == 8 ){
                            $cui['cui']=3;
                        }
                        session('name',$m['username']);             //用户名 存入session
                        session('user_id',$m['user_id']);           //用户ID 存入session
                        session('centre_id',$m['centre_id']);       //中心ID 存入session
                        session('role',$m['role']);                 //角色 存入session
                        session('gangwei',$m['gangwei']);           //岗位 存入session
                        session('phone',$m['phone']);               //手机号 存入session
                        $m['login_time']=date('Y-m-d H:i:s');
                        $m['session_id'] = session_id(); 
                        $status=M('crm_login')->where("user_id='$m[user_id]' and phone='$m[phone]'")->order('id desc')->getField('status');
                        if($status==2){
                            $m['status']=2;
                        }
                        $m['ip']=$a['ip'];
                        M('crm_login')->add($m); 
                        $this->redirect('Index/index',$cui);
                    }else{
                        $this->assign('ar',4);      //中心状态异常，返回3，页面提示中心状态异常
                        $this->display();
                    }
                }
            }
        }else{
            $this->display();
        }
    }
    //注销
    public function out(){
        session(null);
        $this->redirect('Login/index');
    }
    //查看
    public function sai(){
        $w[] = session('name');             //用户名 存入session
        $w[] = session('user_id');           //用户ID 存入session
        $w[] = session('centre_id');       //中心ID 存入session
        $w[] = session('role');                 //角色 存入session
        $w[] = session('gangwei');           //岗位 存入session
                    k($w);
    }
    //密码重置
    public function chong(){
        if($a = I('post.')){
            if($a['pad'] != $a['pad1']){
                $this->assign('ar',1);      //两次密码不一致
                $this->display();die;
            }
            if(!$a['pad']){
                $this->assign('ar',2);      //密码不能为空
                $this->display();die;
            }
            $p['pad'] = md5(md5($a['pad']));           //对收到的用户密码进行加密
            if($p['pad'] == "a9e9a81003adc4f8ce4d15a027347ff5"){
                $this->assign('ar',3);      //密码不能和初始密码相同
                $this->display();die;
            }
            $p['user_id'] = session('user_id');
            $e = M('xueyuan_baoming')->save($p);
            if($e){
                $this->redirect('index');
            }
        }else{
            $this->display();
        }
//
//        $this->assign('cui',$a);      //中心状态异常，返回3，页面提示中心状态异常
}
   public function fankui(){
    $this->display();
   }
   public function yindaoye(){
      $this->display();
    }
    public function mi(){
      $data['status']=2;
      $session_id=session_id();
      M('crm_login')->where("session_id='$session_id'")->save($data);
      echo 1;
    }
}