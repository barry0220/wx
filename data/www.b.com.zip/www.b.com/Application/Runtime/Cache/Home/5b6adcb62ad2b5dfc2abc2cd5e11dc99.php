<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!--360浏览器优先以webkit内核解析-->

    <title>运动宝贝</title>
    <link rel="shortcut icon" href="/Public/image/favicon.ico">
    <link href="/Public/css/bootstrap.css" rel="stylesheet">
    <link href="/Public/css/paike.css" rel="stylesheet">
    <link rel="stylesheet" href="/Public/css/login.css"/>
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://cdn.bootcss.com/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="/Public/js/bootstrap.min.js"></script>
    <style>
    /*下线通知start*/
.xaixBtn{
    box-sizing: border-box;
    width: 115px;
    height: 28px;
    line-height: 28px;
    text-align: center;
    cursor: pointer;
    border-radius: 14px;
    border: 1px solid #fdb06a;
    background: #fff;
}
/*下线通知end*/
    </style>
</head>
<body style="background: url(/Public/img/login.png) no-repeat ;background-size: cover;position: relative"  >
<div class="top"></div>
<div class="box">
    <div class="box_2">
        <div class="box_2_1">
            用户登录
        </div>
        <div class="box_2_2">
            <div class="box_2_2_1">
                <?php if($ar == 1): ?><span style="color:red" >手机号码错误</span>
                    <?php elseif($ar == 2): ?>
                        <span style="color:red" >密码错误</span>
                    <?php elseif($ar == 3): ?>
                        <span style="color:red" >未勾选协议</span>
                    <?php elseif($ar == 4): ?>
                    <span style="color:red" >管理费欠缴，请联系运营</span>
                    <?php else: ?>
                    <span style="color: #1f8c22" ></span><?php endif; ?>
            </div>
            <form action="<?php echo U('Login/index');?>" method="post">
                <div class="box_2_2_2">
                    <input type="text" placeholder="手机号" name="phone"><br>
                    <input type="password" placeholder="登录密码" name="pad">
                </div>
                <div class="box_2_2_3">
                    <input type="checkbox" class="mk1" name="xie" value="1" Checked/><span style="font-size: 11px">我已阅读并同意遵守《运动宝贝服务协议》</span>
                </div>
                <div class="box_2_2_4">
                    <input type="submit" value="登 录" class="deng">
                </div>
            </form>
        </div>
    </div>
    <div class="box_3">
        <img src="/Public/img/gymbaby.png" alt="">
    </div>
    <div class="ban">
        版本：1.0.0
    </div>
</div>
<!-- 下线通知弹窗 start-->
  <div class="modal fade" id="myModalxiax" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"  style="background:rgba(0,0,0,0.3) ">
      <div class="modal-dialog" role="document" style="width: 450px;margin: 160px auto 0">
          <div class="modal-content" style="border-radius: 10px;overflow: hidden">
              <div class="modal-header" style="background:#fdb06a ">
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                  <h4 class="text-center">下线通知</h4>
              </div>
              <div class="modal-body" style="height: 164px;padding-left: 36px">
                <p><img src="/Public/img/xianxiats.png" style="width: 51px" alt="">
                &nbsp;&nbsp;&nbsp;  您的账号在另一地点登录。已被迫下线
                </p>
                  <p style="padding-left: 72px">
                      如果这不是您本人的操作，那么您的密码 <br>
                      很可能已泄露。<br> 建议您及时修改密码。
                  </p>
              </div>
              <div class="modal-footer clearfloat" style="padding:8px 90px 8px 90px;background:#ffebd9 ">
                 <!-- <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                  <button type="button" class="btn btn-primary">Save changes</button>-->
                  <div class="xaixBtn" onclick="gg()" style="float: left" data-dismiss="modal">重新登录</div>
                  <div class="xaixBtn" onclick="gg()" style="float: right" data-dismiss="modal">确定</div>

              </div>
          </div>
      </div>
  </div>
<!-- 下线通知弹窗 end-->
</body>

<script>
     /*下线通知弹窗 start*/
zz=<?php echo ($zz); ?>;
if(zz==1){
    $('#myModalxiax').modal({"backdrop":"static"});
}
function gg(){
    $('#myModalxiax').css('display:none')
}
      /*下线通知弹窗 end*/
</script>
</html>