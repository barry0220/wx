<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <META HTTP-EQUIV="pragma" CONTENT="no-cache">
    <META HTTP-EQUIV="Cache-Control" CONTENT="no-cache, must-revalidate">
    <META HTTP-EQUIV="expires" CONTENT="0">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="initial-scale=1.0, user-scalable=no" />
    <link rel="stylesheet" href="/Public/css/bootstrap.min.css"/>

    <link rel="stylesheet" href="/Public/css/chushiyangsh.css">
    <link rel="stylesheet" href="/Public/css/gindex.css">
    <script src="/Public/js/jquery-1.11.3.js"></script>
    <script src="/Public/js/bootstrap.js"></script>
    <script src="/Public/js/vue.min.js"></script>
    <script src="/Public/js/echarts.min.js"></script>
    <title></title>
    <style>
        [v-cloak] {
            display: none;
        }
       body  .table-bordered>thead{
           border-top:1px solid #b8b2e2;
       }
        .table-bordered>tbody>tr>td, .table-bordered>tbody>tr>th, .table-bordered>tfoot>tr>td, .table-bordered>tfoot>tr>th, .table-bordered>thead>tr>td, .table-bordered>thead>tr>th {
            border: 1px solid #b8b2e2;
        }
    </style>
</head>
<body style="background: #ededed;">
<!--[if lte IE 9]>
<p class="browsehappy">你正在使用<strong>过时</strong>的浏览器，Amaze UI 暂不支持。 请 <a
        href="http://browsehappy.com/" target="_blank">升级浏览器</a>
    以获得更好的体验！</p>
<![endif]-->

<div class="inBox " id="app">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-9" style="width: 78%">
                <div class="row toubu">

                    <div class="col-sm-2" style="cursor: pointer" onclick='javascript:window.location.href="<?php echo U('Genjing/yuexinzengmd');?>"' >
                        <div class="toubulist">
                            <div class="media">
                                <a class="media-left" href="javascript:;">
                                    <img style="width: 40px" class="media-object" src="/Public/img/lvrentou.png" alt="">
                                </a>
                                <div class="media-body">
                                 <h4 class="media-heading" v-cloak>{{dataa.xzmd}}</h4>
                                    <!--<h4 class="media-heading">0</h4>-->
                                    <span v-cloak>{{dataa.yue}}</span>月新增名单
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-sm-2" style="cursor: pointer" onclick='javascript:window.location.href="<?php echo U('Genjing/yuegenjinjl');?>"' >
                        <div class="toubulist">
                            <div class="media">
                                <a class="media-left" href="javascript:;">
                                    <img style="width: 40px" class="media-object" src="/Public/img/lanjsb.png" alt="">
                                </a>
                                <div class="media-body">
                                    <h4 class="media-heading" v-cloak>{{dataa.gjjl}}</h4>
                                    <span v-cloak>{{dataa.yue}}</span>月跟进记录
                                </div>
                            </div>

                        </div>
                    </div>
                    <div class="col-sm-2" style="cursor: pointer" onclick='javascript:window.location.href="<?php echo U('Genjing/mingdanzs');?>"'>
                        <div class="toubulist">
                            <div class="media">
                                <a class="media-left" href="javascript:;">
                                    <img class="media-object" style="width: 40px" src="/Public/img/mingdans.png" alt="">
                                </a>
                                <div class="media-body">
                                    <h4 class="media-heading" v-cloak>{{dataa.mdzs}}</h4>
                                   名单总数
                                </div>
                            </div>

                        </div>
                    </div>
                    <div class="col-sm-2" style="cursor: pointer" onclick='javascript:window.location.href="<?php echo U('Genjing/hetongshu');?>"'>
                        <div class="toubulist">
                            <div class="media">
                                <a class="media-left" href="javascript:;">
                                    <img class="media-object" style="width: 40px" src="/Public/img/huanght.png" alt="">
                                </a>
                                <div class="media-body">
                                    <h4 class="media-heading">{{dataa.hts}}</h4>
                                   <span>{{dataa.yue}}</span>月合同数
                                </div>
                            </div>

                        </div>
                    </div>
                    <div class="col-sm-2" style="cursor: pointer" onclick='javascript:window.location.href="<?php echo U('Genjing/hetongshu');?>"'>
                        <div class="toubulist">
                            <div class="media">
                                <a class="media-left" href="javascript:;">
                                    <img class="media-object" style="width: 40px" src="/Public/img/hongjsq.png" alt="">
                                </a>
                                <div class="media-body">
                                    <h4 class="media-heading" v-cloak>{{dataa.htje}}</h4>
                                    <span v-cloak>{{dataa.yue}}</span>月合同金额
                                </div>
                            </div>

                        </div>
                    </div>

                        <div class="col-sm-7" style="padding-left: 0;padding-right: 0;margin-top: 10px">
                            <div class="tubiao">
                                <div id="e1"></div>
                            </div>
                        </div>
                        <div class="col-sm-5" style="margin-top: 10px;cursor: pointer" onclick='javascript:window.location.href="<?php echo U('Genjing/qjinrijijigenj');?>"' >
                            <div class="qianBg">
                                <p class="qiankeT">潜客</p>
                                <div class="media">
                                    <a class="media-left" href="javascript:;">
                                        <img class="media-object" style="width: 100px" src="/Public/img/baiwj.png" alt="">
                                    </a>
                                    <div class="media-body" style="text-align: center;color: #fff;font-size: 16px">
                                        <p style="font-size: 100px;line-height: 106px" class="media-heading" v-cloak>{{dataa.qjjgj}}</p>
                                        今日紧急跟进名单
                                    </div>
                                </div>
                            </div>

                        </div>

                    <div class="col-sm-7" style="padding-left: 0;padding-right: 0;margin-top: 10px">
                        <div class="tubiao">
                            <div id="e2"></div>
                        </div>
                    </div>
                    <div class="col-sm-5" style="margin-top: 10px;cursor: pointer" onclick='javascript:window.location.href="<?php echo U('Genjing/hjinrijijigenj');?>"'>
                        <div class="qianBg" style="background: #ffb97b">
                            <p class="qiankeT">会员</p>
                            <div class="media">
                                <a class="media-left" href="javascript:;">
                                    <img class="media-object" style="width: 100px" src="/Public/img/baiwj.png" alt="">
                                </a>
                                <div class="media-body" style="text-align: center;color: #fff;font-size: 16px">
                                    <p style="font-size: 100px;line-height: 106px" class="media-heading" v-cloak>{{dataa.hjjgj}}</p>
                                    今日紧急跟进名单
                                </div>
                            </div>
                        </div>

                    </div>

                </div>
            </div>
            <div class="col-sm-3" style="width: 22%">
                <div class="rightM bg1" style="margin-top:48px;cursor: pointer " onclick='javascript:window.location.href="<?php echo U('Genjing/qjinrienjinmd');?>"'  >
                    <p class="nimei">潜客</p>
                    <p class="text-center" style="color: #fff">今日跟进名单 &nbsp; <span style="font-size: 60px" v-cloak>{{dataa.qjrgj}}</span></p>
                </div>
                <div class="rightM bg2" style="margin-bottom: 32px;cursor: pointer" onclick='javascript:window.location.href="<?php echo U('Genjing/qjinrienjinxz');?>"' >
                    <p class="nimei">潜客</p>
                    <p class="text-center" style="color: #fff">今日新增名单 &nbsp; <span style="font-size: 60px" v-cloak>{{dataa.qxzmd}}</span></p>
                </div>
                <div class="rightM bg3" style="cursor: pointer" onclick='javascript:window.location.href="<?php echo U('Genjing/hjinrienjinmd');?>"' >
                    <p class="nimei">会员</p>
                    <p class="text-center" style="color: #fff">今日跟进名单 &nbsp; <span style="font-size: 60px" v-cloak>{{dataa.hjrgj}}</span></p>
                </div>
                <div class="rightM bg4" style="cursor: pointer" onclick='javascript:window.location.href="<?php echo U('Genjing/hjinrienjinxz');?>"' >
                    <p class="nimei">会员</p>
                    <p class="text-center" style="color: #fff">今日新增名单 &nbsp; <span style="font-size: 60px" v-cloak>{{dataa.hxzmd}}</span></p>
                </div>

            </div>
        </div>
    </div>
</div>


<script>

    new Vue({
        el:"#app",
        data:{
            dataa:""

        },
        beforeCreate:function(){
            var self=this;
            $.ajax({
                url:"http://192.168.1.243/huiyuanzi/home/qk/xz",
                type:"post",
                dataType:"json",
                data:{},
                success:function(data){
                    self.dataa=data.result;
//                    console.log(data.result)
                }
            });

            $.ajax({
                url:"http://192.168.1.243/huiyuanzi/home/qk/qkzx",
                type:"post",
                dataType:"json",
                data:{},
                success:function(data){
                    console.log(data.result);
                    var a1=data.result.zs;
                    var b1=data.result.yx;
                    var c1=data.result.ygj;
                    var d1=data.result.ydd;
                    var e1=data.result.yqy;
                    var myChart1 = echarts.init(document.getElementById('e1'));
                    option = {
                        tooltip : {
                            trigger: 'axis',
                            axisPointer : {            // 坐标轴指示器，坐标轴触发有效
                                type : 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
                            }
                        },
                        grid: {
                            left: '3%',
                            right: '4%',
                            bottom: '5%',
                            containLabel: true
                        },
                        xAxis : [
                            {
                                type : 'category',
                                data : ['总数', '有效', '已跟进', '已到店', '已签约' ],
                                axisTick: {
                                    show:false,
                                    alignWithLabel: false
                                },
                                axisLabel:{
                                    show:false,
                                },
                                axisLine: {
                                    show:false,
                                },

                            }
                        ],
                        yAxis : [
                            {
                                show:false,
                                type : 'value'
                            }
                        ],
                        series : [
                            {
                                name:'',
                                type:'bar',
                                barWidth: '30%',
                                label:{
                                    normal:{
                                        show:true,
                                        position:'bottom',
                                        formatter:'{b}',
                                        textStyle:{
                                            color:'#666'
                                        }
                                    }
                                },
                                itemStyle:{
                                    normal:{
                                        barBorderRadius:100,
                                        color:function(idx) {
                                            console.log(idx)
                                            var color = ['#00cce4','#f8e334','#ffb97b','#ff797c','#a9d86e']
                                            return color[idx.dataIndex % color.length]
                                        }
                                    }
                                },
                                data:[a1, b1, c1, d1, e1]
                            }
                        ]
                    };

                    myChart1.setOption(option);
                    window.onresize = myChart1.resize;
                }
            });

            $.ajax({
                url:"http://192.168.1.243/huiyuanzi/home/qk/hyzx",
                type:"post",
                dataType:"json",
                data:{},
                success:function(data){

                    console.log(data.result);
                    var a1=data.result.zs;
                    var b1=data.result.yx;
                    var c1=data.result.ygj;
                    var d1=data.result.ydd;
                    var e1=data.result.yqy;
                    var myChart2 = echarts.init(document.getElementById('e2'));

                    option = {
                        tooltip : {
                            trigger: 'axis',
                            axisPointer : {            // 坐标轴指示器，坐标轴触发有效
                                type : 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
                            }
                        },
                        grid: {
                            left: '3%',
                            right: '4%',
                            bottom: '5%',
                            containLabel: true
                        },
                        xAxis : [
                            {
                                type : 'category',
                                data : ['总数', '有效', '已跟进', '已到店', '已签约' ],
                                axisTick: {
                                    show:false,
                                    alignWithLabel: false
                                },
                                axisLabel:{
                                    show:false,
                                },
                                axisLine: {
                                    show:false,
                                },

                            }
                        ],
                        yAxis : [
                            {
                                show:false,
                                type : 'value'
                            }
                        ],
                        series : [
                            {
                                name:'',
                                type:'bar',
                                barWidth: '30%',
                                label:{
                                    normal:{
                                        show:true,
                                        position:'bottom',
                                        formatter:'{b}',
                                        textStyle:{
                                            color:'#666'
                                        }
                                    }
                                },
                                itemStyle:{
                                    normal:{
                                        barBorderRadius:100,
                                        color:function(idx) {
                                            console.log(idx)
                                            var color = ['#00cce4','#f8e334','#ffb97b','#ff797c','#a9d86e']
                                            return color[idx.dataIndex % color.length]
                                        }
                                    }
                                },
                                data:[a1, b1, c1, d1, e1]
                            }
                        ]
                    };

                    myChart2.setOption(option);
                    window.onresize = myChart2.resize;
                }
            });




        },
        methods:{

        }
    })






</script>


</body>
</html>