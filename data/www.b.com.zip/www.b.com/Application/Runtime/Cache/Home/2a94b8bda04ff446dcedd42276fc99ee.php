<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="zh-CN">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- 上述3个meta标签*必须*放在最前面，任何其他内容都*必须*跟随其后！ -->
	  <META HTTP-EQUIV="pragma" CONTENT="no-cache">
	  <META HTTP-EQUIV="Cache-Control" CONTENT="no-cache, must-revalidate">
	  <META HTTP-EQUIV="expires" CONTENT="0">
    <title>运动宝贝</title>
	<!-- 标题角图 -->
	<link rel="shortcut icon" href="/Public/image/favicon.ico">
    <!-- Bootstrap -->
    <link href="/Public/css/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="/Public/css/index_2.css"/>
	<link rel="stylesheet" type="text/css" href="/Public/css/gonggongyangshibiao.css"/>
	<link rel="stylesheet" type="text/css" href="/Public/css/jquery.marquee.min.css"/>
	<script src="/Public/js/jquery-1.9.1.min.js" type="text/javascript" charset="utf-8"></script>
	<script src="/Public/js/index1.js" type="text/javascript" charset="utf-8"></script>
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://cdn.bootcss.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
	<!-- 引入layui样式 -->
	<script src="/Public/layui/layui.js"></script>
	  <style>


		  .clearfloat:after{display:block;clear:both;content:"";visibility:hidden;height:0}
		  .clearfloat{zoom:1}

		  /*	  .zuolan1{
                    position: absolute;
                    left: 0;
                    top: 0;
                    width: 100%;
                    height: 100%;
                   padding-top: 5px;
                    padding-bottom: 5px;
                    padding-left: 8%;
                }*/
		  /*.qinghu{
			  color: #fff;
			  background: #7c71bf;
			  display: block;
			  height: 28px;
			  line-height: 28px;
			  margin-top: 3px;
			  border: none;
			  border-radius: 15px;
			  padding-left: 20px;
			  padding-right: 20px;
			  float: right;
			  margin-right: 40px;
			  font-size: 14px;
			  cursor: pointer;
		  }*/
	.box_r_1 .bangzhuBtn{
			  width: 62px;
			  height: 24px;
			  display: block;
			  line-height: 28px;
			  margin-top: 5px;
			  float: right;
			  margin-right: 30px;
		  }
	  </style>
  </head>
  <body style="background-color:#BDC3C7;">
  <div class="center">
	  <!--软件名称条  start-->
	  <div class="top" style="position: relative;width: 100%;height: 40px">
		  <img class="logo" src="/Public/image/logo.png" alt="logo">
		  <div class="top_l_1">EMOP_GYMBABY</div>
		  <!-- <div class="gundongtiao" style="width: 700px;height: 40px;line-height: 40px;position: absolute;top:0;background: red">
			  <div style="width: 100%;height: 100%">
				  <ul id="marquee" class="marquee" style="width: 100%;height: 100%">  <?php if(is_array($gg)): $i = 0; $__LIST__ = $gg;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vv): $mod = ($i % 2 );++$i;?><li  style="height: 100%;line-height: 40px;padding: 0">
						  <a href="#" target="_blank"><?php echo ($vv["synopsis"]); ?>
						  </a> [<?php echo ($vv["time"]); ?>]</li> <?php endforeach; endif; else: echo "" ;endif; ?> 
				  </ul>

			  </div>
		  </div> -->

		  <div class="top_R">
			  <?php echo (session('name')); ?>
			  <img class="sanjiao" id="zutc" src="/Public/img/san.png" alt="注销"  align="center">
			  <ul class="zhuxiaoUl">
				  <li>  <a class="zhuxiao1" href="<?php echo U('Login/out');?>" style="height: 30px;width: 100%;font-size: 12px;color:black;"> 注销</a></li>
				  <li >  <a id="genrz"  class="zhuxiao1" href="javascript:;" style="height: 30px;width: 100%;font-size: 12px;color:black;" target="right"> 个人中心</a></li>
			  </ul>
		  </div>


	  </div>
	  <!--软件名称条  end-->
	  <!--主体部分  start-->
	  <div class="box_z">
		  <!--左导航条  start-->
		  <div class="box_l">
			  <div class="gaodu">
			  <!--站位div  start-->
			  <div class="box_l_tu">
			  </div>
<?php if(in_array(14,$nav_id)): ?><div class="zuolan">
			  <div class="box_l_tu">
				  <img class="tu3" src="/Public/img/cebianxiaotiao.png" alt="">
				  <a href="<?php echo U('Duanxin/index');?>" target="right">
				  	<img class="tu" src="/Public/img/duanxin.png" alt="短信">
				  </a>
				 <img class="tu2" src="/Public/img/ceibiansanjiao.png" alt="">
			  </div>
			  <div class="box_l_zi">短信</div>
			  </div><?php endif; ?>
			  <!--站位div  end-->

            <?php if(in_array(1,$nav_id)): ?><div class="zuolan">
			  <div class="box_l_tu">
				  <img class="tu3" src="/Public/img/cebianxiaotiao.png" alt="">
				  <a href="<?php echo U('User/index');?>" target="right">
				  	<img class="tu" src="/Public/img/23.png" alt="会员">
				  </a>
				<!--  <img class="tu2" src="/Public/img/ceibiansanjiao.png" alt="">-->
			  </div>
			  <div class="box_l_zi">会员</div>
			  </div><?php endif; ?>

             <?php if(in_array(2,$nav_id)): ?><div class="zuolan">
			  <div class="box_l_tu">
				  <img class="tu3" src="/Public/img/cebianxiaotiao.png" alt="">
				  <a href="<?php echo U('PaiKe/index');?>" target="right">
					  <img class="tu" src="/Public/img/21.png" alt="排课">
				  </a>
				 <!-- <img class="tu2" src="/Public/img/ceibiansanjiao.png" alt="">-->
			  </div>
			  <div class="box_l_zi">排课</div>
			  </div><?php endif; ?>

             <?php if(in_array(3,$nav_id)): ?><div class="zuolan">
			  <div class="box_l_tu">
				  <img class="tu3" src="/Public/img/cebianxiaotiao.png" alt="">
				  <a href="<?php echo U('PaiKe/xuan');?>" target="right">
					  <img class="tu" src="/Public/img/22.png" alt="选课">
				  </a>
				<!--  <img class="tu2" src="/Public/img/ceibiansanjiao.png" alt="">-->
			  </div>
			  <div class="box_l_zi">选课</div>
			  </div><?php endif; ?>
            <?php if(in_array(5,$nav_id)): ?><div class="zuolan">
			  <div class="box_l_tu">
				  <img class="tu3" src="/Public/img/cebianxiaotiao.png" alt="">
				  <a href="<?php echo U('Activity/index');?>" target="right">
					  <img class="tu" src="/Public/img/huodongq/1.png" alt="活动">
				  </a>





				<!--  <img class="tu2" src="/Public/img/ceibiansanjiao.png" alt="">-->
			  </div>
			  <div class="box_l_zi">活动</div>
			  </div><?php endif; ?>

			  <?php if(in_array(6,$nav_id)): ?><div class="zuolan">
					  <div class="box_l_tu dao_0">
						  <img class="tu3" src="/Public/img/cebianxiaotiao.png" alt="">
						  <a href="<?php echo U('Genjing/index');?>" target="right">
							  <img class="tu" src="/Public/img/104.11.png" alt="跟进">
						  </a>
						  <!--  <img class="tu2" src="/Public/img/ceibiansanjiao.png" alt="">-->
						  <!--二级导航条 start-->
						  <div class="dao_1">
							  <!--<div class="dao_1_1">系统设置</div>-->
							  <div class="dao_1_2">
								  <ul class="xtsz">
									  <!--<li><div>系统设置</div></li>  -->
									  <!--<li><a class="dao_1_1">跟进管理</a></li>-->
									  <?php if(in_array(10,$nav_id)): ?><li class="xtszli"><a style="color: #333" href="<?php echo U('Genjing/suogm');?>" target="right">跟进名单</a></li><?php endif; ?>
									  <?php if(in_array(11,$nav_id)): ?><li class="xtszli"><a style="color: #333" href="<?php echo U('Qian/luruqiank');?>" target="right">添加名单</a></li><?php endif; ?>
									  <?php if(in_array(12,$nav_id)): ?><li class="xtszli"><a style="color: #333" href="<?php echo U('Genjing/gqmingd');?>" target="right">名单分配</a></li><?php endif; ?>




								  </ul>
							  </div>
						  </div>
						  <!--二级导航条 end-->


					  </div>
					  <div class="box_l_zi">跟进</div>
				  </div><?php endif; ?>


            <?php if(in_array(7,$nav_id)): ?><div class="zuolan">
			  <div class="box_l_tu">
				  <img class="tu3" src="/Public/img/cebianxiaotiao.png" alt="">
				  <a href="<?php echo U('Qiandao/index');?>" target="right">
				  	<img class="tu" style="width: 36px" src="/Public/img/qiandao.png" alt="签到">
				  </a>
				 <!-- <img class="tu2" src="/Public/img/ceibiansanjiao.png" alt="">-->
			  </div>
			  <div class="box_l_zi">签到</div>
			  </div><?php endif; ?>

             <?php if(in_array(8,$nav_id)): ?><div class="zuolan">
			  <div class="box_l_tu">
				  <img class="tu3" src="/Public/img/cebianxiaotiao.png" alt="">
				  <a href="<?php echo U('Biao/indexk');?>" target="right">
				  	<img class="tu" style="width: 32px; height: 32px;" src="/Public/img/kehao.png" alt="耗课">
				  </a>
				 <!-- <img class="tu2" src="/Public/img/ceibiansanjiao.png" alt="">-->
			  </div>
			  <div class="box_l_zi">耗课</div>
			  </div><?php endif; ?>

			 <?php if(in_array(9,$nav_id)): ?><div class="zuolan">
			  <div class="box_l_tu">
				  <img class="tu3" src="/Public/img/cebianxiaotiao.png" alt="">
				  <a href="<?php echo U('Biao/indexh');?>" target="right">
				  	<img class="tu" src="/Public/img/26.png" alt="合约">
				  </a>
				<!--  <img class="tu2" src="/Public/img/ceibiansanjiao.png" alt="">-->
			  </div>
			  <div class="box_l_zi">合约</div>
			  </div><?php endif; ?>

			  <div class="zuolan">
			  <div class="box_l_tu dao_0">
				  <img class="tu3" src="/Public/img/cebianxiaotiao.png" alt="">
				  <img class="tu" src="/Public/img/25.png" alt="系统设置">
				<!--  <img class="tu2" src="/Public/img/ceibiansanjiao.png" alt="">-->
				  <!--二级导航条 start-->
				  <div class="dao_1" id="dao_1">
					  <!--<div class="dao_1_1">系统设置</div>-->
					  <div class="dao_1_2">
						  <ul class="xtsz">
							  <!--<li><div>系统设置</div></li>  -->
							  <li><a class="dao_1_1">系统设置</a></li>
							  <?php if(in_array(10,$nav_id)): ?><li class="xtszli"><a style="color: #333" href="<?php echo U('Yuangon/index');?>" target="right">员工设置</a></li><?php endif; ?>
							  <?php if(in_array(11,$nav_id)): ?><li class="xtszli"><a style="color: #333" href="<?php echo U('Kecb/index');?>" target="right">商品设置</a></li><?php endif; ?>
							  <?php if(in_array(12,$nav_id)): ?><li class="xtszli"><a style="color: #333" href="<?php echo U('Kecsz/index');?>" target="right">课程设置</a></li><?php endif; ?>

							  	<li class="xtszli"><a style="color: #333" href="<?php echo U('Mima/index');?>" target="right">密码重置</a></li>

						  </ul>
					  </div>
				  </div>
				  <!--二级导航条 end-->
			  </div>
			  <div class="box_l_zi">系统</div>

			  </div>
			  
			   <!--下拉框-->

			  <!--<div class="jiaowuf" style="width: 100%;height: 80px;position: absolute;left: 100%;top: 0" >-->
				  <!--<ul class="xuanpaike" style="width: 100%;">-->
					  <!--<li style="width: 100%;height: 50%;text-align: center;line-height: 40px;font-size: 14px;background:#2C3E50;color: white ">-->
						  <!--<a style="text-decoration: none;color: white" href="<?php echo U('PaiKe/index');?>" target="right"> 排课</a>-->
					  <!--</li>-->
					  <!--<li style="width: 100%;height: 50%;text-align: center;line-height: 40px;font-size: 14px;background:#2C3E50;color: white ">-->
						  <!--<a style="text-decoration: none;color: white" href="<?php echo U('PaiKe/xuan');?>" target="right">选课</a>-->
					  <!--</li>-->
				  <!--</ul>-->
			  <!--</div>-->
			  <!-- 下拉框-->

			  </div>
		  </div>
		  <!--左导航条  end-->
		  <!--右框  start-->
		  <div class="box_R">
			  <div class="box_r_1">
				  <a href="<?php echo U('index');?>"><img src="/Public/img/home.png" ></a>
				  <?php echo ($centre); ?>
				  <img style="cursor: pointer;" class="bangzhuBtn" src="/Public/img/helpbtn.png" alt="">
				<!--  <span class="qinghu">清除缓存</span>-->
			  </div>
			  <div class="box_r_2">
				  <iframe name="right" width="100%" height="100%" src="<?php echo U('Genjing/index');?>" frameborder="0" seamless></iframe>
			  </div>
			  <div class="box_r_3">
				  版权所有：北京运动宝贝教育科技有限公司     工信部备案号：京ICP备16051683号-1 <br/>
				  地址：北京市朝阳区红军营南路15号瑞普大厦C座3层
				  <img src="/Public/image/guo.png" alt="" style="width: 13px">
				  京公网安备：11010502032362号
			  </div>
		  </div>
		  <!--右框  end-->
	  </div>
	  <!--主体部分  end-->
  </div>


  <div class="modal fade" id="myModal23" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" style="background:rgba(0,0,0,0.3) ">
	  <div class="modal-dialog" role="document" style="width: 700px;margin: 160px auto 0;position: relative ">
		  <img src="/Public/img/tuyisheng.png" style="width: 105px;height: 108px;position: absolute;left:234px;top:-54px;z-index: 999" alt="">
		  <div class="modal-content" style="border-radius: 12px">
			  <div class="modal-header" style="padding-left:75px;height: 55px " >
				  <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				  <h4 class="modal-title text-center colorhua fon30" id="myModalLabel" style="color: #7d71c3;height: 0.8rem;line-height: 0.8rem">小帮手</h4>
			  </div>
			  <div class="modal-body" id="liaocBoxa" style="height: 270px;overflow-y: scroll">
			  	 <div id="liaocBox">
				<!--右侧聊天-->
				  <!--<div class="clearfloat" style="width: 100%;margin-bottom: 20px">
				  <div style="float: right;max-width: 70%;">
					  <div class="yongtou">
						  <img src="/Public/img/yonghuh.png" style="width: 100%" alt="">
					  </div>
					  <img style="width: 7px;margin-top: 20px;float: right" src="/Public/img/sanjiaorh.png" alt="">
					<div class="yLbox">	请问，怎么添加新会员？怎么添加新会员怎么添加新会员怎么添加新会员怎么添加新会员</div>
				  </div>
				  </div>-->
				<!--右侧聊天-->
				  <!--左侧聊天-->
				  <div class="clearfloat" style="width: 100%;margin-bottom: 20px">
					  <div style="float: left;max-width: 70%;">
						  <div class="yongtou2">
							  <img src="/Public/img/shabitoux.png" style="width: 100%" alt="">
						  </div>
						  <img style="width: 7px;margin-top: 20px;float: left" src="/Public/img/sanjiaolb.png" alt="">
						  <div class="yLbox2">您有什么需要询问的吗？</div>
					  </div>
				  </div>
				  <!--左侧聊天-->
				  
				  </div>


			  </div>
			  <div class="modal-footer">
				  <textarea name="" id="neirong1" style="width: 500px;height: 70px;resize: none;float: left;border: none" placeholder="请输入需要帮助的问题"></textarea>
						<div class="fasongBtn">
							发送
						</div>
				  <!--<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				  <button type="button" class="btn btn-primary">Save changes</button>-->
			  </div>
		  </div>
	  </div>
  </div>


  <!--下载二维码弹窗start-->
  <div class="modal fade" id="xiazaiTan" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" style="background:rgba(0,0,0,0.3) ">
	  <div class="modal-dialog" role="document" style="width: 300px">
		  <div class="modal-content" style="border-radius: 10px;overflow: hidden;margin-top: 100px">
			  <div class="modal-header" style="padding-top:10px;padding-bottom: 10px;background: #7c71bf;color: #fff">
				  <button type="button" class="close" data-dismiss="modal" aria-label="Close" style="opacity: 1"><img src="/Public/img/tanguanbi.png" style="width: 20px" alt=""></button>
				  <h4 class="modal-title text-center colorhua fon30"  >下载签到二维码</h4>
			  </div>
			  <div class="modal-body">
				  <img style="width: 100%" src="<?php echo ($ewm); ?>" alt="">
			  </div>
			  <div class="modal-footer clearfloat" style="border: none;padding:0 30px 10px 30px">
				  <!--  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary">Save changes</button>-->
				  <a href="http://crm.gymbaby.cn/Home/ewmxz/index?centre_id=<?php echo (session('centre_id')); ?>"><div class="xaixBtn" style="float: left;width: 80px;background:#7c71bf;color: #fff;border-color:#7c71bf">下载</div></a>
				  <a href=""><div class="xaixBtn" style="float: left;width: 80px;background:#7c71bf;color: #fff;border-color:#7c71bf">下载</div></a>
				  <a href="https://crm.gymbaby.cn/Home/ewmxz/index?centre_id=<?php echo (session('centre_id')); ?>"><div class="xaixBtn" style="float: left;width: 80px;background:#7c71bf;color: #fff;border-color:#7c71bf">下载</div></a>
				  <div class="xaixBtn" style="float: right;width: 80px;" data-dismiss="modal">取消</div>
			  </div>
		  </div>
	  </div>
  </div>

  <!--下载二维码弹窗end-->





    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://cdn.bootcss.com/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="/Public/js/bootstrap.min.js"></script>
  <script>

	  // $('#xiazaiTan').modal({"backdrop":"static"})
	/*  $(function () {
		  juzzhong("#myModalxiax");
		  function juzzhong(aa) {
			  var $modal_dialog = $(aa).find('.modal-dialog');
			  var clientHeight=$(window).height();
			  var dialogHeight= $modal_dialog.height();
			  console.log(clientHeight,dialogHeight)
			  var m_top = (clientHeight - dialogHeight)/2;
			  $modal_dialog.find(".modal-content").css({'margin': m_top + 'px auto 0'});
		  }

	  })*/
	 

	  /*帮助js start*/
	  $('.bangzhuBtn').click(function () {
		  $('#myModal23').modal({"backdrop":"static"})
	  });
  $('.fasongBtn').click(function () {
	  var lineir=$('#neirong1').val();
	  if(lineir){
		 var strL='<div class="clearfloat" style="width: 100%;margin-bottom: 20px">' +
				 '<div style="float: right;max-width: 70%;">' +
				 '<div class="yongtou">' +
				 '<img src="/Public/img/yonghuh.png" style="width: 100%" alt="">' +
				 ' </div>' +
				 '<img style="width: 7px;margin-top: 20px;float: right" src="/Public/img/sanjiaorh.png" alt="">' +
				 ' <div class="yLbox">'+lineir+'</div>' +
				 '</div>' +
				 '</div>';
		  $('#liaocBox').append(strL);
		/*  alert($('#liaocBox').height())*/
		  $('#liaocBoxa').scrollTop($('#liaocBox').height());
		  $.ajax({
			  "type": "post",
			  "url": "https://crm.gymbaby.cn/Index/wen",
			  "dataType": "json",
			  "data":{
				  "wen":lineir
			  },
			  success: function (data) {
				  var strass='';
				  console.log(data);
				  if(data){
					for(var i=0;i<data.length;i++){
						strass+='<div class="clearfloat" style="width: 100%;margin-bottom: 20px">' +
								'<div style="float: left;max-width: 70%;">' +
								'<div class="yongtou2">' +
								'<img src="/Public/img/shabitoux.png" style="width: 100%" alt="">' +
								'</div>' +
								'<img style="width: 7px;margin-top: 20px;float: left" src="/Public/img/sanjiaolb.png" alt="">' +
								'<div class="yLbox2">问题：'+data[i].wen+'<br/>答：'+data[i].da+'</div>' +
								'</div>' +
								'</div>'
					}
					  $('#liaocBox').append(strass);

					  $('#liaocBoxa').scrollTop($('#liaocBox').height());

				  }else{

					 var stra='<div class="clearfloat" style="width: 100%;margin-bottom: 20px">' +
							  '<div style="float: left;max-width: 70%;">' +
							  '<div class="yongtou2">' +
							  '<img src="/Public/img/shabitoux.png" style="width: 100%" alt="">' +
							  '</div>' +
							  '<img style="width: 7px;margin-top: 20px;float: left" src="/Public/img/sanjiaolb.png" alt="">' +

							  '<div class="yLbox2">您的问题暂时没有收录</div>' +
							  '</div>' +
							  '</div>'
					  $('#liaocBox').append(stra);

					  $('#liaocBoxa').scrollTop($('#liaocBox').height());
				  }

			  }
		  })

		  $('#neirong1').val('');
	  }else {
		  return false;
	  }
  });
	  /*帮助js end*/



 /* $('.zuolan').hover(function () {
		  $(this).find('.zuolan1').css({

		  "background":"#56a1ed"
		  })
	  },function () {
		  $(this).find('.zuolan1').css({
			  "background":"none"
		  })
	  })*/
/* $('.qinghu').click(function () {
	 location.reload()
 })*/
	  $('.zuolan').click(function () {
		  $('.zuolan').css({
			  'background':"#7c71bf",
			  'color':"#7c71bf"
		  });
	/*	  if($(this).index()==1){
			  $(this).find('.tu').attr('src','/Public/img/')
		  }*/
		  $(this).css({
			  'background':"#a097e4",
			  'color':"#fff"
		  });
	  })
  </script>
   	<script src="/Public/js/index.js"></script>
  <script src="/Public/js/jquery.marquee.min.js"></script>
  <script>
	  //弹窗插件
	  function add(n){
		  layui.use('layer', function(){
			  var layer = layui.layer;
			  layer.msg(n, {
				  anim:1,
				  area:'300px',
				  time: 0,
				  btnAlign: 'c',
				  btn: ['知道了'],
				  shade: [0.8, '#393D49']
			  });
		  });
	  }
	  //管理费到期提示弹窗
	  $(function () {
		  var ww = <?php echo ($cui); ?>;
		  if(ww == 1){
			  add("主人<br/>权益金即将到期请联系贝贝<br/>尽快处理哦！");
		  }else if(ww == 2){
			  add("主人<br/>发现您的权益金处于异常状态<br/>请火速处理<br/>否则系统将无法正常运转");
		  }else if(ww == 3){
			  add("主人<br/>权益金延时中<br/>请火速处理<br/>否则系统将无法正常运转");
		  }
		  $('#marquee').marquee({
			  yScroll: "top",        // 初始滚动方向 (还可以是"top" 或 "bottom")         ,
			  showSpeed: 850,        // 初始下拉速度         ,
			  scrollSpeed: 12,       // 滚动速度         ,
			  pauseSpeed: 2000 ,     // 滚动完到下一条的间隔时间         ,
			  pauseOnHover: true,    // 鼠标滑向文字时是否停止滚动         ,
			  loop: -1,              // 设置循环滚动次数 （-1为无限循环）         ,
			  fxEasingShow: "swing",  // 缓冲效果         ,
			  fxEasingScroll: "linear",  // 缓冲效果         ,
			  cssShowing: "marquee-showing",  //定义class           //
			  init: null,                // 初始调用函数         ,
			  beforeshow: null,           // 滚动前回调函数         ,
			  show: null                 // 当新的滚动内容显示时回调函数
		  });
        var winWid= parseInt($(window).width());
		  var gunWid= parseInt($('.gundongtiao').width());
		  var leftNum=(winWid-gunWid)/2;
		$('.gundongtiao').css({
	"left":leftNum
})

	  })
  </script>
  <script>
	  $(function () {
		  if( $(window).height()<710&&$('.gaodu').height()>600){
		      $('#dao_1').css({
		          'top':'-50px'
			  })
		  }

      });


	  $('#genrz').click(function(){
		/*  alert(11);*/
		$('.zuolan').css({
			"background":" rgb(124, 113, 191)",
			"color":"rgb(124, 113, 191)"
		});
		  window.parent.right.location.href="<?php echo U('Yuangon/geren');?>"
	  })

  </script>
  </body>

</html>