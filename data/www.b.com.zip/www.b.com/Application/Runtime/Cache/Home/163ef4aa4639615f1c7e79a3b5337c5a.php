<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>页面走丢了</title>
</head>
<body>
    <img src="/Public/image/404.jpg" alt="页面走丢了" width="80%">
</body>
</html>